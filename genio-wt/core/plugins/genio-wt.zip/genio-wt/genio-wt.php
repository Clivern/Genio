<?php
/*
Plugin Name: Genio
Plugin URI: https://clivern.com
Description: WordPress Theme Core Plugin
Author: Clivern
Author URI: http://clivern.com/
Version: 1.0
License: GPL
*/
/**
 * If this file is called directly, abort.
 */
if ( !defined('WPINC') )
{
      die;
}

/**
 * Genio Root File Path
 *
 * Used for plugin activation
 * 
 * @since 1.0
 */
define('GENIO_WT_ROOT_FILE', __FILE__);

/**
 * Genio Root Dir Path
 *
 * @since 1.0
 */
define('GENIO_WT_ROOT_DIR', dirname(__FILE__));

/**
 * load plugin files loader
 */
include_once GENIO_WT_ROOT_DIR . '/loader.php';