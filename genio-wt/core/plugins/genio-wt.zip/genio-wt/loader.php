<?php
/**
 * Genio - WordPress Theme Core Plugin
 *
 * @version 1.0
 * @package genio-wt
 * @author  Clivern <support@clivern.com>
 * @link    http://clivern.com/
 * @copyright     Copyright (c) 2015, Clivern (http://clivern.com/)
 * @license http://themeforest.net/licenses GPL
 */

/**
 * If this file is called directly, abort.
 */
if ( !defined('WPINC') ) {
      die;
}

/**
 * load shortcodes class
 */
if ( !class_exists('GENIO_WT_SHORTCODES') ) {
      include_once GENIO_WT_ROOT_DIR . '/core/shortcodes.php';
}

/**
 * load widgets class
 */
if ( !class_exists('GENIO_WT_WIDGETS') ) {
      include_once GENIO_WT_ROOT_DIR . '/core/widgets.php';
}

/**
 * load validator class
 */
if ( !class_exists('GENIO_WT_VALIDATOR') ) {
      include_once GENIO_WT_ROOT_DIR . '/core/validator.php';
}

/**
 * load importer class
 */
if ( !class_exists('GENIO_WT_IMPORTER') ) {
      include_once GENIO_WT_ROOT_DIR . '/core/importer.php';
}

/**
 * load core class
 */
if ( !class_exists('GENIO_WT_CORE') ) {
      include_once GENIO_WT_ROOT_DIR . '/core/core.php';
}

/**
 * An instance of shortcodes class
 *
 * @since 1.0
 * @var GENIO_WT_SHORTCODES
 */
$genio_wt_shortcodes = new GENIO_WT_SHORTCODES();
$genio_wt_shortcodes->run();

/**
 * An instance of validator class
 *
 * @since 1.0
 * @var GENIO_WT_VALIDATOR
 */
$genio_wt_validator = new GENIO_WT_VALIDATOR();

/**
 * An instance of importer class
 *
 * @since 1.0
 * @var GENIO_WT_IMPORTER
 */
$genio_wt_importer = new GENIO_WT_IMPORTER();

/**
 * An instance of core class
 *
 * @since 1.0
 * @var GENIO_WT_CORE
 */
$genio_wt_core = new GENIO_WT_CORE();
$genio_wt_core->run($genio_wt_validator, $genio_wt_importer);

// End of loader.php