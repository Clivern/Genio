<?php
/**
 * Genio - WordPress Theme Core Plugin
 *
 * @version 1.0
 * @package genio-wt
 * @author  Clivern <support@clivern.com>
 * @link    http://clivern.com/
 * @copyright     Copyright (c) 2015, Clivern (http://clivern.com/)
 * @license http://themeforest.net/licenses GPL
 */

class GENIO_WT_CORE
{

	/**
	 * Current stable version
	 * 
	 * @since 1.0
	 * @access private
	 * @var string $this->version
	 */
	public $version = '1.0';

      /**
       * Plugin i18n domain
       * 
       * @since 1.0
       * @access private
       * @var string $this->domain
       */
      private $domain = 'genio_wt_plugin_lang';

     /**
      * Languages rel path
      *
      * @since 1.0
      * @access private
      * @var string $this->rel_path
      */
      private $rel_path = '/genio-wt/langs/';

     /**
      * Absolute or rel path
      *
      * @since 1.0
      * @access private
      * @var boolean $this->abs_rel_path
      */
      private $abs_rel_path = false;

	/**
	 * Remote xml file
	 * 
	 * @since 1.0
	 * @access private
	 * @var string $this->notifier_xml_file
	 */
	private $notifier_xml_file = 'http://clivern.com/wp-content/api/genio-update-notifier.xml';

	/**
	 * Version check cache
	 * 
	 * @since 1.0
	 * @access private
	 * @var string $this->notifier_cache_interval
	 */
	private $notifier_cache_interval = '43200';

	/**
	 * Backend access capability
	 * 
	 * @since 1.0
	 * @access private 
	 * @var string $this->capability
	 */
	public $capability = 'edit_theme_options';

	/**
	 * A list of theme options
	 * 
	 * @since 1.0
	 * @access private
	 * @var array $this->theme_options
	 */
	private $theme_options = array(
		'genio_wt_customize' => array(
			'templates' => array(
				'default' => 'Default',
			),
			'template'=> 'default',
			'logo' => '',
			'favicon' => '/media/images/favicon.png',
			'header_display' => 'site_title',
			'skin' => 'blue',
			'headings_font' => '',
			'main_font' => '',
			'serif_font' => '',
			'custom_styles' => '',
			'blog_header' => '/media/images/backgrounds/blog.jpg',
			'404_header' => '/media/images/backgrounds/blog.jpg',
			'archive_header' => '/media/images/backgrounds/blog.jpg',
			'search_header' =>  '/media/images/backgrounds/blog.jpg',
			'post_header' => '/media/images/backgrounds/blog.jpg',
			'page_header' => '/media/images/backgrounds/blog.jpg',
			'custom_scripts' => '',
			'copyright' => '',
			'facebook' => '',
			'twitter' => 'https://twitter.com',
			'google_plus' => 'https://plus.google.com',
			'behance' => 'https://www.behance.net',
			'dribbble' => 'https://dribbble.com',
			'youtube' => '',
			'flickr' => '',
			'instagram' => '',
			'github' => 'https://github.com',
			'linkedin' => '',
		),
		'genio_wt_basic' => array(
			'version' => '1.0',
			'lastcheck' => '1416845251',
		),

		'genio_wt_default_template' => array(
			'sections_order' => array(
				'home',
				'nav',
				'profile',
				'hobbies',
				'resume',
				'milestones',
				'skills',
				'services',
				'workprocess',
				'portfolio',
				'pricing',
				'clients',
				'blog',
				'testimonials',
				'contact',
			),

			//Menu Title	
			//Show In Menu	
			//Show	
			//Home Style	
			//Background
			//Your image
			//Name
			//Job Title
			'home_s_mt' => 'Home',
			'home_s_sim' => 'yes',
			'home_s_s' => 'yes',
			'home_s_hs' => 'gradient',
			'home_s_bg' => '/media/images/backgrounds/06.jpg',
			'home_s_img' => '/media/images/photo-4.jpg',
			'home_s_n' => 'Patt Miller',
			'home_s_jt' => 'Designer / Developer',

			//show
			'nav_s_s' => 'yes',

			//Menu Title	
			//Show In Menu	
			//Show	
			//Icon	
			//Title	
			//Slogan	
			//Description	
			//Story Title	
			//Story Main	
			//Signature
			//Photo
			//CV
			//Information Title	
			//Your Name	
			//Your Age	
			//Your Phone	
			//Your Email	
			//Your Address
			'profile_s_mt' => 'Profile',
			'profile_s_sim' => 'yes',
			'profile_s_s' => 'yes',
			'profile_s_ic' => 'fa-user',
			'profile_s_tit' => 'Profile',
			'profile_s_slog' => 'My Personal Info',
			'profile_s_desc' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s, when an unknown printer.',
			'profile_s_sto_tit' => 'My Story',
			'profile_s_sto_mai' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer.',
			'profile_s_sign' => '/media/images/signature.png',
			'profile_s_phot' => '/media/images/photo-4.jpg',
			'profile_s_cv' => 'https://www.dropbox.com/',
			'profile_s_inf_tit' => 'Personal Info',
			'profile_s_yo_nam' => 'Patt Miller Doe',
			'profile_s_yo_age' => '23 Years Old',
			'profile_s_yo_phon' => '+123-456-7890',
			'profile_s_yo_emai' => 'hello@site.com',
			'profile_s_yo_addrs' => '1732 Monroe Street Houston, TX 77055',

			//Menu Title	
			//Show In Menu	
			//Show	
			//Title	
			//Slogan	
			//Background
			'hobbies_s_mt' => 'Hobbies',
			'hobbies_s_sim' => 'no',
			'hobbies_s_s' => 'yes',
			'hobbies_s_tit' => 'My Hobbies',
			'hobbies_s_slog' => 'Work Hard, Party Harder',
			'hobbies_s_bg' => '/media/images/backgrounds/03.jpg',

			//Menu Title	
			//Show In Menu	
			//Show	
			//Resume Icon	
			//Description	
			//Education Icon	
			//Education Title	
			//Experience Icon	
			//Experience Title	
			//Recognition Icon	
			//Recognition Title
			'resume_s_mt' => 'Resume',
			'resume_s_sim' => 'yes',
			'resume_s_s' => 'yes',
			'resume_s_res_ic' => 'fa-book',
			'resume_s_tit' => 'Resume',
			'resume_s_slog' => 'Know Who I am',
			'resume_s_desc' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer.',
			'resume_s_ed_ic' => 'fa-graduation-cap',
			'resume_s_ed_tit' => 'Education',
			'resume_s_ex_ic' => 'fa-flask',
			'resume_s_ex_tit' => 'Experience',
			'resume_s_rec_ic' => 'fa-globe',
			'resume_s_rec_tit' => 'Recognition',

			//Menu Title	
			//Show In Menu	
			//Show
			//First, Second, Third and fourth count title icon
			'milesto_s_mt' => 'Milestones',
			'milesto_s_sim' => 'no',
			'milesto_s_s' => 'yes',
			'milesto_fi_ic' => 'fa-users',
			'milesto_fi_tit' => 'Happy Clients',
			'milesto_fi_cou' => '1200',
			'milesto_se_ic' => 'fa-briefcase',
			'milesto_se_tit' => 'Projects Finished',
			'milesto_se_cou' => '1500',
			'milesto_th_ic' => 'fa-clock-o',
			'milesto_th_tit' => 'Years Of Experience',
			'milesto_th_cou' => '10',
			'milesto_fo_ic' => 'fa-code',
			'milesto_fo_tit' => 'Lines Of Code',
			'milesto_fo_cou' => '30M',

			//Menu Title	
			//Show In Menu	
			//Icon	
			//Show	
			//Title	
			//Slogan	
			//Description
			'skills_s_mt' => 'Skills',
			'skills_s_sim' => 'yes',
			'skills_s_ic' => 'fa-pie-chart',
			'skills_s_s' => 'yes',
			'skills_s_tit' => 'Skills',
			'skills_s_slog' => 'How Good I am',
			'skills_s_desc' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer.',

			//Menu Title	
			//Show In Menu	
			//Icon	
			//Show	
			//Title	
			//Slogan	
			//Description
			'services_s_mt' => 'Services',
			'services_s_sim' => 'yes',
			'services_s_ic' => 'fa-cog',
			'services_s_s' => 'yes',
			'services_s_tit' => 'Services',
			'services_s_slog' => 'What My Clients Get',
			'services_s_desc' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer.',
			
			//Menu Title	
			//Show In Menu	
			//Show	
			//Background
			//Title	
			//Slogan
			'process_s_mt' => 'Process',
			'process_s_sim' => 'no',
			'process_s_s' => 'yes',
			'process_s_bg' => '/media/images/backgrounds/04.jpg',
			'process_s_tit' => 'Work Process',
			'process_s_slog' => 'How i work in my projects',

			//Menu Title	
			//Show In Menu
			//Show	
			//Icon	
			//Title	
			//Slogan	
			//Description	
			//Show Only	
			//Link Text
			'blog_s_mt' => 'Blog',
			'blog_s_sim' => 'yes',
			'blog_s_s' => 'yes',
			'blog_s_tit' => 'My Blog',
			'blog_s_slog' => 'All about my latest achievements',
			'blog_s_sh_on' => '3',
			'blog_s_lin_tex' => 'Visit My Blog',

			//Menu Title	
			//Show In Menu
			//show	
			//Icon	
			//Title	
			//Slogan	
			//Description	
			//Show Only	
			//Link Text
			'portfolio_s_mt' => 'Portfolio',
			'portfolio_s_sim' => 'yes',
			'portfolio_s_s' => 'yes',
			'portfolio_s_ic' => 'fa-briefcase',
			'portfolio_s_tit' => 'Work',
			'portfolio_s_slog' => 'Recent Projects',
			'portfolio_s_desc' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer.',
			'portfolio_s_sh_on' => '10',
			'portfolio_s_lin_tex' => 'Show More Items',

			//Menu Title	
			//Show In Menu	
			//Icon	
			//Title	
			//Slogan	
			//Description
			'pricing_s_mt' => 'Pricing',
			'pricing_s_sim' => 'yes',
			'pricing_s_s' => 'yes',
			'pricing_s_ic' => 'fa-dollar',
			'pricing_s_tit' => 'Pricing',
			'pricing_s_slog' => 'Choose Your Package',
			'pricing_s_desc' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer.',

			//Menu Title	
			//Show In Menu	
			//Show	
			//Title	
			//Slogan
			'clients_s_mt' => 'Clients',
			'clients_s_sim' => 'no',
			'clients_s_s' => 'yes',
			'clients_s_tit' => 'Famous Clients',
			'clients_s_slog' => 'Names you definitly know',

			//Menu Title	
			//Show In Menu	
			//Show	
			//Background	
			//Show Only
			'testimonial_s_mt' => 'Testimonials',
			'testimonial_s_sim' => 'yes',
			'testimonial_s_s' => 'yes',
			'testimonial_s_bg' => '/media/images/backgrounds/01.jpg',
			'testimonial_s_sh_on' => '15',

			//Menu Title	
			//Show In Menu
			//show
			//Icon	
			//Title	
			//Slogan	
			//Description	
			//Show Contact Form	
			//Contact Emails	
			//Show Hire Form	
			//Hire Emails
			'contact_s_mt' => 'Contact',
			'contact_s_sim' => 'yes',
			'contact_s_s' => 'yes',
			'contact_s_ic' => 'fa-envelope',
			'contact_s_tit' => 'Contact',
			'contact_s_slog' => 'Get In Touch With Me',
			'contact_s_desc' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer.',
			'contact_s_scf' => 'yes',
			'contact_s_cem' => '',
			'contact_s_shf' => 'yes',
			'contact_s_hem' => '',
		),
	);

	/**
	 * Theme random hash
	 * 
	 * @since 1.0
	 * @access private
	 * @var string $this->rand_hash
	 */
	private $rand_hash = "cr2e8grcg78rvg187796uik171ol7azw676zwd"; 

	/**
	 * Theme menu items screen names
	 *
	 * Used later to register hooks fired on these pages
	 * 
	 * @since 1.0
	 * @access private
	 * @var array $this->theme_menu
	 */
	private $theme_menu;

	/**
	 * Theme updates notifier message
	 * 
	 * @since 1.0
	 * @access private
	 * @var string $this->theme_updates
	 */
	private $theme_updates = '';

	/**
	 * Theme router
	 * 
	 * @since 1.0
	 * @access private
	 * @var array $this->router
	 */
	private $router = array(
		'table' => false,
		'project' => false,
		'skills' => false,
		'resume' => false,
		'hobbies' => false,
		'pricing' => false,
		'work_process' => false,
		'testimoials' => false,
		'clients' => false,
		'services' => false,
		'builder' => false,
		'customizer' => false,
	);

	/**
	 * Current template
	 * 
	 * @since 1.0
	 * @access private
	 * @var string $this->current_template
	 */
	private $current_template = 'default';

	/**
	 * Current template Data
	 * 
	 * @since 1.0
	 * @access private
	 * @var string $this->current_template_data
	 */
	private $current_template_data = false;


	/**
	 * Admin notice iden id
	 *
	 * @since 1.0
	 * @access private
	 * @var boolean|string $this->admin_notice_id
	 */
	private $admin_notice_id = false;

	/**
	 * Used as error indicator for CPT
	 *
	 * @since 1.0
	 * @access private
	 * @var boolean|integer $this->error_indicator
	 */
	private $error_indicator = false;

	/**
	 * An instance of validator class
	 * 
	 * @since 1.0
	 * @access private
	 * @var object $this->validator
	 */
	private $validator;

	/**
	 * An instance of importer class
	 * 
	 * @since 1.0
	 * @access private
	 * @var object $this->importer
	 */
	private $importer;

	/**
	 * Run theme core functions
	 *
	 * @since 1.0
	 * @access public
	 * @param object $validator
	 */
	public function run($validator, $importer)
	{	
		//define depen
		$this->validator = $validator;
		$this->importer = $importer;
		//get options
		$this->getOptions();
		//define router
		$this->router();
		//load template data
		$this->templateLoader();
		
		add_action('init', array(
			&$this,
			'registerPostTypes'
		));

		add_filter( 'bulk_post_updated_messages', array(
			&$this,
			'cptCustomMessages'), 10, 2 );

		add_filter('post_updated_messages', array(
			&$this,
			'cptUpdatedMessages'
		));
		add_filter( 'post_row_actions', array(
			&$this,
			'removeRowActions'), 10, 1 );

		add_action('add_meta_boxes',array(
			&$this,
			'registerPostTypesMetaboxes'
		));
		add_action('save_post',array(
			&$this,
			'saveMetaMetabox'
		));

		//register updater checked
		add_action('admin_init', array(
			&$this,
			'updater'
		));
		//register requests checked
		add_action('admin_init', array(
			&$this,
			'requests'
		));
		//register activation and deactivation
            register_activation_hook( GENIO_WT_ROOT_FILE, array(
                  &$this,
                  'activation'
            ));
            register_deactivation_hook( GENIO_WT_ROOT_FILE, array(
                  &$this,
                  'deactivation'
            ));
            //register i18n
            add_action('plugins_loaded', array(
                  &$this,
                  'translations'
            ));
            //register menu items
		add_action('admin_menu', array(
			&$this,
			'menu'
		));

		//regiser social links
		add_filter( 'user_contactmethods', array(
			&$this,
		 	'addToProfile')
		, 10, 1);

		//delete template action 
		add_action("wp_ajax_delete_template", array(
		 	&$this,
		 	'deleteTemplateAction' 
		));

		//delete template action 
		add_action("wp_ajax_import_demo", array(
		 	&$this,
		 	'importDemoAction' 
		));

		//enqueue and print scripts and styles
		add_action('admin_enqueue_scripts', array(
			&$this,
			'backEnqueue'
		));
		add_action('admin_print_footer_scripts', array(
			&$this,
			'backFooterPrint'
		));
		add_action('admin_head', array(
			&$this,
			'backHeaderPrint'
		));
	}

	/**
	 * Map plugin backend pages
	 *
	 * reduce plugin finger prints
	 *
	 * @since 1.0
	 * @access private
	 */
	private function router()
	{
 		if( (isset($_GET['post_type'])) && (in_array($_GET['post_type'] , array('gen_project','gen_skills','gen_resume','gen_hobbies','gen_pricing','gen_work_process','gen_testimonials','gen_clients','gen_services'))) ){
 			$this->router['table'] = true;
 			$this->router['project'] = (boolean) ($_GET['post_type'] == 'gen_project');
			$this->router['skills'] = (boolean) ($_GET['post_type'] == 'gen_skills');
			$this->router['resume'] = (boolean) ($_GET['post_type'] == 'gen_resume');
			$this->router['hobbies'] = (boolean) ($_GET['post_type'] == 'gen_hobbies');
			$this->router['pricing'] = (boolean) ($_GET['post_type'] == 'gen_pricing');
			$this->router['work_process'] = (boolean) ($_GET['post_type'] == 'gen_work_process');
			$this->router['testimoials'] = (boolean) ($_GET['post_type'] == 'gen_testimonials');
			$this->router['clients'] = (boolean) ($_GET['post_type'] == 'gen_clients');
			$this->router['services'] = (boolean) ($_GET['post_type'] == 'gen_services');
 		}
  		if( (isset($_GET['page'])) && ($_GET['page'] == 'clivern_genio') ){
 			$this->router['builder'] = true;
 			$this->current_template = (isset($_GET['template'])) ? filter_var($_GET['template'], FILTER_SANITIZE_STRING) : false;
 			$this->admin_notice_id = ( (isset($_GET['done'])) && (in_array($_GET['done'], array('1'))) ) ? $_GET['done'] : false;
 		}
 		if( !(isset($_SERVER['PHP_SELF'])) ){
 			$this->router['customizer'] = true;
 		}
 		if( (isset($_SERVER['PHP_SELF'])) && (strrpos($_SERVER['PHP_SELF'], 'customize.php') > 0) ){
 			$this->router['customizer'] = true;
 		}
 		if( (isset($_GET['message'])) && ($_GET['message'] == 200) ){
 			$this->admin_notice_id = 200;
 		}
	}

      /**
       * Plugin activation
       *
       * @since 1.0
       * @access public
       */
      public function activation()
      {
            // validate current wp version
            if ( version_compare(get_bloginfo('version'), '3.9', '<') ) {
                  // too old, DIE!
                  wp_die(__('WordPress Blog Version Must Be Higher Than 3.9 So Please Update Your Blog', $this->domain), 'Genio');
            } else {
            	// Both option add and custom capability
            	// deprecated at plugin activation
            	//$this->addOptions();
			/*$admin_role = get_role('administrator');
			if(!empty($admin_role)){
  				$admin_role->add_cap($this->capability);
 			}*/
 			flush_rewrite_rules();
            }
      }

      /**
       * Plugin deactivation
       * 
       * @since 1.0
       * @access public
       */
      public function deactivation()
      {
      	/*$admin_role = get_role('administrator');
		if(!empty($admin_role)){
 			$admin_role->remove_cap($this->capability);
 		}*/
 		flush_rewrite_rules();
      }

      /**
       * Plugin translation
       *
       * @since 1.0
       * @access public
       */
      public function translations()
      {
            load_plugin_textdomain( $this->domain, $this->abs_rel_path, $this->rel_path );
      }


	/**
	 * Register menu items for plugin
	 *
	 * @since 1.0
	 * @access public
	 */
	public function menu()
	{
		if ( ( string ) $this->theme_options['genio_wt_basic'][ 'version' ] > ( string ) $this->version ) {
			$this->theme_updates = ' <span class="update-plugins count-1"><span class="update-count">' . __('New Updates', $this->domain) . '</span></span>';
		}
		$this->theme_menu = add_theme_page( __('Home Builder', $this->domain), __('Home Builder', $this->domain) . $this->theme_updates, $this->capability, 'clivern_genio', array(
			&$this,
			'renderPage'
		));
		add_action("load-{$this->theme_menu}", array(
			&$this,
			'pageHelp'
		));
		add_action("load-{$this->theme_menu}", array(
			&$this,
			'pageActions'
			), 9);
		add_action("admin_footer-{$this->theme_menu}", array(
			&$this,
			'pageFooter'
		));
		add_action( 'add_meta_boxes', array(
			&$this,
			'pageMetaboxes'
		));
	}

	/**
	 * Render settings page
	 *
	 * @since 1.0
	 * @access public
	 */
	public function renderPage()
	{
		$form_submit_url = ($this->current_template !== false) ? admin_url('themes.php?page=clivern_genio&template=' . $this->current_template) : admin_url('themes.php?page=clivern_genio');
		?>
		<div class='wrap'>
		 <h2>
		  <?php _e('Home Builder', $this->domain) ?>
		 </h2>
		 <form id="genio_settings_form" action="<?php echo esc_url($form_submit_url); ?>" method="post">
		 <?php wp_nonce_field($this->rand_hash) ?>
		 <input type="hidden" name="genio_settings_action" value="fdg682768r7g68387b8g7b3hg7hn39g7n3sd7">
		  <input type="hidden" name="genio_sections_order" id="genio_sections_order" value="<?php echo esc_attr(implode('__', $this->current_template_data['sections_order'])); ?>">
		  <div id="poststuff">
		   <div id="post-body" class="metabox-holder columns-<?php
		   echo 1 == get_current_screen()->get_columns() ? '1' : '2';
		   ?>">
		    <div id="post-body-content">
		     <div id="postbox-container-1" class="postbox-container">
			<?php
			do_meta_boxes($this->theme_menu, 'side', null);
			?>
		     </div>
		     <div id="postbox-container-2" class="postbox-container">
			<?php
			do_meta_boxes($this->theme_menu, 'normal', null);
			?>
			<?php
			do_meta_boxes($this->theme_menu, 'advanced', null);
			?>
		     </div>
		    </div>
		   </div> <!-- #post-body -->
		  </div> <!-- #poststuff -->
		 </form>
		</div>
		<?php
	}

	/**
	 * Page help tab
	 *
	 * @since 1.0
	 * @access public
	 */
	public function pageHelp()
	{
		$screen = get_current_screen();
		if ( $screen->id != $this->theme_menu ) {
			return false;
		}
		//overview metabox help tab
		$screen->add_help_tab(array(
			'id' => 'genio_page_help_overview',
			'title' => __('Overview', $this->domain),
			'content' => sprintf('<br/>%1$s',
				__('Overview Text here.', $this->domain)
			)
		));
		$screen->add_help_tab(array(
			'id' => 'genio_page_help_support',
			'title' => __('Support', $this->domain),
			'content' => sprintf('<br/>%1$s',
				__('Thank you so much for purchasing genio. I would be glad to help you if you have any questions relating to genio . No guarantees, but I will do my best to assist.', $this->domain)
			)
		));
	}
	
	/**
	 * Register metaboxes
	 *
	 * @since 1.0
	 * @access public
	 */
	public function pageActions()
	{
		do_action('add_meta_boxes_' . $this->theme_menu, null);
		do_action('add_meta_boxes', $this->theme_menu, null);
		/* User can choose between 1 or 2 columns (default 2) */
		add_screen_option('layout_columns', array(
		  'max' => 2,
		  'default' => 2
		));
		/* Enqueue WordPress' script for handling the metaboxes */
		wp_enqueue_script('postbox');
	}

	/**
	 * Metabox footer script
	 *
	 * @since 1.0
	 * @access public
	 */
	public function pageFooter()
	{
		?>
		<script> postboxes.add_postbox_toggles(pagenow);</script>
		<?php
	}

	/**
	 * Register metaboxes
	 *
	 * @since 1.0
	 * @access public
	 */
	public function pageMetaboxes()
	{
		add_meta_box('genio-publish-metabox', __('Publish', $this->domain), array(
		  &$this,
		  'publishMetabox'
				), $this->theme_menu, 'side', 'default');
		add_meta_box('genio-delete-metabox', __('Delete Template', $this->domain), array(
		  &$this,
		  'deleteMetabox'
				), $this->theme_menu, 'side', 'default');
		add_meta_box('genio-import-metabox', __('Import Demo', $this->domain), array(
		  &$this,
		  'importMetabox'
				), $this->theme_menu, 'side', 'default');
		add_meta_box('genio-home-metabox', __('Home Section', $this->domain), array(
		  &$this,
		  'homeSectionMetabox'
			    ), $this->theme_menu, 'normal', 'high');
		add_meta_box('genio-nav-metabox', __('Navigation Section', $this->domain), array(
		  &$this,
		  'navSectionMetabox'
			    ), $this->theme_menu, 'normal', 'default');
		add_meta_box('genio-profile-metabox', __('Profile Section', $this->domain), array(
		  &$this,
		  'profileSectionMetabox'
			    ), $this->theme_menu, 'normal', 'default');
		add_meta_box('genio-hobbies-metabox', __('Hobbies Section', $this->domain), array(
		  &$this,
		  'hobbiesSectionMetabox'
			    ), $this->theme_menu, 'normal', 'default');
		add_meta_box('genio-resume-metabox', __('Resume Section', $this->domain), array(
		  &$this,
		  'resumeSectionMetabox'
			    ), $this->theme_menu, 'normal', 'default');
		add_meta_box('genio-milestones-metabox', __('MileStones Section', $this->domain), array(
		  &$this,
		  'mileStonesMetabox'
			    ), $this->theme_menu, 'normal', 'default');
		add_meta_box('genio-skills-metabox', __('Skills Section', $this->domain), array(
		  &$this,
		  'skillsSectionMetabox'
			    ), $this->theme_menu, 'normal', 'default');
		add_meta_box('genio-services-metabox', __('Services Section', $this->domain), array(
		  &$this,
		  'servicesSectionMetabox'
			    ), $this->theme_menu, 'normal', 'default');
		add_meta_box('genio-workprocess-metabox', __('Work Process Section', $this->domain), array(
		  &$this,
		  'workprocessSectionMetabox'
			    ), $this->theme_menu, 'normal', 'default');
		add_meta_box('genio-blog-metabox', __('Blog Section', $this->domain), array(
		  &$this,
		  'blogSectionMetabox'
			    ), $this->theme_menu, 'normal', 'default');
		add_meta_box('genio-portfolio-metabox', __('Portfolio Section', $this->domain), array(
		  &$this,
		  'portfolioSectionMetabox'
			    ), $this->theme_menu, 'normal', 'default');
		add_meta_box('genio-pricing-metabox', __('Pricing Section', $this->domain), array(
		  &$this,
		  'pricingSectionMetabox'
			    ), $this->theme_menu, 'normal', 'default');
		add_meta_box('genio-clients-metabox', __('Clients Section', $this->domain), array(
		  &$this,
		  'clientsSectionMetabox'
			    ), $this->theme_menu, 'normal', 'default');
		add_meta_box('genio-testimonials-metabox', __('Testimonials Section', $this->domain), array(
		  &$this,
		  'testimonialsSectionMetabox'
			    ), $this->theme_menu, 'normal', 'default');
		add_meta_box('genio-contact-metabox', __('Contact Section', $this->domain), array(
		  &$this,
		  'contactSectionMetabox'
			    ), $this->theme_menu, 'normal', 'default');
	}

	/**
	 * Render publish metabox
	 *
	 * @since 1.0
	 * @access public
	 */
	public function publishMetabox()
	{
		?>
            <div id="genio_template_control" style="padding:0 12px 12px;">
             <p><b><?php _e('Current Template', $this->domain); ?></b><br/>
              <select name="genio_current_template" onchange="if (this.value) window.location.href= '<?php echo esc_url(admin_url('themes.php?page=clivern_genio&template=')); ?>' + this.value">
              <?php foreach ($this->theme_options['genio_wt_customize']['templates'] as $key => $value) { ?>
              	<option value="<?php echo esc_attr($key); ?>" <?php selected( $this->current_template, $key, 'true' ); ?>><?php echo $value; ?></option>
              <?php } ?>
              </select></p>
             <p><b><?php _e('Save As', $this->domain); ?></b><br/>
              <select name="genio_template_save_as" id="genio_template_save_as">
              <option value="override"><?php _e('Override Current', $this->domain); ?></option>
               <option value="new"><?php _e('New Template', $this->domain); ?></option>
              </select></p>
             <p id="genio_new_template_wrapper" style="display:none"><b><?php _e('Template Name', $this->domain); ?></b><br/>
              <input name="genio_new_template_name" maxlength="20" type="text" value="" id="genio_new_template_name"> </p>
            </div>
            <div id="major-publishing-actions">
             <div id="delete-action">
              <input type="reset" name="Reset" class="button" style="color:red;" value="<?php esc_attr_e('Reset', $this->domain); ?>">
             </div>
             <div id="publishing-action">
             <span id="spinner_submit" class="spinner" style="display:none;"></span>
              <input type="submit" name="Submit" class="button button-primary button-large" value="<?php esc_attr_e('Save', $this->domain); ?>">
             </div>
             <div class="clear"></div>
            </div>
		<?php
	}

	/**
	 * Render delete metabox
	 *
	 * @since 1.0
	 * @access public
	 */
	public function deleteMetabox()
	{
		?>
		<?php if( count($this->theme_options['genio_wt_customize']['templates']) > 1 ){ ?>
            <div id="delete_template_control" style="padding:0 12px 12px;">
             <p><b><?php _e('Select Template To Delete', $this->domain); ?></b><br/>
              <select name="genio_delete_template" id="genio_delete_template">
              <?php foreach ($this->theme_options['genio_wt_customize']['templates'] as $key => $value) { ?>
              	<?php if($key != 'default'){ ?>
              	<option value="<?php echo esc_attr($key); ?>"><?php echo $value; ?></option>
              	<?php } ?>
              <?php } ?>
              </select></p>
            </div>
            <div id="major-publishing-actions">
             <div id="publishing-action">
             <span id="spinner_delete" class="spinner" style="display:none;"></span>
              <input class="button button-primary button-large" id="template_delete" style="width:100px" value="<?php esc_attr_e('Delete', $this->domain); ?>">
             </div>
             <div class="clear"></div>
            </div>
            <?php }else{ ?>
            <div id="delete_template_control" style="padding:0 12px 12px;">
             <p><b>
            <?php _e('No additional templates exist.', $this->domain); ?>
            </b><br/></p>
            </div>
            <?php } ?>
		<?php
	}

	/**
	 * Render import metabox
	 *
	 * @since 1.0
	 * @access public
	 */
	public function importMetabox()
	{
		?>
            <div id="import_demo_control" style="padding:0 12px 12px;">
             <p id="import_alert_info"><b>
            <?php _e('Do you like to Import Home Data and Demo Home Templates?', $this->domain); ?>
            </b><br/></p>
             <p id="import_alert" style="display:none"></p>
            </div>
            <div id="major-publishing-actions">
             <div id="publishing-action">
             <span id="spinner_import" class="spinner" style="display:none;"></span>
              <input class="button button-primary button-large" id="demo_import" style="width:100px" value="<?php esc_attr_e('Import', $this->domain); ?>">
             </div>
             <div class="clear"></div>
            </div>
		<?php
	}

	/**
	 * Render home section metabox
	 *
	 * @since 1.0
	 * @access public
	 */
	public function homeSectionMetabox()
	{
		?>
            <table class="form-table">
             <tbody>
			<tr>
 				<th scope="row"><label for="genio_home_menu_title"><?php _e('Menu Title', $this->domain); ?></label></th>
 				<td><input name="genio_home_menu_title" maxlength="30" type="text" value="<?php echo esc_attr(stripslashes($this->current_template_data['home_s_mt'])); ?>" id="genio_home_menu_title" class="regular-text">
 				<p class='description'><?php _e('Insert anchor link text that will appear in home menu.', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_home_show_in_menu"><?php _e('Show In Menu', $this->domain); ?></label></th>
 				<td><select name="genio_home_show_in_menu" id="genio_home_show_in_menu">
   					<option value="yes" <?php selected( $this->current_template_data['home_s_sim'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['home_s_sim'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				 <p class='description'><?php _e('Whether to show anchor link in home page menu.', $this->domain); ?></p> 
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_home_show"><?php _e('Show', $this->domain); ?></label></th>
 				<td><select name="genio_home_show" id="genio_home_show">
   					<option value="yes" <?php selected( $this->current_template_data['home_s_s'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['home_s_s'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  					<p class='description'><?php _e('Whether to show home section in your home page.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_home_styles"><?php _e('Style', $this->domain); ?></label></th>
 				<td><select name="genio_home_styles" id="genio_home_styles">
   					<option value="parallax" <?php selected( $this->current_template_data['home_s_hs'], 'parallax', 'true' ); ?>><?php _e('Parallax', $this->domain); ?></option>
   					<option value="bottom_image" <?php selected( $this->current_template_data['home_s_hs'], 'bottom_image', 'true' ); ?>><?php _e('Bottom Image', $this->domain); ?></option>
   					<option value="right_image" <?php selected( $this->current_template_data['home_s_hs'], 'right_image', 'true' ); ?>><?php _e('Right Image', $this->domain); ?></option>
    					<option value="gradient" <?php selected( $this->current_template_data['home_s_hs'], 'gradient', 'true' ); ?>><?php _e('Gradient', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Home section styles.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr id="genio_home_bg_tr">
 				<th scope="row"><label for="genio_home_bg"><?php _e('Background', $this->domain); ?></label></th>
 				<td><input name="genio_home_bg" type="text" maxlength="200" value="<?php echo esc_attr(stripslashes($this->current_template_data['home_s_bg'])); ?>" id="_val_genio_home_bg" class="regular-text"> <a href="#" id="genio_home_bg" class="button">Select Image</a>
 				<p class='description'><?php _e('Select home section background image. recommended size (1920 x 1080).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr id="genio_home_your_photo_tr">
 				<th scope="row"><label for="genio_home_photo"><?php _e('Your Photo', $this->domain); ?></label></th>
 				<td><input name="genio_home_photo" type="text" maxlength="200" value="<?php echo esc_attr(stripslashes($this->current_template_data['home_s_img'])); ?>" id="_val_genio_home_photo" class="regular-text"> <a href="#" id="genio_home_photo" class="button">Select Image</a>
 				<p class='description' id='bottom_img_desc'><?php _e('Select your photo. recommended size (500 x 372).', $this->domain); ?></p>
 				<p class='description' id='right_img_desc'><?php _e('Select your photo. recommended size (max width should be 500px).', $this->domain); ?></p>
 				<p class='description' id='gradient_img_desc'><?php _e('Select your photo. recommended size (500 x 372).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_home_name"><?php _e('Name', $this->domain); ?></label></th>
 				<td><input name="genio_home_name" type="text" maxlength="150" value="<?php echo esc_attr(stripslashes($this->current_template_data['home_s_n'])); ?>" id="genio_home_name" class="regular-text">
 				<p class='description'><?php _e('Insert your name.', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_home_job_title"><?php _e('Job Title', $this->domain); ?></label></th>
 				<td><input name="genio_home_job_title" type="text" maxlength="150" value="<?php echo esc_attr(stripslashes($this->current_template_data['home_s_jt'])); ?>" id="genio_home_job_title" class="regular-text">
 				<p class='description'><?php _e('Insert your job title.', $this->domain); ?></p>
 				</td>
			</tr>
              </tbody>
            </table>
		<?php
	}

	/**
	 * Render navigation section metabox
	 *
	 * @since 1.0
	 * @access public
	 */
	public function navSectionMetabox()
	{
		?>
            <table class="form-table">
             <tbody>
			<tr>
 				<th scope="row"><label for="genio_nav_show"><?php _e('Show', $this->domain); ?></label></th>
 				<td><select name="genio_nav_show" id="genio_nav_show">
   					<option value="yes" <?php selected( $this->current_template_data['nav_s_s'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['nav_s_s'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  					<p class='description'><?php _e('Whether to show navigation menu in your home page.', $this->domain); ?></p>
  				</td>
			</tr>
              </tbody>
            </table>
		<?php
	}

	/**
	 * Render profile section metabox
	 *
	 * @since 1.0
	 * @access public
	 */
	public function profileSectionMetabox()
	{
		$icons_list = $this->fontIcons();
		?>
            <table class="form-table">
             <tbody>
			<tr>
 				<th scope="row"><label for="genio_profile_menu_title"><?php _e('Menu Title', $this->domain); ?></label></th>
 				<td><input name="genio_profile_menu_title" type="text" maxlength="30" value="<?php echo esc_attr(stripslashes($this->current_template_data['profile_s_mt'])); ?>" id="genio_profile_menu_title" class="regular-text">
 					<p class='description'><?php _e('Insert anchor link text that will appear in home menu.', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_profile_show_in_menu"><?php _e('Show In Menu', $this->domain); ?></label></th>
 				<td><select name="genio_profile_show_in_menu" id="genio_profile_show_in_menu">
   					<option value="yes" <?php selected( $this->current_template_data['profile_s_sim'], 'no', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['profile_s_sim'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show anchor link in home page menu.', $this->domain); ?></p> 
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_profile_show"><?php _e('Show', $this->domain); ?></label></th>
 				<td><select name="genio_profile_show" id="genio_profile_show">
   					<option value="yes" <?php selected( $this->current_template_data['profile_s_s'], 'no', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['profile_s_s'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show profile section in your home page.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_profile_icon"><?php _e('Icon', $this->domain); ?></label></th>
 				<td><span class="custom-icon-container" id="genio_profile_icon_show"><i class="fa <?php echo esc_attr($this->current_template_data['profile_s_ic']) ?>"></i></span> <select name="genio_profile_icon" id="genio_profile_icon">
   					<?php foreach ($icons_list as $key => $value){ ?>
   						<?php
						$slug = str_replace(array('fa','-'), array('',' '), $value);
						$slug = ucwords($slug);
   					?>
   						<option value="<?php echo esc_attr($value); ?>" <?php selected( $this->current_template_data['profile_s_ic'], $value, 'true' ); ?>><?php echo $slug ?></option>
   					<?php } ?>
  				</select>
  				<p class='description'><?php _e('Select your favourite icon for this section.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_profile_title"><?php _e('Title', $this->domain); ?></label></th>
 				<td><input name="genio_profile_title" type="text" maxlength="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['profile_s_tit'])); ?>" id="genio_profile_title" class="regular-text">
 				<p class='description'><?php _e('Insert section title (eg.Profile).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_profile_slogan"><?php _e('Slogan', $this->domain); ?></label></th>
 				<td><input name="genio_profile_slogan" type="text"  maxlength="150" value="<?php echo esc_attr(stripslashes($this->current_template_data['profile_s_slog'])); ?>" id="genio_profile_slogan" class="regular-text">
 				<p class='description'><?php _e('Insert section slogan (eg.My Personal Info).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_profile_description"><?php _e('Description', $this->domain); ?></label></th>
 				<td><textarea name="genio_profile_description" type="text" id="genio_profile_description" cols="48" rows="3"><?php echo esc_textarea(stripslashes($this->current_template_data['profile_s_desc'])); ?></textarea>
 				<p class='description'><?php _e('Insert simple description about yourself.', $this->domain); ?></p>
 				</td>
			</tr>

			<tr>
 				<th scope="row"><label for="genio_profile_story_title"><?php _e('Story Title', $this->domain); ?></label></th>
 				<td><input name="genio_profile_story_title" type="text" maxlength="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['profile_s_sto_tit'])); ?>" id="genio_profile_story_title" class="regular-text">
 				<p class='description'><?php _e('Insert story sub-section title (eg. My Story).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_profile_story_main"><?php _e('Story Main', $this->domain); ?></label></th>
 				<td><textarea name="genio_profile_story_main" type="text" id="genio_profile_story_main" cols="48" rows="3"><?php echo esc_textarea(stripslashes($this->current_template_data['profile_s_sto_mai'])); ?></textarea>
 				<p class='description'><?php _e('Insert story sub-section main.', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_profile_signature"><?php _e('Signature', $this->domain); ?></label></th>
 				<td><input name="genio_profile_signature" type="text" maxlength="200" value="<?php echo esc_attr(stripslashes($this->current_template_data['profile_s_sign'])); ?>" id="_val_genio_profile_signature" class="regular-text"> <a href="#" id="genio_profile_signature" class="button">Select Image</a>
 				<p class='description'><?php _e('Select your signature photo.', $this->domain); ?></p>
 				</td>
			</tr>

			<tr>
 				<th scope="row"><label for="genio_profile_photo"><?php _e('Photo', $this->domain); ?></label></th>
 				<td><input name="genio_profile_photo" type="text" maxlength="200" value="<?php echo esc_attr(stripslashes($this->current_template_data['profile_s_phot'])); ?>" id="_val_genio_profile_photo" class="regular-text"> <a href="#" id="genio_profile_photo" class="button">Select Image</a>
 					<p class='description'><?php _e('Select your profile photo. recommended size (500 x 372).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_profile_cv"><?php _e('CV', $this->domain); ?></label></th>
 				<td><input name="genio_profile_cv" type="text" maxlength="200" value="<?php echo esc_attr(stripslashes($this->current_template_data['profile_s_cv'])); ?>" id="_val_genio_profile_cv" class="regular-text"> <a href="#" id="genio_profile_cv" class="button">Select Image</a>
 				<p class='description'><?php _e('Select your CV file. It could be in any format (eg. pdf, image or word)', $this->domain); ?></p>
 				</td>
			</tr>
			
			<tr>
 				<th scope="row"><label for="genio_profile_information_title"><?php _e('Information Title', $this->domain); ?></label></th>
 				<td><input name="genio_profile_information_title" type="text" maxlength="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['profile_s_inf_tit'])); ?>" id="genio_profile_information_title" class="regular-text">
 				<p class='description'><?php _e('Insert information sub-section title (eg. My Info).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_profile_your_name"><?php _e('Your Name', $this->domain); ?></label></th>
 				<td><input name="genio_profile_your_name" type="text" maxlength="100" value="<?php echo esc_attr(stripslashes($this->current_template_data['profile_s_yo_nam'])); ?>" id="genio_profile_your_name" class="regular-text">
 				<p class='description'><?php _e('Insert your full name.', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_profile_your_age"><?php _e('Your Age', $this->domain); ?></label></th>
 				<td><input name="genio_profile_your_age" type="text" maxlength="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['profile_s_yo_age'])); ?>" id="genio_profile_your_age" class="regular-text">
 				<p class='description'><?php _e('Insert your age.', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_profile_your_phone"><?php _e('Your Phone', $this->domain); ?></label></th>
 				<td><input name="genio_profile_your_phone" type="text" maxlength="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['profile_s_yo_phon'])); ?>" id="genio_profile_your_phone" class="regular-text">
 				<p class='description'><?php _e('Insert your phone number.', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_profile_your_email"><?php _e('Your Email', $this->domain); ?></label></th>
 				<td><input name="genio_profile_your_email" type="text" maxlength="60" value="<?php echo esc_attr(stripslashes($this->current_template_data['profile_s_yo_emai'])); ?>" id="genio_profile_your_email" class="regular-text">
 				<p class='description'><?php _e('Insert your email.', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_profile_your_address"><?php _e('Your Address', $this->domain); ?></label></th>
 				<td><input name="genio_profile_your_address" type="text" maxlength="100" value="<?php echo esc_attr(stripslashes($this->current_template_data['profile_s_yo_addrs'])); ?>" id="genio_profile_your_address" class="regular-text">
 				<p class='description'><?php _e('Insert your address.', $this->domain); ?></p>
 				</td>
			</tr>

              </tbody>
            </table>
            <?php
	}

	/**
	 * Render hobbies section metabox
	 *
	 * @since 1.0
	 * @access public
	 */
	public function hobbiesSectionMetabox()
	{
		?>
            <table class="form-table">
             <tbody>
			<tr>
 				<th scope="row"><label for="genio_hobbies_menu_title"><?php _e('Menu Title', $this->domain); ?></label></th>
 				<td><input name="genio_hobbies_menu_title" type="text" maxlength="30" value="<?php echo esc_attr(stripslashes($this->current_template_data['hobbies_s_mt'])); ?>" id="genio_hobbies_menu_title" class="regular-text">
 					<p class='description'><?php _e('Insert anchor link text that will appear in home menu.', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_hobbies_show_in_menu"><?php _e('Show In Menu', $this->domain); ?></label></th>
 				<td><select name="genio_hobbies_show_in_menu" id="genio_hobbies_show_in_menu">
   					<option value="yes" <?php selected( $this->current_template_data['hobbies_s_sim'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['hobbies_s_sim'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show anchor link in home page menu.', $this->domain); ?></p> 
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_hobbies_show"><?php _e('Show', $this->domain); ?></label></th>
 				<td><select name="genio_hobbies_show" id="genio_hobbies_show">
   					<option value="yes" <?php selected( $this->current_template_data['hobbies_s_s'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['hobbies_s_s'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show hobbies section in your home page.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_hobbies_title"><?php _e('Title', $this->domain); ?></label></th>
 				<td><input name="genio_hobbies_title" type="text" maxlength="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['hobbies_s_tit'])); ?>" id="genio_hobbies_title" class="regular-text">
 				<p class='description'><?php _e('Insert section title (eg.My Hobbies).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_hobbies_slogan"><?php _e('Slogan', $this->domain); ?></label></th>
 				<td><input name="genio_hobbies_slogan" type="text" maxlength="150" value="<?php echo esc_attr(stripslashes($this->current_template_data['hobbies_s_slog'])); ?>" id="genio_hobbies_slogan" class="regular-text">
 				<p class='description'><?php _e('Insert section slogan (eg.Work hard, Party harder).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_hobbies_bg"><?php _e('Background', $this->domain); ?></label></th>
 				<td><input name="genio_hobbies_bg" type="text" maxlength="200" value="<?php echo esc_attr(stripslashes($this->current_template_data['hobbies_s_bg'])); ?>" id="_val_genio_hobbies_bg" class="regular-text"> <a href="#" id="genio_hobbies_bg" class="button">Select Image</a>
 				<p class='description'><?php _e('Select background image. recommended size (1920 x 1080).', $this->domain); ?></p>
 				</td>
			</tr>
		</tbody>
		</table>
		<?php
	}

	/**
	 * Render resume section metabox
	 *
	 * @since 1.0
	 * @access public
	 */
	public function resumeSectionMetabox()
	{
		$icons_list = $this->fontIcons();
		?>
            <table class="form-table">
             <tbody>
			<tr>
 				<th scope="row"><label for="genio_resume_menu_title"><?php _e('Menu Title', $this->domain); ?></label></th>
 				<td><input name="genio_resume_menu_title" type="text" maxlength="30" value="<?php echo esc_attr(stripslashes($this->current_template_data['resume_s_mt'])); ?>" id="genio_resume_menu_title" class="regular-text">
 					<p class='description'><?php _e('Insert anchor link text that will appear in home menu.', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_resume_show_in_menu"><?php _e('Show In Menu', $this->domain); ?></label></th>
 				<td><select name="genio_resume_show_in_menu" id="genio_resume_show_in_menu">
   					<option value="yes" <?php selected( $this->current_template_data['resume_s_sim'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['resume_s_sim'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show anchor link in home page menu.', $this->domain); ?></p> 
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_resume_show"><?php _e('Show', $this->domain); ?></label></th>
 				<td><select name="genio_resume_show" id="genio_resume_show">
   					<option value="yes" <?php selected( $this->current_template_data['resume_s_s'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['resume_s_s'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show resume section in your home page.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_resume_icon"><?php _e('Resume Icon', $this->domain); ?></label></th>
 				<td><span class="custom-icon-container" id="genio_resume_icon_show"><i class="fa <?php echo esc_attr($this->current_template_data['resume_s_res_ic']); ?>"></i></span> <select name="genio_resume_icon" id="genio_resume_icon">
   					<?php foreach ($icons_list as $key => $value){ ?>
   						<?php
						$slug = str_replace(array('fa','-'), array('',' '), $value);
						$slug = ucwords($slug);
   					?>
   						<option value="<?php echo esc_attr($value); ?>" <?php selected( $this->current_template_data['resume_s_res_ic'], $value, 'true' ); ?>><?php echo $slug ?></option>
   					<?php } ?>
  				</select>
  					<p class='description'><?php _e('Select your favourite icon for this section.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_resume_title"><?php _e('Title', $this->domain); ?></label></th>
 				<td><input name="genio_resume_title" type="text" maxlength="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['resume_s_tit'])); ?>" id="genio_resume_title" class="regular-text">
 				<p class='description'><?php _e('Insert section title (eg.Resume).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_resume_slogan"><?php _e('Slogan', $this->domain); ?></label></th>
 				<td><input name="genio_resume_slogan" type="text"  maxlength="150" value="<?php echo esc_attr(stripslashes($this->current_template_data['resume_s_slog'])); ?>" id="genio_resume_slogan" class="regular-text">
 				<p class='description'><?php _e('Insert section slogan (eg.Know Who I am).', $this->domain); ?></p>
 				</td>
			</tr>


			<tr>
 				<th scope="row"><label for="genio_resume_description"><?php _e('Description', $this->domain); ?></label></th>
 				<td><textarea name="genio_resume_description" type="text" id="genio_resume_description" cols="48" rows="3"><?php echo esc_textarea(stripslashes($this->current_template_data['resume_s_desc'])); ?></textarea>
 				<p class='description'><?php _e('Insert this section description.', $this->domain); ?></p>
 				</td>
			</tr>

			<tr>
 				<th scope="row"><label for="genio_resume_education_icon"><?php _e('Education Icon', $this->domain); ?></label></th>
 				<td><span class="custom-icon-container" id="genio_resume_education_icon_show"><i class="fa <?php echo esc_attr(stripslashes($this->current_template_data['resume_s_ed_ic'])); ?>"></i></span> <select name="genio_resume_education_icon" id="genio_resume_education_icon">
   					<?php foreach ($icons_list as $key => $value){ ?>
   						<?php
						$slug = str_replace(array('fa','-'), array('',' '), $value);
						$slug = ucwords($slug);
   					?>
   						<option value="<?php echo esc_attr($value); ?>" <?php selected( $this->current_template_data['resume_s_ed_ic'], $value, 'true' ); ?>><?php echo $slug ?></option>
   					<?php } ?>
  				</select>
  				<p class='description'><?php _e('Select your favourite icon for education sub-section.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_resume_education_title"><?php _e('Education Title', $this->domain); ?></label></th>
 				<td><input name="genio_resume_education_title" type="text" maxlength="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['resume_s_ed_tit'])); ?>" id="genio_resume_education_title" class="regular-text">
 				<p class='description'><?php _e('Insert education sub-section title (eg. Education).', $this->domain); ?></p>
 				</td>
			</tr>

			<tr>
 				<th scope="row"><label for="genio_resume_experience_icon"><?php _e('Experience Icon', $this->domain); ?></label></th>
 				<td><span class="custom-icon-container" id="genio_resume_experience_icon_show"><i class="fa <?php echo esc_attr($this->current_template_data['resume_s_ex_ic']) ?>"></i></span> <select name="genio_resume_experience_icon" id="genio_resume_experience_icon">
   					<?php foreach ($icons_list as $key => $value){ ?>
   						<?php
						$slug = str_replace(array('fa','-'), array('',' '), $value);
						$slug = ucwords($slug);
   					?>
   						<option value="<?php echo esc_attr($value); ?>" <?php selected( $this->current_template_data['resume_s_ex_ic'], $value, 'true' ); ?>><?php echo $slug ?></option>
   					<?php } ?>
  				</select>
  				<p class='description'><?php _e('Select your favourite icon for experience sub-section.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_resume_experience_title"><?php _e('Experience Title', $this->domain); ?></label></th>
 				<td><input name="genio_resume_experience_title" type="text" maxlength="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['resume_s_ex_tit'])); ?>" id="genio_resume_experience_title" class="regular-text">
 					<p class='description'><?php _e('Insert experience sub-section title (eg. Experience).', $this->domain); ?></p>
 				</td>
			</tr>

			<tr>
 				<th scope="row"><label for="genio_resume_recognition_icon"><?php _e('Recognition Icon', $this->domain); ?></label></th>
 				<td><span class="custom-icon-container" id="genio_resume_recognition_icon_show"><i class="fa <?php echo esc_attr(stripslashes($this->current_template_data['resume_s_rec_ic'])); ?>"></i></span> <select name="genio_resume_recognition_icon" id="genio_resume_recognition_icon">
   					<?php foreach ($icons_list as $key => $value){ ?>
   						<?php
						$slug = str_replace(array('fa','-'), array('',' '), $value);
						$slug = ucwords($slug);
   					?>
   						<option value="<?php echo esc_attr($value); ?>" <?php selected( $this->current_template_data['resume_s_rec_ic'], $value, 'true' ); ?>><?php echo $slug ?></option>
   					<?php } ?>
  				</select>
  				<p class='description'><?php _e('Select your favourite icon for recognition sub-section.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_resume_recognition_title"><?php _e('Recognition Title', $this->domain); ?></label></th>
 				<td><input name="genio_resume_recognition_title" type="text" maxlength="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['resume_s_rec_tit'])); ?>" id="genio_resume_recognition_title" class="regular-text">
 					<p class='description'><?php _e('Insert recognition sub-section title (eg. Recognition).', $this->domain); ?></p>
 				</td>
			</tr>
		</tbody>
		</table>
		<?php
	}

	/**
	 * Render milestone section metabox
	 * 
	 * @since 1.0
	 * @access public
	 */
	public function mileStonesMetabox()
	{
		//show
		//client icon
		//client number
		//projects icon
		//projects number
		//experience icon
		//experience number
		//code icon
		//codes number
		$icons_list = $this->fontIcons();
		?>
            <table class="form-table">
             <tbody>
			<tr>
 				<th scope="row"><label for="genio_milestone_menu_title"><?php _e('Menu Title', $this->domain); ?></label></th>
 				<td><input name="genio_milestone_menu_title" type="text" maxlength="30" value="<?php echo esc_attr(stripslashes($this->current_template_data['milesto_s_mt'])); ?>" id="genio_milestone_menu_title" class="regular-text">
 					<p class='description'><?php _e('Insert anchor link text that will appear in home menu.', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_milestone_show_in_menu"><?php _e('Show In Menu', $this->domain); ?></label></th>
 				<td><select name="genio_milestone_show_in_menu" id="genio_milestone_show_in_menu">
   					<option value="yes" <?php selected( $this->current_template_data['milesto_s_sim'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['milesto_s_sim'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show anchor link in home page menu.', $this->domain); ?></p> 
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_milestone_show"><?php _e('Show', $this->domain); ?></label></th>
 				<td><select name="genio_milestone_show" id="genio_milestone_show">
   					<option value="yes" <?php selected( $this->current_template_data['milesto_s_s'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['milesto_s_s'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show milestone section in your home page.', $this->domain); ?></p>
  				</td>
			</tr>

			<tr>
 				<th scope="row"><label for="genio_first_box_icon"><?php _e('First Box Icon', $this->domain); ?></label></th>
 				<td><span class="custom-icon-container" id="genio_first_box_icon_show"><i class="fa <?php echo esc_attr($this->current_template_data['milesto_fi_ic']); ?>"></i></span> <select name="genio_first_box_icon" id="genio_first_box_icon">
   					<?php foreach ($icons_list as $key => $value){ ?>
   						<?php
						$slug = str_replace(array('fa','-'), array('',' '), $value);
						$slug = ucwords($slug);
   					?>
   						<option value="<?php echo esc_attr($value); ?>" <?php selected( $this->current_template_data['milesto_fi_ic'], $value, 'true' ); ?>><?php echo $slug ?></option>
   					<?php } ?>
  				</select>
  				<p class='description'><?php _e('Select your favourite icon for first box.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_first_box_title"><?php _e('First Box Title', $this->domain); ?></label></th>
 				<td><input name="genio_first_box_title" type="text" maxlength="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['milesto_fi_tit'])); ?>" id="genio_first_box_title" class="regular-text">
		              <p class='description'><?php _e('Insert first box title (eg. Happy Clients).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_first_box_count"><?php _e('First Box Count', $this->domain); ?></label></th>
 				<td><input name="genio_first_box_count" type="text" maxlength="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['milesto_fi_cou'])); ?>" id="genio_first_box_count" class="regular-text">
 				<p class='description'><?php _e('Insert first box count (eg. 1500).', $this->domain); ?></p>
 				</td>
			</tr>

			<tr>
 				<th scope="row"><label for="genio_second_box_icon"><?php _e('Second Box Icon', $this->domain); ?></label></th>
 				<td><span class="custom-icon-container" id="genio_second_box_icon_show"><i class="fa <?php echo esc_attr($this->current_template_data['milesto_se_ic']); ?>"></i></span> <select name="genio_second_box_icon" id="genio_second_box_icon">
   					<?php foreach ($icons_list as $key => $value){ ?>
   						<?php
						$slug = str_replace(array('fa','-'), array('',' '), $value);
						$slug = ucwords($slug);
   					?>
   						<option value="<?php echo esc_attr($value); ?>" <?php selected( $this->current_template_data['milesto_se_ic'], $value, 'true' ); ?>><?php echo $slug ?></option>
   					<?php } ?>
  				</select>
  				<p class='description'><?php _e('Select your favourite icon for second box.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_second_box_title"><?php _e('Second Box Title', $this->domain); ?></label></th>
 				<td><input name="genio_second_box_title" type="text" maxlength="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['milesto_se_tit'])); ?>" id="genio_second_box_title" class="regular-text">
 				<p class='description'><?php _e('Insert second box title (eg. Projects Finished).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_second_box_count"><?php _e('Second Box Count', $this->domain); ?></label></th>
 				<td><input name="genio_second_box_count" type="text" maxlength="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['milesto_se_cou'])); ?>" id="genio_second_box_count" class="regular-text">
 				<p class='description'><?php _e('Insert second box count (eg. 60).', $this->domain); ?></p>
 				</td>
			</tr>

			<tr>
 				<th scope="row"><label for="genio_third_box_icon"><?php _e('Third Box Icon', $this->domain); ?></label></th>
 				<td><span class="custom-icon-container" id="genio_third_box_icon_show"><i class="fa <?php echo esc_attr($this->current_template_data['milesto_th_ic']) ?>"></i></span> <select name="genio_third_box_icon" id="genio_third_box_icon">
   					<?php foreach ($icons_list as $key => $value){ ?>
   						<?php
						$slug = str_replace(array('fa','-'), array('',' '), $value);
						$slug = ucwords($slug);
   					?>
   						<option value="<?php echo esc_attr($value); ?>" <?php selected( $this->current_template_data['milesto_th_ic'], $value, 'true' ); ?>><?php echo $slug ?></option>
   					<?php } ?>
  				</select>
  				<p class='description'><?php _e('Select your favourite icon for third box.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_third_box_title"><?php _e('Third Box Title', $this->domain); ?></label></th>
 				<td><input name="genio_third_box_title" type="text" maxlength="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['milesto_th_tit'])); ?>" id="genio_third_box_title" class="regular-text">
 				<p class='description'><?php _e('Insert third box title (eg.  Years Of Experience).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_third_box_count"><?php _e('Third Box Count', $this->domain); ?></label></th>
 				<td><input name="genio_third_box_count" type="text" maxlength="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['milesto_th_cou'])); ?>" id="genio_third_box_count" class="regular-text">
 				<p class='description'><?php _e('Insert third box count (eg. 10).', $this->domain); ?></p>
 				</td>
			</tr>


			<tr>
 				<th scope="row"><label for="genio_fourth_box_icon"><?php _e('Fourth Box Icon', $this->domain); ?></label></th>
 				<td><span class="custom-icon-container" id="genio_fourth_box_icon_show"><i class="fa <?php echo esc_attr($this->current_template_data['milesto_fo_ic']) ?>"></i></span> <select name="genio_fourth_box_icon" id="genio_fourth_box_icon">
   					<?php foreach ($icons_list as $key => $value){ ?>
   						<?php
						$slug = str_replace(array('fa','-'), array('',' '), $value);
						$slug = ucwords($slug);
   					?>
   						<option value="<?php echo esc_attr($value); ?>" <?php selected( $this->current_template_data['milesto_fo_ic'], $value, 'true' ); ?>><?php echo $slug ?></option>
   					<?php } ?>
  				</select>
  				<p class='description'><?php _e('Select your favourite icon for fourth box.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_fourth_box_title"><?php _e('Fourth Box Title', $this->domain); ?></label></th>
 				<td><input name="genio_fourth_box_title" type="text" maxlength="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['milesto_fo_tit'])); ?>" id="genio_fourth_box_title" class="regular-text">
 				<p class='description'><?php _e('Insert fourth box title (eg.  Lines Of Code).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_fourth_box_count"><?php _e('Fourth Box Count', $this->domain); ?></label></th>
 				<td><input name="genio_fourth_box_count" type="text" maxlength="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['milesto_fo_cou'])); ?>" id="genio_fourth_box_count" class="regular-text">
 					<p class='description'><?php _e('Insert fourth box count (eg. 30M).', $this->domain); ?></p>
 				</td>
			</tr>
		</tbody>
		</table>
		<?php
	}

	/**
	 * Render skills section metabox
	 *
	 * @since 1.0
	 * @access public
	 */
	public function skillsSectionMetabox()
	{
		$icons_list = $this->fontIcons();
		?>
            <table class="form-table">
             <tbody>
			<tr>
 				<th scope="row"><label for="genio_skills_menu_title"><?php _e('Menu Title', $this->domain); ?></label></th>
 				<td><input name="genio_skills_menu_title" type="text" maxlength="30" value="<?php echo esc_attr(stripslashes($this->current_template_data['skills_s_mt'])); ?>" id="genio_skills_menu_title" class="regular-text">
 					<p class='description'><?php _e('Insert anchor link text that will appear in home menu.', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_skills_show_in_menu"><?php _e('Show In Menu', $this->domain); ?></label></th>
 				<td><select name="genio_skills_show_in_menu" id="genio_skills_show_in_menu">
   					<option value="yes" <?php selected( $this->current_template_data['skills_s_sim'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['skills_s_sim'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show anchor link in home page menu.', $this->domain); ?></p> 
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_skills_show"><?php _e('Show', $this->domain); ?></label></th>
 				<td><select name="genio_skills_show" id="genio_skills_show">
   					<option value="yes" <?php selected( $this->current_template_data['skills_s_s'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['skills_s_s'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show skills section in your home page.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_skills_icon"><?php _e('Icon', $this->domain); ?></label></th>
 				<td><span class="custom-icon-container" id="genio_skills_icon_show"><i class="fa <?php echo esc_attr($this->current_template_data['skills_s_ic']) ?>"></i></span> <select name="genio_skills_icon" id="genio_skills_icon">
   					<?php foreach ($icons_list as $key => $value){ ?>
   						<?php
						$slug = str_replace(array('fa','-'), array('',' '), $value);
						$slug = ucwords($slug);
   					?>
   						<option value="<?php echo esc_attr($value); ?>" <?php selected( $this->current_template_data['skills_s_ic'], $value, 'true' ); ?>><?php echo $slug ?></option>
   					<?php } ?>
  				</select>
  				<p class='description'><?php _e('Select your favourite icon this section.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_skills_title"><?php _e('Title', $this->domain); ?></label></th>
 				<td><input name="genio_skills_title" type="text" maxlength="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['skills_s_tit'])); ?>" id="genio_skills_title" class="regular-text">
 				<p class='description'><?php _e('Insert this section title (eg. Skills).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_skills_slogan"><?php _e('Slogan', $this->domain); ?></label></th>
 				<td><input name="genio_skills_slogan" type="text" maxlength="150" value="<?php echo esc_attr(stripslashes($this->current_template_data['skills_s_slog'])); ?>" id="genio_skills_slogan" class="regular-text">
 				<p class='description'><?php _e('Insert this section slogan (eg. How Good I am).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_skills_description"><?php _e('Description', $this->domain); ?></label></th>
 				<td><textarea name="genio_skills_description" type="text" id="genio_skills_description" cols="48" rows="3"><?php echo esc_textarea(stripslashes($this->current_template_data['skills_s_desc'])); ?></textarea>
 					<p class='description'><?php _e('Insert this section description.', $this->domain); ?></p>
 				</td>
			</tr>
		</tbody>
		</table>
		<?php
	}

	/**
	 * Render services section metabox
	 *
	 * @since 1.0
	 * @access public
	 */
	public function servicesSectionMetabox()
	{
		$icons_list = $this->fontIcons();
		?>
            <table class="form-table">
             <tbody>
			<tr>
 				<th scope="row"><label for="genio_services_menu_title"><?php _e('Menu Title', $this->domain); ?></label></th>
 				<td><input name="genio_services_menu_title" type="text" maxlength="30" value="<?php echo esc_attr(stripslashes($this->current_template_data['services_s_mt'])); ?>" id="genio_services_menu_title" class="regular-text">
 					<p class='description'><?php _e('Insert anchor link text that will appear in home menu.', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_services_show_in_menu"><?php _e('Show In Menu', $this->domain); ?></label></th>
 				<td><select name="genio_services_show_in_menu" id="genio_services_show_in_menu">
   					<option value="yes" <?php selected( $this->current_template_data['services_s_sim'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['services_s_sim'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show anchor link in home page menu.', $this->domain); ?></p> 
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_services_show"><?php _e('Show', $this->domain); ?></label></th>
 				<td><select name="genio_services_show" id="genio_services_show">
   					<option value="yes" <?php selected( $this->current_template_data['services_s_s'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['services_s_s'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show services section in your home page.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_services_icon"><?php _e('Icon', $this->domain); ?></label></th>
 				<td><span class="custom-icon-container" id="genio_services_icon_show"><i class="fa <?php echo esc_attr($this->current_template_data['services_s_ic']) ?>"></i></span> <select name="genio_services_icon" id="genio_services_icon">
   					<?php foreach ($icons_list as $key => $value){ ?>
   						<?php
						$slug = str_replace(array('fa','-'), array('',' '), $value);
						$slug = ucwords($slug);
   					?>
   						<option value="<?php echo esc_attr($value); ?>" <?php selected( $this->current_template_data['services_s_ic'], $value, 'true' ); ?>><?php echo $slug ?></option>
   					<?php } ?>
  				</select>
  				<p class='description'><?php _e('Select your favourite icon this section.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_services_title"><?php _e('Title', $this->domain); ?></label></th>
 				<td><input name="genio_services_title" type="text" maxlenght="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['services_s_tit'])); ?>" id="genio_services_title" class="regular-text">
 				<p class='description'><?php _e('Insert this section title (eg. Services).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_services_slogan"><?php _e('Slogan', $this->domain); ?></label></th>
 				<td><input name="genio_services_slogan" type="text" maxlenght="150" value="<?php echo esc_attr(stripslashes($this->current_template_data['services_s_slog'])); ?>" id="genio_services_slogan" class="regular-text">
 				<p class='description'><?php _e('Insert this section slogan (eg. What My Clients Get).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_services_description"><?php _e('Description', $this->domain); ?></label></th>
 				<td><textarea name="genio_services_description" type="text" id="genio_services_description" cols="48" rows="3"><?php echo esc_textarea(stripslashes($this->current_template_data['services_s_desc'])); ?></textarea>
 					<p class='description'><?php _e('Insert this section description.', $this->domain); ?></p>
 				</td>
			</tr>
		</tbody>
		</table>
		<?php
	}

	/**
	 * Render work process section metabox
	 *
	 * @since 1.0
	 * @access public
	 */
	public function workprocessSectionMetabox()
	{
		?>
            <table class="form-table">
             <tbody>
			<tr>
 				<th scope="row"><label for="genio_workprocess_menu_title"><?php _e('Menu Title', $this->domain); ?></label></th>
 				<td><input name="genio_workprocess_menu_title" type="text" maxlength="30" value="<?php echo esc_attr(stripslashes($this->current_template_data['process_s_mt'])); ?>" id="genio_workprocess_menu_title" class="regular-text">
 					<p class='description'><?php _e('Insert anchor link text that will appear in home menu.', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_workprocess_show_in_menu"><?php _e('Show In Menu', $this->domain); ?></label></th>
 				<td><select name="genio_workprocess_show_in_menu" id="genio_workprocess_show_in_menu">
   					<option value="yes" <?php selected( $this->current_template_data['process_s_sim'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['process_s_sim'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show anchor link in home page menu.', $this->domain); ?></p> 
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_workprocess_show"><?php _e('Show', $this->domain); ?></label></th>
 				<td><select name="genio_workprocess_show" id="genio_workprocess_show">
   					<option value="yes" <?php selected( $this->current_template_data['process_s_s'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['process_s_s'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show services section in your home page.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_workprocess_bg"><?php _e('Background', $this->domain); ?></label></th>
 				<td><input name="genio_workprocess_bg" type="text" maxlenght="200" value="<?php echo esc_attr(stripslashes($this->current_template_data['process_s_bg'])); ?>" id="_val_genio_workprocess_bg" class="regular-text"> <a href="#" id="genio_workprocess_bg" class="button">Select Image</a>
 					<p class='description'><?php _e('Select background image. recommended size (1920 x 1080).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_workprocess_title"><?php _e('Title', $this->domain); ?></label></th>
 				<td><input name="genio_workprocess_title" type="text" maxlenght="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['process_s_tit'])); ?>" id="genio_workprocess_title" class="regular-text">
 					<p class='description'><?php _e('Insert this section title (eg. Work Process).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_workprocess_slogan"><?php _e('Slogan', $this->domain); ?></label></th>
 				<td><input name="genio_workprocess_slogan" type="text" maxlenght="150" value="<?php echo esc_attr(stripslashes($this->current_template_data['process_s_slog'])); ?>" id="genio_workprocess_slogan" class="regular-text">
 					<p class='description'><?php _e('Insert this section slogan (eg. How i work in my projects).', $this->domain); ?></p>
 				</td>
			</tr>
              </tbody>
            </table>
		<?php
	}

	/**
	 * Render blog section metabox
	 *
	 * @since 1.0
	 * @access public
	 */
	public function blogSectionMetabox()
	{
		$icons_list = $this->fontIcons();
		?>
            <table class="form-table">
             <tbody>
			<tr>
 				<th scope="row"><label for="genio_blog_menu_title"><?php _e('Menu Title', $this->domain); ?></label></th>
 				<td><input name="genio_blog_menu_title" type="text" maxlength="30" value="<?php echo esc_attr(stripslashes($this->current_template_data['blog_s_mt'])); ?>" id="genio_blog_menu_title" class="regular-text">
 					<p class='description'><?php _e('Insert anchor link text that will appear in home menu.', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_blog_show_in_menu"><?php _e('Show In Menu', $this->domain); ?></label></th>
 				<td><select name="genio_blog_show_in_menu" id="genio_blog_show_in_menu">
   					<option value="yes" <?php selected( $this->current_template_data['blog_s_sim'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['blog_s_sim'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show anchor link in home page menu.', $this->domain); ?></p> 
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_blog_show"><?php _e('Show', $this->domain); ?></label></th>
 				<td><select name="genio_blog_show" id="genio_blog_show">
   					<option value="yes" <?php selected( $this->current_template_data['blog_s_s'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['blog_s_s'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show blog section in your home page.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_blog_title"><?php _e('Title', $this->domain); ?></label></th>
 				<td><input name="genio_blog_title" type="text" maxlenght="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['blog_s_tit'])); ?>" id="genio_blog_title" class="regular-text">
 				<p class='description'><?php _e('Insert this section title (eg. Blog).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_blog_slogan"><?php _e('Slogan', $this->domain); ?></label></th>
 				<td><input name="genio_blog_slogan" type="text" maxlenght="150" value="<?php echo esc_attr(stripslashes($this->current_template_data['blog_s_slog'])); ?>" id="genio_blog_slogan" class="regular-text">
 				<p class='description'><?php _e('Insert this section slogan (eg. A bit of my journal).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_blog_count"><?php _e('Show Only', $this->domain); ?></label></th>
 				<td><select name="genio_blog_count" id="genio_blog_count">
   					<option value="1" <?php selected( $this->current_template_data['blog_s_sh_on'], '1', 'true' ); ?>><?php _e('1', $this->domain); ?></option>
   					<option value="2" <?php selected( $this->current_template_data['blog_s_sh_on'], '2', 'true' ); ?>><?php _e('2', $this->domain); ?></option>
   					<option value="3" <?php selected( $this->current_template_data['blog_s_sh_on'], '3', 'true' ); ?>><?php _e('3', $this->domain); ?></option>
   					<option value="4" <?php selected( $this->current_template_data['blog_s_sh_on'], '4', 'true' ); ?>><?php _e('4', $this->domain); ?></option>
   					<option value="5" <?php selected( $this->current_template_data['blog_s_sh_on'], '5', 'true' ); ?>><?php _e('5', $this->domain); ?></option>
   					<option value="6" <?php selected( $this->current_template_data['blog_s_sh_on'], '6', 'true' ); ?>><?php _e('6', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Number of posts to show in your home.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_blog_link_text"><?php _e('Link Text', $this->domain); ?></label></th>
 				<td><input name="genio_blog_link_text" type="text" maxlenght="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['blog_s_lin_tex'])); ?>" id="genio_blog_link_text" class="regular-text">
 				<p class='description'><?php _e('Visit blog link text (eg. Visit My Blog).', $this->domain); ?></p>
 				</td>
			</tr>
		</tbody>
		</table>
		<?php
	}

	/**
	 * Render portfolio section metabox
	 *
	 * @since 1.0
	 * @access public
	 */
	public function portfolioSectionMetabox()
	{
		$icons_list = $this->fontIcons();
		?>
            <table class="form-table">
             <tbody>
			<tr>
 				<th scope="row"><label for="genio_portfolio_menu_title"><?php _e('Menu Title', $this->domain); ?></label></th>
 				<td><input name="genio_portfolio_menu_title" type="text" maxlength="30" value="<?php echo esc_attr(stripslashes($this->current_template_data['portfolio_s_mt'])); ?>" id="genio_portfolio_menu_title" class="regular-text">
 					<p class='description'><?php _e('Insert anchor link text that will appear in home menu.', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_portfolio_show_in_menu"><?php _e('Show In Menu', $this->domain); ?></label></th>
 				<td><select name="genio_portfolio_show_in_menu" id="genio_portfolio_show_in_menu">
   					<option value="yes" <?php selected( $this->current_template_data['portfolio_s_sim'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['portfolio_s_sim'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show anchor link in home page menu.', $this->domain); ?></p> 
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_portfolio_show"><?php _e('Show', $this->domain); ?></label></th>
 				<td><select name="genio_portfolio_show" id="genio_portfolio_show">
   					<option value="yes" <?php selected( $this->current_template_data['portfolio_s_s'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['portfolio_s_s'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show portfolio section in your home page.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_portfolio_icon"><?php _e('Icon', $this->domain); ?></label></th>
 				<td><span class="custom-icon-container" id="genio_portfolio_icon_show"><i class="fa <?php echo esc_attr($this->current_template_data['portfolio_s_ic']) ?>"></i></span> <select name="genio_portfolio_icon" id="genio_portfolio_icon">
   					<?php foreach ($icons_list as $key => $value){ ?>
   						<?php
						$slug = str_replace(array('fa','-'), array('',' '), $value);
						$slug = ucwords($slug);
   					?>
   						<option value="<?php echo esc_attr($value); ?>" <?php selected( $this->current_template_data['portfolio_s_ic'], $value, 'true' ); ?>><?php echo $slug ?></option>
   					<?php } ?>
  				</select>
  				<p class='description'><?php _e('Select your favourite icon this section.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_portfolio_title"><?php _e('Title', $this->domain); ?></label></th>
 				<td><input name="genio_portfolio_title" type="text" maxlenght="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['portfolio_s_tit'])); ?>" id="genio_portfolio_title" class="regular-text">
 				<p class='description'><?php _e('Insert this section title (eg. Portfolio).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_portfolio_slogan"><?php _e('Slogan', $this->domain); ?></label></th>
 				<td><input name="genio_portfolio_slogan" type="text" maxlenght="150" value="<?php echo esc_attr(stripslashes($this->current_template_data['portfolio_s_slog'])); ?>" id="genio_portfolio_slogan" class="regular-text">
 					<p class='description'><?php _e('Insert this section slogan (eg. Recent Projects).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_portfolio_description"><?php _e('Description', $this->domain); ?></label></th>
 				<td><textarea name="genio_portfolio_description" type="text" id="genio_portfolio_description" cols="48" rows="3"><?php echo esc_textarea(stripslashes($this->current_template_data['portfolio_s_desc'])); ?></textarea>
 					<p class='description'><?php _e('Insert this section description.', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_portfolio_count"><?php _e('Show Only', $this->domain); ?></label></th>
 				<td><select name="genio_portfolio_count" id="genio_portfolio_count">
   					<option value="5" <?php selected( $this->current_template_data['portfolio_s_sh_on'], '5', 'true' ); ?>><?php _e('5', $this->domain); ?></option>
   					<option value="10" <?php selected( $this->current_template_data['portfolio_s_sh_on'], '10', 'true' ); ?>><?php _e('10', $this->domain); ?></option>
   					<option value="15" <?php selected( $this->current_template_data['portfolio_s_sh_on'], '15', 'true' ); ?>><?php _e('15', $this->domain); ?></option>
   					<option value="20" <?php selected( $this->current_template_data['portfolio_s_sh_on'], '20', 'true' ); ?>><?php _e('20', $this->domain); ?></option>
   					<option value="25" <?php selected( $this->current_template_data['portfolio_s_sh_on'], '25', 'true' ); ?>><?php _e('25', $this->domain); ?></option>
   					<option value="30" <?php selected( $this->current_template_data['portfolio_s_sh_on'], '30', 'true' ); ?>><?php _e('30', $this->domain); ?></option>
  				   	<option value="all" <?php selected( $this->current_template_data['portfolio_s_sh_on'], 'all', 'true' ); ?>><?php _e('All', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Number of projects to be shown in your home and the rest will use lazy load.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_portfolio_link_text"><?php _e('Link Text', $this->domain); ?></label></th>
 				<td><input name="genio_portfolio_link_text" type="text" maxlenght="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['portfolio_s_lin_tex'])); ?>" id="genio_portfolio_link_text" class="regular-text">
 				<p class='description'><?php _e('Visit portfolio link text (eg. Load More).', $this->domain); ?></p>
 				</td>
			</tr>
		</tbody>
		</table>
		<?php
	}

	/**
	 * Render pricing section metabox
	 *
	 * @since 1.0
	 * @access public
	 */
	public function pricingSectionMetabox()
	{
		$icons_list = $this->fontIcons();
		?>
            <table class="form-table">
             <tbody>
			<tr>
 				<th scope="row"><label for="genio_pricing_menu_title"><?php _e('Menu Title', $this->domain); ?></label></th>
 				<td><input name="genio_pricing_menu_title" type="text" maxlength="30" value="<?php echo esc_attr(stripslashes($this->current_template_data['pricing_s_mt'])); ?>" id="genio_pricing_menu_title" class="regular-text">
 					<p class='description'><?php _e('Insert anchor link text that will appear in home menu.', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_pricing_show_in_menu"><?php _e('Show In Menu', $this->domain); ?></label></th>
 				<td><select name="genio_pricing_show_in_menu" id="genio_pricing_show_in_menu">
   					<option value="yes" <?php selected( $this->current_template_data['pricing_s_sim'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['pricing_s_sim'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show anchor link in home page menu.', $this->domain); ?></p> 
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_pricing_show"><?php _e('Show', $this->domain); ?></label></th>
 				<td><select name="genio_pricing_show" id="genio_pricing_show">
   					<option value="yes" <?php selected( $this->current_template_data['pricing_s_s'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['pricing_s_s'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show pricing section in your home page.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_pricing_icon"><?php _e('Icon', $this->domain); ?></label></th>
 				<td><span class="custom-icon-container" id="genio_pricing_icon_show"><i class="fa <?php echo esc_attr($this->current_template_data['pricing_s_ic']) ?>"></i></span> <select name="genio_pricing_icon" id="genio_pricing_icon">
   					<?php foreach ($icons_list as $key => $value){ ?>
   						<?php
						$slug = str_replace(array('fa','-'), array('',' '), $value);
						$slug = ucwords($slug);
   					?>
   						<option value="<?php echo esc_attr($value); ?>" <?php selected( $this->current_template_data['pricing_s_ic'], $value, 'true' ); ?>><?php echo $slug ?></option>
   					<?php } ?>
  				</select>
  				<p class='description'><?php _e('Select your favourite icon this section.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_pricing_title"><?php _e('Title', $this->domain); ?></label></th>
 				<td><input name="genio_pricing_title" type="text" maxlenght="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['pricing_s_tit'])); ?>" id="genio_pricing_title" class="regular-text">
 				<p class='description'><?php _e('Insert this section title (eg. Pricing).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_pricing_slogan"><?php _e('Slogan', $this->domain); ?></label></th>
 				<td><input name="genio_pricing_slogan" type="text" maxlenght="150" value="<?php echo esc_attr(stripslashes($this->current_template_data['pricing_s_slog'])); ?>" id="genio_pricing_slogan" class="regular-text">
 				<p class='description'><?php _e('Insert this section slogan (eg. Choose Your Package).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_pricing_description"><?php _e('Description', $this->domain); ?></label></th>
 				<td><textarea name="genio_pricing_description" type="text" id="genio_pricing_description" cols="48" rows="3"><?php echo esc_textarea(stripslashes($this->current_template_data['pricing_s_desc'])); ?></textarea>
 					<p class='description'><?php _e('Insert this section description.', $this->domain); ?></p>
 				</td>
			</tr>
              </tbody>
            </table>
		<?php
	}

	/**
	 * Render clients section metabox
	 *
	 * @since 1.0
	 * @access public
	 */
	public function clientsSectionMetabox()
	{
		?>
            <table class="form-table">
             <tbody>
			<tr>
 				<th scope="row"><label for="genio_clients_menu_title"><?php _e('Menu Title', $this->domain); ?></label></th>
 				<td><input name="genio_clients_menu_title" type="text" maxlength="30" value="<?php echo esc_attr(stripslashes($this->current_template_data['clients_s_mt'])); ?>" id="genio_clients_menu_title" class="regular-text">
 					<p class='description'><?php _e('Insert anchor link text that will appear in home menu.', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_clients_show_in_menu"><?php _e('Show In Menu', $this->domain); ?></label></th>
 				<td><select name="genio_clients_show_in_menu" id="genio_clients_show_in_menu">
   					<option value="yes" <?php selected( $this->current_template_data['clients_s_sim'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['clients_s_sim'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show anchor link in home page menu.', $this->domain); ?></p> 
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_clients_show"><?php _e('Show', $this->domain); ?></label></th>
 				<td><select name="genio_clients_show" id="genio_clients_show">
   					<option value="yes" <?php selected( $this->current_template_data['clients_s_s'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['clients_s_s'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show clients section in your home page.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_clients_title"><?php _e('Title', $this->domain); ?></label></th>
 				<td><input name="genio_clients_title" type="text" maxlenght="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['clients_s_tit'])); ?>" id="genio_clients_title" class="regular-text">
 				<p class='description'><?php _e('Insert this section title (eg. Clients).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_clients_slogan"><?php _e('Slogan', $this->domain); ?></label></th>
 				<td><input name="genio_clients_slogan" type="text" maxlenght="150" value="<?php echo esc_attr(stripslashes($this->current_template_data['clients_s_slog'])); ?>" id="genio_clients_slogan" class="regular-text">
 				<p class='description'><?php _e('Insert this section slogan (eg. Names you definitly know).', $this->domain); ?></p>
 				</td>
			</tr>
		</tbody>
		</table>
		<?php
	}

	/**
	 * Render testimonials section metabox
	 *
	 * @since 1.0
	 * @access public
	 */
	public function testimonialsSectionMetabox()
	{
		?>
            <table class="form-table">
             <tbody>
			<tr>
 				<th scope="row"><label for="genio_testimonials_menu_title"><?php _e('Menu Title', $this->domain); ?></label></th>
 				<td><input name="genio_testimonials_menu_title" type="text" maxlength="30" value="<?php echo esc_attr(stripslashes($this->current_template_data['testimonial_s_mt'])); ?>" id="genio_testimonials_menu_title" class="regular-text">
 					<p class='description'><?php _e('Insert anchor link text that will appear in home menu.', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_testimonials_show_in_menu"><?php _e('Show In Menu', $this->domain); ?></label></th>
 				<td><select name="genio_testimonials_show_in_menu" id="genio_testimonials_show_in_menu">
   					<option value="yes" <?php selected( $this->current_template_data['testimonial_s_sim'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['testimonial_s_sim'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show anchor link in home page menu.', $this->domain); ?></p> 
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_testimonials_show"><?php _e('Show', $this->domain); ?></label></th>
 				<td><select name="genio_testimonials_show" id="genio_testimonials_show">
   					<option value="yes" <?php selected( $this->current_template_data['testimonial_s_s'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['testimonial_s_s'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show testimonials section in your home page.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_testimonials_bg"><?php _e('Background', $this->domain); ?></label></th>
 				<td><input name="genio_testimonials_bg" type="text" maxlenght="200" value="<?php echo esc_attr(stripslashes($this->current_template_data['testimonial_s_bg'])); ?>" id="_val_genio_testimonials_bg" class="regular-text"> <a href="#" id="genio_testimonials_bg" class="button">Select Image</a>
 					<p class='description'><?php _e('Select background image. recommended size (1920 x 1080).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_testimonials_count"><?php _e('Show Only', $this->domain); ?></label></th>
 				<td><select name="genio_testimonials_count" id="genio_testimonials_count">
   					<option value="5" <?php selected( $this->current_template_data['testimonial_s_sh_on'], '5', 'true' ); ?>><?php _e('5', $this->domain); ?></option>
   					<option value="10" <?php selected( $this->current_template_data['testimonial_s_sh_on'], '10', 'true' ); ?>><?php _e('10', $this->domain); ?></option>
   					<option value="15" <?php selected( $this->current_template_data['testimonial_s_sh_on'], '15', 'true' ); ?>><?php _e('15', $this->domain); ?></option>
   					<option value="20" <?php selected( $this->current_template_data['testimonial_s_sh_on'], '20', 'true' ); ?>><?php _e('20', $this->domain); ?></option>
   					<option value="25" <?php selected( $this->current_template_data['testimonial_s_sh_on'], '25', 'true' ); ?>><?php _e('25', $this->domain); ?></option>
   					<option value="30" <?php selected( $this->current_template_data['testimonial_s_sh_on'], '30', 'true' ); ?>><?php _e('30', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Number of testimonials to show in your home.', $this->domain); ?></p>
  				</td>
			</tr>
              </tbody>
            </table>
		<?php
	}

	/**
	 * Render contact section metabox
	 *
	 * @since 1.0
	 * @access public
	 */
	public function contactSectionMetabox()
	{
		$icons_list = $this->fontIcons();
		?>
            <table class="form-table">
             <tbody>
			<tr>
 				<th scope="row"><label for="genio_contact_menu_title"><?php _e('Menu Title', $this->domain); ?></label></th>
 				<td><input name="genio_contact_menu_title" type="text" maxlength="30" value="<?php echo esc_attr(stripslashes($this->current_template_data['contact_s_mt'])); ?>" id="genio_contact_menu_title" class="regular-text">
 					<p class='description'><?php _e('Insert anchor link text that will appear in home menu.', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_contact_show_in_menu"><?php _e('Show In Menu', $this->domain); ?></label></th>
 				<td><select name="genio_contact_show_in_menu" id="genio_contact_show_in_menu">
   					<option value="yes" <?php selected( $this->current_template_data['contact_s_sim'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['contact_s_sim'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show anchor link in home page menu.', $this->domain); ?></p> 
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_contact_show"><?php _e('Show', $this->domain); ?></label></th>
 				<td><select name="genio_contact_show" id="genio_contact_show">
   					<option value="yes" <?php selected( $this->current_template_data['contact_s_s'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['contact_s_s'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show contact section in your home page.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_contact_icon"><?php _e('Icon', $this->domain); ?></label></th>
 				<td><span class="custom-icon-container" id="genio_contact_icon_show"><i class="fa <?php echo esc_attr($this->current_template_data['contact_s_ic']) ?>"></i></span> <select name="genio_contact_icon" id="genio_contact_icon">
   					<?php foreach ($icons_list as $key => $value){ ?>
   						<?php
						$slug = str_replace(array('fa','-'), array('',' '), $value);
						$slug = ucwords($slug);
   					?>
   						<option value="<?php echo esc_attr($value); ?>" <?php selected( $this->current_template_data['contact_s_ic'], $value, 'true' ); ?>><?php echo $slug ?></option>
   					<?php } ?>
  				</select>
  				<p class='description'><?php _e('Select your favourite icon this section.', $this->domain); ?></p>
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_contact_title"><?php _e('Title', $this->domain); ?></label></th>
 				<td><input name="genio_contact_title" type="text" maxlength="50" value="<?php echo esc_attr(stripslashes($this->current_template_data['contact_s_tit'])); ?>" id="genio_contact_title" class="regular-text">
 					<p class='description'><?php _e('Insert this section title (eg. Contact).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_contact_slogan"><?php _e('Slogan', $this->domain); ?></label></th>
 				<td><input name="genio_contact_slogan" type="text" maxlength="150" value="<?php echo esc_attr(stripslashes($this->current_template_data['contact_s_slog'])); ?>" id="genio_contact_slogan" class="regular-text">
 					<p class='description'><?php _e('Insert this section slogan (eg. Get In Touch With Me).', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_contact_description"><?php _e('Description', $this->domain); ?></label></th>
 				<td><textarea name="genio_contact_description" type="text" id="genio_contact_description" cols="48" rows="3"><?php echo esc_textarea(stripslashes($this->current_template_data['contact_s_desc'])); ?></textarea>
 					<p class='description'><?php _e('Insert this section description.', $this->domain); ?></p>
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_contact_form_show"><?php _e('Show Contact Form', $this->domain); ?></label></th>
 				<td><select name="genio_contact_form_show" id="genio_contact_form_show">
   					<option value="yes" <?php selected( $this->current_template_data['contact_s_scf'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['contact_s_scf'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show contact form.', $this->domain); ?></p> 
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_contact_email"><?php _e('Contact Email', $this->domain); ?></label></th>
 				<td><input name="genio_contact_email" type="text" maxlength="60" value="<?php echo esc_attr(stripslashes($this->current_template_data['contact_s_cem'])); ?>" id="genio_contact_email" class="regular-text">
 					<p class='description'><?php _e('Email to send contact messages.', $this->domain); ?></p> 
 				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_hireme_form_show"><?php _e('Show Hire Form', $this->domain); ?></label></th>
 				<td><select name="genio_hireme_form_show" id="genio_hireme_form_show">
   					<option value="yes" <?php selected( $this->current_template_data['contact_s_shf'], 'yes', 'true' ); ?>><?php _e('Yes', $this->domain); ?></option>
   					<option value="no" <?php selected( $this->current_template_data['contact_s_shf'], 'no', 'true' ); ?>><?php _e('No', $this->domain); ?></option>
  				</select>
  				<p class='description'><?php _e('Whether to show hire me form.', $this->domain); ?></p> 
  				</td>
			</tr>
			<tr>
 				<th scope="row"><label for="genio_hireme_email"><?php _e('Hire Email', $this->domain); ?></label></th>
 				<td><input name="genio_hireme_email" type="text" maxlength="60" value="<?php echo esc_attr(stripslashes($this->current_template_data['contact_s_hem'])); ?>" id="genio_hireme_email" class="regular-text">
 				<p class='description'><?php _e('Email to send hire me messages.', $this->domain); ?></p> 
 				</td>
			</tr>
              </tbody>
            </table>
		<?php
	}

	/**
	 * Register portfolio post type
	 *
	 * @since 1.0
	 * @access public
	 */
	public function registerPostTypes()
	{
		# Capabilities list
		$capabilities = array(
			'edit_post'           => $this->capability,
			'read_post'           => $this->capability,
			'delete_post'         => $this->capability,
			'delete_posts'        => $this->capability,
			'edit_posts'          => $this->capability,
			'edit_others_posts'   => $this->capability,
			'delete_others_posts' => $this->capability,
			'publish_posts'       => $this->capability,
			'read_private_posts'  => $this->capability,
		);
		# Portfolio UI labels
		$labels = array(
			'name'                => __( 'Portfolio', $this->domain ),
			'singular_name'       => __( 'Project', $this->domain ),
			'add_new'             => _x( 'Add New', 'project', $this->domain ),
			'add_new_item'        => __( 'Add New Project', $this->domain ),
			'edit_item'           => __( 'Edit Project', $this->domain ),
			'new_item'            => __( 'New Project', $this->domain ),
			'view_item'           => __( 'View Project', $this->domain ),
			'search_items'        => __( 'Search Projects', $this->domain ),
			'not_found'           => __( 'No Projects found', $this->domain ),
			'not_found_in_trash'  => __( 'No Projects found in Trash', $this->domain ),
			'parent_item_colon'   => __( 'Parent Project:', $this->domain ),
			'menu_name'           => __( 'Portfolio', $this->domain ),
		);
		# Portfolio post type args
		$args = array(
			'labels'              => $labels,
			'public'              => true,
			'publicly_queryable'  => true,
			'exclude_from_search' => false,
			'show_in_admin_bar'   => true,
			'show_in_nav_menus'   => false,
			'show_in_menu'        => null,
			'menu_position'       => 25,
			'menu_icon'           => 'dashicons-text',
			'rewrite' => array( 'slug' => 'portfolio' ),
			'capabilities'        => $capabilities,
			'supports'            => array(
				'title', 'editor', 'thumbnail'
			),
			'hierarchical'        => false,
			'has_archive'         => true,
			'query_var'           => 'project',
			'can_export'          => true,
		);
		# Register portfolio post type
		register_post_type( 'gen_project', $args );

		# Skill post type labels
		$labels = array(
			'name'                => __( 'Skills', $this->domain ),
			'singular_name'       => __( 'Skill', $this->domain ),
			'add_new'             => _x( 'Add New', 'skill', $this->domain ),
			'add_new_item'        => __( 'Add New Skill', $this->domain ),
			'edit_item'           => __( 'Edit Skill', $this->domain ),
			'new_item'            => __( 'New Skill', $this->domain ),
			'view_item'           => __( 'View Skill', $this->domain ),
			'search_items'        => __( 'Search Skills', $this->domain ),
			'not_found'           => __( 'No Skill found', $this->domain ),
			'not_found_in_trash'  => __( 'No Skill found in Trash', $this->domain ),
			'parent_item_colon'   => __( 'Parent Skill:', $this->domain ),
			'menu_name'           => __( 'Skills', $this->domain ),
		);
		# Skills post type args
		$args = array(
			'labels'              => $labels,
			'public'              => false,
			'show_ui'             => true,
			'publicly_queryable'  => true,
			'exclude_from_search' => true,
			'show_in_admin_bar'   => false,
			'show_in_nav_menus'   => false,
			'show_in_menu'        => 'edit.php?post_type=gen_project',
			'rewrite'             => false,
			'capabilities'        => $capabilities,
			'supports'            => array(
				'title'
			),
			'hierarchical'        => false,
			'has_archive'         => false,
			'query_var'           => false,
			'can_export'          => true,
		);
		# Register skill port type
		register_post_type( 'gen_skills', $args );
		
		# Category taxonomy labels
		$labels = array(
			'name'				=> _x( 'Category', 'Categoies', $this->domain ),
			'singular_name'			=> _x( 'Category', 'Categoies', $this->domain ),
			'search_items'			=> __( 'Search Categories', $this->domain ),
			'popular_items'			=> __( 'Popular Categories', $this->domain ),
			'all_items'				=> __( 'All Categories', $this->domain ),
			'parent_item'			=> __( 'Parent Category', $this->domain ),
			'parent_item_colon'		=> __( 'Parent Category', $this->domain ),
			'edit_item'				=> __( 'Edit Category', $this->domain ),
			'update_item'			=> __( 'Update Category', $this->domain ),
			'add_new_item'			=> __( 'Add New Category', $this->domain ),
			'new_item_name'			=> __( 'New Category', $this->domain ),
			'add_or_remove_items'	=> __( 'Add or remove Categories', $this->domain ),
			'choose_from_most_used'	=> __( 'Choose from most used categories', $this->domain ),
			'menu_name'				=> __( 'Categories', $this->domain ),
		);
		# Category taxonomy args
		$args = array(
			'labels'            => $labels,
			'public'            => true,
			'show_in_nav_menus' => false,
			'show_admin_column' => true,
			'hierarchical'      => true,
			'show_ui'           => true,
			'query_var'         => false,
			'rewrite'           => false,
			'capabilities'      => array(
				'manage_terms'           => $this->capability,
				'edit_terms'           => $this->capability,
				'delete_terms'           => $this->capability,
				'assign_terms'           => $this->capability,
			),
		);
		# Register category custom taxonomy
		register_taxonomy( 'gen_proj_sk_categ', array( 'gen_project', 'gen_skills' ), $args );

		# Resume custom post type labels
		$labels = array(
			'name'                => __( 'Resume', $this->domain ),
			'singular_name'       => __( 'Item', $this->domain ),
			'add_new'             => _x( 'Add New', 'project', $this->domain ),
			'add_new_item'        => __( 'Add New Item', $this->domain ),
			'edit_item'           => __( 'Edit Item', $this->domain ),
			'new_item'            => __( 'New Item', $this->domain ),
			'view_item'           => __( 'View Item', $this->domain ),
			'search_items'        => __( 'Search Projects', $this->domain ),
			'not_found'           => __( 'No Items found', $this->domain ),
			'not_found_in_trash'  => __( 'No Items found in Trash', $this->domain ),
			'parent_item_colon'   => __( 'Parent Item:', $this->domain ),
			'menu_name'           => __( 'Resume', $this->domain ),
		);
		# Resume custom post type args
		$args = array(
			'labels'              => $labels,
			'public'              => false,
			'show_ui'             => true,
			'publicly_queryable'  => true,
			'exclude_from_search' => true,
			'show_in_admin_bar'   => false,
			'show_in_nav_menus'   => false,
			'show_in_menu'        => 'edit.php?post_type=gen_project',
			'rewrite'             => false,
			'capabilities'        => $capabilities,
			'supports'            => array(
				'title'
			),
			'hierarchical'        => false,
			'has_archive'         => false,
			'query_var'           => false,
			'can_export'          => true,
		);
		# Regsiter resume custom post type
		register_post_type( 'gen_resume', $args );
		
		# Hobbies custom post type labels
		$labels = array(
			'name'                => __( 'Hobbies', $this->domain ),
			'singular_name'       => __( 'Hobby', $this->domain ),
			'add_new'             => _x( 'Add New', 'hobby', $this->domain ),
			'add_new_item'        => __( 'Add New Hobby', $this->domain ),
			'edit_item'           => __( 'Edit Hobby', $this->domain ),
			'new_item'            => __( 'New Hobby', $this->domain ),
			'view_item'           => __( 'View Hobby', $this->domain ),
			'search_items'        => __( 'Search Hobbies', $this->domain ),
			'not_found'           => __( 'No Hobbies found', $this->domain ),
			'not_found_in_trash'  => __( 'No Hobbies found in Trash', $this->domain ),
			'parent_item_colon'   => __( 'Parent Hobby:', $this->domain ),
			'menu_name'           => __( 'Hobbies', $this->domain ),
		);
		# Hobbies custom post type args
		$args = array(
			'labels'              => $labels,
			'public'              => false,
			'show_ui'             => true,
			'publicly_queryable'  => true,
			'exclude_from_search' => true,
			'show_in_admin_bar'   => false,
			'show_in_nav_menus'   => false,
			'show_in_menu'        => 'edit.php?post_type=gen_project',
			'rewrite'             => false,
			'capabilities'        => $capabilities,
			'supports'            => array(
				'title'
			),
			'hierarchical'        => false,
			'has_archive'         => false,
			'query_var'           => false,
			'can_export'          => true,
		);
		# Register hobbies custom post type
		register_post_type( 'gen_hobbies', $args );

		# Pricing custom post type labels
		$labels = array(
			'name'                => __( 'Pricing', $this->domain ),
			'singular_name'       => __( 'Plan', $this->domain ),
			'add_new'             => _x( 'Add New', 'plan', $this->domain ),
			'add_new_item'        => __( 'Add New Plan', $this->domain ),
			'edit_item'           => __( 'Edit Plan', $this->domain ),
			'new_item'            => __( 'New Plan', $this->domain ),
			'view_item'           => __( 'View Plan', $this->domain ),
			'search_items'        => __( 'Search Plans', $this->domain ),
			'not_found'           => __( 'No Plans found', $this->domain ),
			'not_found_in_trash'  => __( 'No Plans found in Trash', $this->domain ),
			'parent_item_colon'   => __( 'Parent Plan:', $this->domain ),
			'menu_name'           => __( 'Pricing', $this->domain ),
		);
		# Pricing custom post type args
		$args = array(
			'labels'              => $labels,
			'public'              => false,
			'show_ui'             => true,
			'publicly_queryable'  => true,
			'exclude_from_search' => true,
			'show_in_admin_bar'   => false,
			'show_in_nav_menus'   => false,
			'show_in_menu'        => 'edit.php?post_type=gen_project',
			'rewrite'             => false,
			'capabilities'        => $capabilities,
			'supports'            => array(
				'title'
			),
			'hierarchical'        => false,
			'has_archive'         => false,
			'query_var'           => false,
			'can_export'          => true,
		);
		# Register pricing post type
		register_post_type( 'gen_pricing', $args );

		# Process custom post type labels
		$labels = array(
			'name'                => __( 'Work Process', $this->domain ),
			'singular_name'       => __( 'Process', $this->domain ),
			'add_new'             => _x( 'Add New', 'process', $this->domain ),
			'add_new_item'        => __( 'Add New Process', $this->domain ),
			'edit_item'           => __( 'Edit Process', $this->domain ),
			'new_item'            => __( 'New Process', $this->domain ),
			'view_item'           => __( 'View Process', $this->domain ),
			'search_items'        => __( 'Search Processes', $this->domain ),
			'not_found'           => __( 'No Processes found', $this->domain ),
			'not_found_in_trash'  => __( 'No Processes found in Trash', $this->domain ),
			'parent_item_colon'   => __( 'Parent Item:', $this->domain ),
			'menu_name'           => __( 'Work Process', $this->domain ),
		);
		# Process custom post type args
		$args = array(
			'labels'              => $labels,
			'public'              => false,
			'show_ui'             => true,
			'publicly_queryable'  => true,
			'exclude_from_search' => true,
			'show_in_admin_bar'   => false,
			'show_in_nav_menus'   => false,
			'show_in_menu'        => 'edit.php?post_type=gen_project',
			'rewrite'             => false,
			'capabilities'        => $capabilities,
			'supports'            => array(
				'title'
			),
			'hierarchical'        => false,
			'has_archive'         => false,
			'query_var'           => false,
			'can_export'          => true,
		);
		# Register process post type
		register_post_type( 'gen_work_process', $args );

		# Testimonial custom post type labels
		$labels = array(
			'name'                => __( 'Testimonials', $this->domain ),
			'singular_name'       => __( 'Testimonial', $this->domain ),
			'add_new'             => _x( 'Add New', 'item', $this->domain ),
			'add_new_item'        => __( 'Add New Testimonial', $this->domain ),
			'edit_item'           => __( 'Edit Testimonial', $this->domain ),
			'new_item'            => __( 'New Testimonial', $this->domain ),
			'view_item'           => __( 'View Testimonial', $this->domain ),
			'search_items'        => __( 'Search Testimonials', $this->domain ),
			'not_found'           => __( 'No Testimonials found', $this->domain ),
			'not_found_in_trash'  => __( 'No Testimonials found in Trash', $this->domain ),
			'parent_item_colon'   => __( 'Parent Testimonial:', $this->domain ),
			'menu_name'           => __( 'Testimonials', $this->domain ),
		);
		# Testimonial custom post type args
		$args = array(
			'labels'              => $labels,
			'public'              => false,
			'show_ui'             => true,
			'publicly_queryable'  => true,
			'exclude_from_search' => true,
			'show_in_admin_bar'   => false,
			'show_in_nav_menus'   => false,
			'show_in_menu'        => 'edit.php?post_type=gen_project',
			'rewrite'             => false,
			'capabilities'        => $capabilities,
			'supports'            => array(
				'title'
			),
			'hierarchical'        => false,
			'has_archive'         => false,
			'query_var'           => false,
			'can_export'          => true,
		);
		# Register testimonial post type
		register_post_type( 'gen_testimonials', $args );


		# Clients custom post type labels
		$labels = array(
			'name'                => __( 'Clients', $this->domain ),
			'singular_name'       => __( 'Client', $this->domain ),
			'add_new'             => _x( 'Add New', 'client', $this->domain ),
			'add_new_item'        => __( 'Add New Client', $this->domain ),
			'edit_item'           => __( 'Edit Client', $this->domain ),
			'new_item'            => __( 'New Client', $this->domain ),
			'view_item'           => __( 'View Client', $this->domain ),
			'search_items'        => __( 'Search Clients', $this->domain ),
			'not_found'           => __( 'No Clients found', $this->domain ),
			'not_found_in_trash'  => __( 'No Clients found in Trash', $this->domain ),
			'parent_item_colon'   => __( 'Parent Client:', $this->domain ),
			'menu_name'           => __( 'Clients', $this->domain ),
		);
		# Clients custom post type args
		$args = array(
			'labels'              => $labels,
			'public'              => false,
			'show_ui'             => true,
			'publicly_queryable'  => true,
			'exclude_from_search' => true,
			'show_in_admin_bar'   => false,
			'show_in_nav_menus'   => false,
			'show_in_menu'        => 'edit.php?post_type=gen_project',
			'rewrite'             => false,
			'capabilities'        => $capabilities,
			'supports'            => array(
				'title'
			),
			'hierarchical'        => false,
			'has_archive'         => false,
			'query_var'           => false,
			'can_export'          => true,
		);
		# Register client post type
		register_post_type( 'gen_clients', $args );


		# Services custom post type labels
		$labels = array(
			'name'                => __( 'Services', $this->domain ),
			'singular_name'       => __( 'Service', $this->domain ),
			'add_new'             => _x( 'Add New', 'service', $this->domain ),
			'add_new_item'        => __( 'Add New Service', $this->domain ),
			'edit_item'           => __( 'Edit Service', $this->domain ),
			'new_item'            => __( 'New Service', $this->domain ),
			'view_item'           => __( 'View Service', $this->domain ),
			'search_items'        => __( 'Search Services', $this->domain ),
			'not_found'           => __( 'No Services found', $this->domain ),
			'not_found_in_trash'  => __( 'No Services found in Trash', $this->domain ),
			'parent_item_colon'   => __( 'Parent Service:', $this->domain ),
			'menu_name'           => __( 'Services', $this->domain ),
		);
		# Services custom post type args
		$args = array(
			'labels'              => $labels,
			'public'              => false,
			'show_ui'             => true,
			'publicly_queryable'  => true,
			'exclude_from_search' => true,
			'show_in_admin_bar'   => false,
			'show_in_nav_menus'   => false,
			'show_in_menu'        => 'edit.php?post_type=gen_project',
			'rewrite'             => false,
			'capabilities'        => $capabilities,
			'supports'            => array(
				'title'
			),
			'hierarchical'        => false,
			'has_archive'         => false,
			'query_var'           => false,
			'can_export'          => true,
		);
		# Register services post type
		register_post_type( 'gen_services', $args );
	}

	/**
	 * Custom post types tabular messages change
	 *
	 * @since 1.0
	 * @param array $bulk_messages
	 * @param intgere $bulk_counts 
	 * @return array
	 */
	public function cptCustomMessages( $bulk_messages, $bulk_counts )
	{
    		$bulk_messages['gen_project'] = array(
      	  	'updated'   => _n( '%s project updated.', '%s projects updated.', $bulk_counts['updated'], $this->domain ),
        		'locked'    => _n( '%s project not updated, somebody is editing it.', '%s projects not updated, somebody is editing them.', $bulk_counts['locked'], $this->domain ),
        		'deleted'   => _n( '%s project permanently deleted.', '%s projects permanently deleted.', $bulk_counts['deleted'], $this->domain ),
        		'trashed'   => _n( '%s project moved to the Trash.', '%s projects moved to the Trash.', $bulk_counts['trashed'], $this->domain ),
        		'untrashed' => _n( '%s project restored from the Trash.', '%s projects restored from the Trash.', $bulk_counts['untrashed'], $this->domain ),
    		);

    		$bulk_messages['gen_skills'] = array(
      	  	'updated'   => _n( '%s skill updated.', '%s skills updated.', $bulk_counts['updated'], $this->domain ),
        		'locked'    => _n( '%s skill not updated, somebody is editing it.', '%s skills not updated, somebody is editing them.', $bulk_counts['locked'], $this->domain ),
        		'deleted'   => _n( '%s skill permanently deleted.', '%s skills permanently deleted.', $bulk_counts['deleted'], $this->domain ),
        		'trashed'   => _n( '%s skill moved to the Trash.', '%s skills moved to the Trash.', $bulk_counts['trashed'], $this->domain ),
        		'untrashed' => _n( '%s skill restored from the Trash.', '%s skills restored from the Trash.', $bulk_counts['untrashed'], $this->domain ),
    		);

    		$bulk_messages['gen_resume'] = array(
      	  	'updated'   => _n( '%s item updated.', '%s items updated.', $bulk_counts['updated'], $this->domain ),
        		'locked'    => _n( '%s item not updated, somebody is editing it.', '%s items not updated, somebody is editing them.', $bulk_counts['locked'], $this->domain ),
        		'deleted'   => _n( '%s item permanently deleted.', '%s items permanently deleted.', $bulk_counts['deleted'], $this->domain ),
        		'trashed'   => _n( '%s item moved to the Trash.', '%s items moved to the Trash.', $bulk_counts['trashed'], $this->domain ),
        		'untrashed' => _n( '%s item restored from the Trash.', '%s items restored from the Trash.', $bulk_counts['untrashed'], $this->domain ),
    		);

    		$bulk_messages['gen_hobbies'] = array(
      	  	'updated'   => _n( '%s hobby updated.', '%s hobbies updated.', $bulk_counts['updated'], $this->domain ),
        		'locked'    => _n( '%s hobby not updated, somebody is editing it.', '%s hobbies not updated, somebody is editing them.', $bulk_counts['locked'], $this->domain ),
        		'deleted'   => _n( '%s hobby permanently deleted.', '%s hobbies permanently deleted.', $bulk_counts['deleted'], $this->domain ),
        		'trashed'   => _n( '%s hobby moved to the Trash.', '%s hobbies moved to the Trash.', $bulk_counts['trashed'], $this->domain ),
        		'untrashed' => _n( '%s hobby restored from the Trash.', '%s hobbies restored from the Trash.', $bulk_counts['untrashed'], $this->domain ),
    		);

    		$bulk_messages['gen_pricing'] = array(
      	  	'updated'   => _n( '%s plan updated.', '%s plans updated.', $bulk_counts['updated'], $this->domain ),
        		'locked'    => _n( '%s plan not updated, somebody is editing it.', '%s plans not updated, somebody is editing them.', $bulk_counts['locked'], $this->domain ),
        		'deleted'   => _n( '%s plan permanently deleted.', '%s plans permanently deleted.', $bulk_counts['deleted'], $this->domain ),
        		'trashed'   => _n( '%s plan moved to the Trash.', '%s plans moved to the Trash.', $bulk_counts['trashed'], $this->domain ),
        		'untrashed' => _n( '%s plan restored from the Trash.', '%s plans restored from the Trash.', $bulk_counts['untrashed'], $this->domain ),
    		);

    		$bulk_messages['gen_work_process'] = array(
      	  	'updated'   => _n( '%s process updated.', '%s processes updated.', $bulk_counts['updated'], $this->domain ),
        		'locked'    => _n( '%s process not updated, somebody is editing it.', '%s processes not updated, somebody is editing them.', $bulk_counts['locked'], $this->domain ),
        		'deleted'   => _n( '%s process permanently deleted.', '%s processes permanently deleted.', $bulk_counts['deleted'], $this->domain ),
        		'trashed'   => _n( '%s process moved to the Trash.', '%s processes moved to the Trash.', $bulk_counts['trashed'], $this->domain ),
        		'untrashed' => _n( '%s process restored from the Trash.', '%s processes restored from the Trash.', $bulk_counts['untrashed'], $this->domain ),
    		);

    		$bulk_messages['gen_testimonials'] = array(
      	  	'updated'   => _n( '%s testimonial updated.', '%s testimonials updated.', $bulk_counts['updated'], $this->domain ),
        		'locked'    => _n( '%s testimonial not updated, somebody is editing it.', '%s testimonials not updated, somebody is editing them.', $bulk_counts['locked'], $this->domain ),
        		'deleted'   => _n( '%s testimonial permanently deleted.', '%s testimonials permanently deleted.', $bulk_counts['deleted'], $this->domain ),
        		'trashed'   => _n( '%s testimonial moved to the Trash.', '%s testimonials moved to the Trash.', $bulk_counts['trashed'], $this->domain ),
        		'untrashed' => _n( '%s testimonial restored from the Trash.', '%s testimonials restored from the Trash.', $bulk_counts['untrashed'], $this->domain ),
    		);


    		$bulk_messages['gen_clients'] = array(
      	  	'updated'   => _n( '%s client updated.', '%s clients updated.', $bulk_counts['updated'], $this->domain ),
        		'locked'    => _n( '%s client not updated, somebody is editing it.', '%s clients not updated, somebody is editing them.', $bulk_counts['locked'], $this->domain ),
        		'deleted'   => _n( '%s client permanently deleted.', '%s clients permanently deleted.', $bulk_counts['deleted'], $this->domain ),
        		'trashed'   => _n( '%s client moved to the Trash.', '%s clients moved to the Trash.', $bulk_counts['trashed'], $this->domain ),
        		'untrashed' => _n( '%s client restored from the Trash.', '%s clients restored from the Trash.', $bulk_counts['untrashed'], $this->domain ),
    		);


    		$bulk_messages['gen_services'] = array(
      	  	'updated'   => _n( '%s service updated.', '%s services updated.', $bulk_counts['updated'], $this->domain ),
        		'locked'    => _n( '%s service not updated, somebody is editing it.', '%s services not updated, somebody is editing them.', $bulk_counts['locked'], $this->domain ),
        		'deleted'   => _n( '%s service permanently deleted.', '%s services permanently deleted.', $bulk_counts['deleted'], $this->domain ),
        		'trashed'   => _n( '%s service moved to the Trash.', '%s services moved to the Trash.', $bulk_counts['trashed'], $this->domain ),
        		'untrashed' => _n( '%s service restored from the Trash.', '%s services restored from the Trash.', $bulk_counts['untrashed'], $this->domain ),
    		);

    		return $bulk_messages;

	}

	/**
	 * Custom post types updated messages
	 *
	 * @since 1.0
	 * @access public
	 * @param  array $messages
	 * @return array
	 */
	public function cptUpdatedMessages($messages)
	{
		global $post, $post_ID;
		$post_type = get_post_type( $post_ID );

		if( !in_array($post_type, array('gen_skills','gen_resume','gen_hobbies','gen_pricing','gen_work_process','gen_testimonials','gen_clients','gen_services')) ){
			return $messages;
		}

		$obj = get_post_type_object($post_type);
		$singular = $obj->labels->singular_name;

		$messages[$post_type] = array(
			0 => '', // Unused. Messages start at index 1.
			1 => $singular . __(' updated.', $this->domain ),
			2 => __('Custom field updated.', $this->domain),
			3 => __('Custom field deleted.', $this->domain),
			4 => $singular . __(' updated.', $this->domain),
			5 => isset($_GET['revision']) ? $singular . __(' restored to revision from', $this->domain) . wp_post_revision_title( (int) $_GET['revision'], false ) : false,
			6 => $singular . __(' published.',$this->domain),
			7 => __('Page saved.', $this->domain),
			8 => $singular . __(' submitted.',$this->domain),
			9 => $singular . __(' scheduled.',$this->domain),
			10 => $singular . __(' draft updated.',$this->domain),
		);
		return $messages;	
	}

	/**
	 * Remove quick edit action button from custom post types
	 *
	 * @since 1.0
	 * @access public
	 * @param array $actions
	 * @return array
	 */
	public function removeRowActions($actions )
	{
		global $post;
		
		if( !in_array($post->post_type, array('gen_skills','gen_resume','gen_hobbies','gen_pricing','gen_work_process','gen_testimonials','gen_clients','gen_services')) ){
			return $actions;
		}
        	
        	unset( $actions['inline hide-if-no-js'] );
    		
    		return $actions;
	}

	/**
	 * Register project informations metabox
	 * 
	 * @since 1.0
	 * @access public
	 */
	public function registerPostTypesMetaboxes()
	{
		add_meta_box('genio_project_meta', __( 'Additional Info', $this->domain ), array(
			&$this,
			'renderProjectMetaMetabox'
		),'gen_project', 'normal', 'low');

		add_meta_box('genio_skill_meta', __( 'Skill Info', $this->domain ), array(
			&$this,
			'renderSkillMetaMetabox'
		),'gen_skills', 'normal', 'low');
		add_meta_box('genio_resume_meta', __( 'Resume Item Info', $this->domain ), array(
			&$this,
			'renderResumeMetaMetabox'
		),'gen_resume', 'normal', 'low');
		add_meta_box('genio_hobbies_meta', __( 'Hobby Info', $this->domain ), array(
			&$this,
			'renderHobbiesMetaMetabox'
		),'gen_hobbies', 'normal', 'low');
		add_meta_box('genio_pricing_meta', __( 'Pricing Plan Info', $this->domain ), array(
			&$this,
			'renderPricingMetaMetabox'
		),'gen_pricing', 'normal', 'low');
		add_meta_box('genio_word_process_meta', __( 'Work Process Info', $this->domain ), array(
			&$this,
			'renderWorkProcessMetaMetabox'
		),'gen_work_process', 'normal', 'low');
		add_meta_box('genio_testimonial_meta', __( 'Testimonial Info', $this->domain ), array(
			&$this,
			'renderTestimonialMetaMetabox'
		),'gen_testimonials', 'normal', 'low');
		add_meta_box('genio_clients_meta', __( 'Client Info', $this->domain ), array(
			&$this,
			'renderClientMetaMetabox'
		),'gen_clients', 'normal', 'low');
		add_meta_box('genio_service_meta', __( 'Service Info', $this->domain ), array(
			&$this,
			'renderServiceMetaMetabox'
		),'gen_services', 'normal', 'low');
	}  

	/**
	 * Render Skills Metabox
	 *
	 * @since 1.0
	 * @access public
	 * @param object $post
	 */
	public function renderSkillMetaMetabox($post)
	{
        	wp_nonce_field( $this->rand_hash, 'genio_wt_cpt_nonce');
        	$skills_info = get_post_meta( $post->ID, 'genio_skills_info', true );
        	if(($skills_info === false) || ($skills_info == '')){
        		$skills_info = array(
        			'title' => '',
        			'display_as' => 'bar',
        			'level' => '20',
        		);
        	}
		?>
		<table class="form-table">
             	<tbody>
              		<tr>
               			<th scope="row"><label for="genio_skills_title"><?php _e('Skill Title', $this->domain); ?> *</label></th>
               		<td>
               			<input name="genio_skills_info[title]" type="text" maxlength="50" value="<?php echo esc_attr($skills_info['title']); ?>" id="genio_skills_title" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert skill title (eg.Web Design).', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr>
               			<th scope="row"><label for="genio_skills_display_as"><?php _e('Display As', $this->domain); ?> *</label></th>
               		<td>
               			<select name="genio_skills_info[display_as]" id="genio_skills_display_as">
               				<option value="bar" <?php selected( $skills_info['display_as'], 'bar', 'true' ); ?>><?php _e('Bar', $this->domain); ?></option>
               				<option value="list_item" <?php selected( $skills_info['display_as'], 'list_item', 'true' ); ?>><?php _e('List Item', $this->domain); ?></option>
               			</select>
               			<p class='description'><?php _e('Whether to show skill as list item or bar.', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr>
               			<th scope="row"><flabel for="genio_skills_level"><?php _e('Proficiency Level', $this->domain); ?> *</label></th>
               		<td>
               			<select name="genio_skills_info[level]" id="genio_skills_level">
               				<option value="20" <?php selected( $skills_info['level'], '20', 'true' ); ?>><?php _e('20%', $this->domain); ?></option>
               				<option value="40" <?php selected( $skills_info['level'], '40', 'true' ); ?>><?php _e('40%', $this->domain); ?></option>
               				<option value="60" <?php selected( $skills_info['level'], '60', 'true' ); ?>><?php _e('60%', $this->domain); ?></option>
               				<option value="80" <?php selected( $skills_info['level'], '80', 'true' ); ?>><?php _e('80%', $this->domain); ?></option>
               				<option value="100" <?php selected( $skills_info['level'], '100', 'true' ); ?>><?php _e('100%', $this->domain); ?></option>
               			</select>
               			<p class='description'><?php _e('Select proficiency level for skill bar.', $this->domain); ?></p>
               		</td>
               		</tr>
               	</tbody>
            </table>
		<?php
	}

	/**
	 * Render Resume Metabox
	 *
	 * @since 1.0
	 * @access public
	 * @param object $post
	 */
	public function renderResumeMetaMetabox($post)
	{
		$icons_list = $this->fontIcons();
        	wp_nonce_field( $this->rand_hash, 'genio_wt_cpt_nonce');
        	$resume_info = get_post_meta( $post->ID, 'genio_resume_info', true );
        	if(($resume_info === false) || ($resume_info == '')){
        		$resume_info = array(
        			'category' => 'education',
        			'ed_from' => '',
        			'ed_to' => '',
        			'ed_univ' => '',
        			'ed_coun' => '',
        			'ed_degree' => '',
        			'ed_grade' => '',
        			'ed_summ' => '',
        			'ex_from' => '',
        			'ex_to' => '',
        			'ex_comp' => '',
        			'ex_coun' => '',
        			'ex_job' => '',
        			'ex_logo' => '',
        			'ex_summ' => '',
        			're_date' => '',
        			're_conf' => '',
        			're_coun' => '',
        			're_part' => '',
        			're_icon' => 'fa-glass',
        			're_summ' => '',
        		);
        	}
		?>
		<table class="form-table">
             	<tbody>
              		<tr>
               			<th scope="row"><label for="genio_resume_category"><?php _e('Category', $this->domain); ?> *</label></th>
               		<td>
               			<select name="genio_resume_info[category]" id="genio_resume_category">
               				<option value="education" <?php selected( $resume_info['category'], 'education', 'true' ); ?>><?php _e('Education', $this->domain); ?></option>
               				<option value="experience" <?php selected( $resume_info['category'], 'experience', 'true' ); ?>><?php _e('Experience', $this->domain); ?></option>
               				<option value="recognition" <?php selected( $resume_info['category'], 'recognition', 'true' ); ?>><?php _e('Recognition', $this->domain); ?></option>
               			</select>
               			<p class='description'><?php _e('Select resume item category.', $this->domain); ?></p>
               		</td>
               		</tr>

              		<tr class="ed_part">
               			<th scope="row"><label for="genio_resume_ed_from"><?php _e('From Year', $this->domain); ?> *</label></th>
               		<td>
               			<input name="genio_resume_info[ed_from]" type="text" maxlength="4" value="<?php echo esc_attr($resume_info['ed_from']); ?>" id="genio_resume_ed_from" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Select begin year.', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr class="ed_part">
               			<th scope="row"><label for="genio_resume_ed_to"><?php _e('To Year', $this->domain); ?></label> *</th>
               		<td>
               			<input name="genio_resume_info[ed_to]" type="text" maxlength="4" value="<?php echo esc_attr($resume_info['ed_to']); ?>" id="genio_resume_ed_to" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Select end year.', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr class="ed_part">
               			<th scope="row"><label for="genio_resume_ed_univ"><?php _e('University Or School Name', $this->domain); ?> *</label></th>
               		<td>
               			<input name="genio_resume_info[ed_univ]" type="text" maxlength="60" value="<?php echo esc_attr($resume_info['ed_univ']); ?>" id="genio_resume_ed_univ" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert university or school name.', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr class="ed_part">
               			<th scope="row"><label for="genio_resume_ed_coun"><?php _e('University Or School Country', $this->domain); ?></label></th>
               		<td>
               			<input name="genio_resume_info[ed_coun]" type="text" maxlength="60" value="<?php echo esc_attr($resume_info['ed_coun']); ?>" id="genio_resume_ed_coun" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert university or school country (eg.US).', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr class="ed_part">
               			<th scope="row"><label for="genio_resume_ed_degree"><?php _e('Degree', $this->domain); ?> *</label></th>
               		<td>
               			<input name="genio_resume_info[ed_degree]" type="text" maxlength="60" value="<?php echo esc_attr($resume_info['ed_degree']); ?>" id="genio_resume_ed_degree" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert final degree (eg.Master Degree Of Design).', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr class="ed_part">
               			<th scope="row"><label for="genio_resume_ed_grade"><?php _e('Grade', $this->domain); ?> *</label></th>
               		<td>
               			<input name="genio_resume_info[ed_grade]" type="text" maxlength="50" value="<?php echo esc_attr($resume_info['ed_grade']); ?>" id="genio_resume_ed_grade" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert final grade (eg.A+).', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr class="ed_part">
               			<th scope="row"><label for="genio_resume_ed_summ"><?php _e('Summary', $this->domain); ?></label></th>
               		<td>
               			<textarea name="genio_resume_info[ed_summ]" type="text" id="genio_resume_ed_summ" cols="60" rows="10"><?php echo esc_textarea($resume_info['ed_summ']); ?></textarea>
               			<p class='description'><?php _e('Insert A little description.', $this->domain); ?></p>
               		</td>
               		</tr>

              		<tr class="ex_part">
               			<th scope="row"><label for="genio_resume_ex_from"><?php _e('From Year', $this->domain); ?> *</label></th>
               		<td>
               			<input name="genio_resume_info[ex_from]" type="text" maxlength="4" value="<?php echo esc_attr($resume_info['ex_from']); ?>" id="genio_resume_ex_from" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Select begin year.', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr class="ex_part">
               			<th scope="row"><label for="genio_resume_ex_to"><?php _e('To Year', $this->domain); ?> *</label></th>
               		<td>
               			<input name="genio_resume_info[ex_to]" type="text" maxlength="4" value="<?php echo esc_attr($resume_info['ex_to']); ?>" id="genio_resume_ex_to" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Select end year. In case you still work at this company, Select future year (eg.2025).', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr class="ex_part">
               			<th scope="row"><label for="genio_resume_ex_comp"><?php _e('Company Name', $this->domain); ?> *</label></th>
               		<td>
               			<input name="genio_resume_info[ex_comp]" type="text" maxlength="60" value="<?php echo esc_attr($resume_info['ex_comp']); ?>" id="genio_resume_ex_comp" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert company name.', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr class="ex_part">
               			<th scope="row"><label for="genio_resume_ex_coun"><?php _e('Company Country', $this->domain); ?></label></th>
               		<td>
               			<input name="genio_resume_info[ex_coun]" type="text" maxlength="60" value="<?php echo esc_attr($resume_info['ex_coun']); ?>" id="genio_resume_ex_coun" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert company country.', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr class="ex_part">
               			<th scope="row"><label for="genio_resume_ex_job"><?php _e('Job Name', $this->domain); ?> *</label></th>
               		<td>
               			<input name="genio_resume_info[ex_job]" type="text" maxlength="60" value="<?php echo esc_attr($resume_info['ex_job']); ?>" id="genio_resume_ex_job" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert job name (eg.Web Developer).', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr class="ex_part">
               			<th scope="row"><label for="genio_resume_ex_logo"><?php _e('Company Logo', $this->domain); ?> *</label></th>
               		<td>
					<input name="genio_resume_info[ex_logo]" type="text" maxlength="200" value="<?php echo esc_attr($resume_info['ex_logo']); ?>" id="_val_genio_resume_ex_logo" class="regular-text"> <a href="#" id="genio_resume_ex_logo" class="button"><?php _e('Select Image', $this->domain); ?></a>
               			<p class='description'><?php _e('Select company logo.  recommended size (80 x 50).', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr class="ex_part">
               			<th scope="row"><label for="genio_resume_ex_summ"><?php _e('Summary', $this->domain); ?></label></th>
               		<td>
               			<textarea name="genio_resume_info[ex_summ]" type="text" id="genio_resume_ex_summ" cols="60" rows="10"><?php echo esc_textarea($resume_info['ex_summ']); ?></textarea>
               			<p class='description'><?php _e('Insert A little description.', $this->domain); ?></p>
               		</td>
               		</tr>

              		<tr class="re_part">
               			<th scope="row"><label for="genio_resume_re_date"><?php _e('Date', $this->domain); ?> *</label></th>
               		<td>
               			<input name="genio_resume_info[re_date]" type="text" maxlength="20" value="<?php echo esc_attr($resume_info['re_date']); ?>" id="genio_resume_re_date" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Select conference date.', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr class="re_part">
               			<th scope="row"><label for="genio_resume_re_conf"><?php _e('Conference or Contest Name', $this->domain); ?>*</label></th>
               		<td>
               			<input name="genio_resume_info[re_conf]" type="text" maxlength="60" value="<?php echo esc_attr($resume_info['re_conf']); ?>" id="genio_resume_re_conf" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert conference name (eg.Word Camp).', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr class="re_part">
               			<th scope="row"><label for="genio_resume_re_coun"><?php _e('Conference or Contest Country', $this->domain); ?></label></th>
               		<td>
               			<input name="genio_resume_info[re_coun]" type="text" maxlength="60" value="<?php echo esc_attr($resume_info['re_coun']); ?>" id="genio_resume_re_coun" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert conference country (eg.US).', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr class="re_part">
               			<th scope="row"><label for="genio_resume_re_part"><?php _e('Your Part', $this->domain); ?> *</label></th>
               		<td>
               			<input name="genio_resume_info[re_part]" type="text" maxlength="60" value="<?php echo esc_attr($resume_info['re_part']); ?>" id="genio_resume_re_part" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert your part (eg.Speaker).', $this->domain); ?></p>
               		</td>
               		</tr>
				<tr class="re_part">
 					<th scope="row"><label for="genio_resume_re_icon"><?php _e('Icon', $this->domain); ?> *</label></th>
 					<td><span class="custom-icon-container" id="genio_resume_re_icon_show"><i class="fa <?php echo esc_attr($resume_info['re_icon']); ?>"></i></span> <select name="genio_resume_info[re_icon]" id="genio_resume_re_icon">
   						<?php foreach ($icons_list as $key => $value){ ?>
   							<?php
							$slug = str_replace(array('fa','-'), array('',' '), $value);
							$slug = ucwords($slug);
   						?>
   							<option value="<?php echo esc_attr($value); ?>" <?php selected( $resume_info['re_icon'], $value, 'true' ); ?>><?php echo $slug ?></option>
   						<?php } ?>
  					</select>
  					<p class='description'><?php _e('Select your favourite icon.', $this->domain); ?></p>
  					</td>
				</tr>
              		<tr class="re_part">
               			<th scope="row"><label for="genio_resume_re_summ"><?php _e('Summary', $this->domain); ?></label></th>
               		<td>
               			<textarea name="genio_resume_info[re_summ]" type="text" id="genio_resume_re_summ" cols="60" rows="10"><?php echo esc_textarea($resume_info['re_summ']); ?></textarea>
               			<p class='description'><?php _e('Insert A little description.', $this->domain); ?></p>
               		</td>
               		</tr>

               	</tbody>
            </table>
		<?php
	}

	/**
	 * Render Hobbies Metabox
	 *
	 * @since 1.0
	 * @access public
	 * @param object $post
	 */
	public function renderHobbiesMetaMetabox($post)
	{
		$icons_list = $this->fontIcons();
        	wp_nonce_field( $this->rand_hash, 'genio_wt_cpt_nonce');
        	$hobbies_info = get_post_meta( $post->ID, 'genio_hobbies_info', true );
        	if(($hobbies_info === false) || ($hobbies_info == '')){
        		$hobbies_info = array(
        			'title' => '',
        			'icon' => 'fa-glass',
        			'summary' => '',
        		);
        	}
		?>
		<table class="form-table">
             	<tbody>
              		<tr>
               			<th scope="row"><label for="genio_hobbies_title"><?php _e('Title', $this->domain); ?> *</label></th>
               		<td>
               			<input name="genio_hobbies_info[title]" type="text" maxlength="50" value="<?php echo esc_attr($hobbies_info['title']); ?>" id="genio_hobbies_title" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert hobby title (eg.Travel).', $this->domain); ?></p>
               		</td>
               		</tr>
				<tr>
 					<th scope="row"><label for="genio_hobbies_icon"><?php _e('Icon', $this->domain); ?> *</label></th>
 					<td><span class="custom-icon-container" id="genio_hobbies_icon_show"><i class="fa <?php echo esc_attr($hobbies_info['icon']); ?>"></i></span> <select name="genio_hobbies_info[icon]" id="genio_hobbies_icon">
   						<?php foreach ($icons_list as $key => $value){ ?>
   							<?php
							$slug = str_replace(array('fa','-'), array('',' '), $value);
							$slug = ucwords($slug);
   						?>
   							<option value="<?php echo esc_attr($value); ?>" <?php selected( $hobbies_info['icon'], $value, 'true' ); ?>><?php echo $slug ?></option>
   						<?php } ?>
  					</select>
  					<p class='description'><?php _e('Select your favourite icon for this hobby.', $this->domain); ?></p>
  					</td>
				</tr>
              		<tr>
               			<th scope="row"><label for="genio_hobbies_summary"><?php _e('Summary', $this->domain); ?></label></th>
               		<td>
               			<textarea name="genio_hobbies_info[summary]" type="text" id="genio_hobbies_summary" cols="60" rows="10"><?php echo esc_textarea($hobbies_info['summary']); ?></textarea>
               			<p class='description'><?php _e('Insert A little description.', $this->domain); ?></p>
               		</td>
               		</tr>
               	</tbody>
            </table>
		<?php
	}

	/**
	 * Render Pricing Metabox
	 *
	 * @since 1.0
	 * @access public
	 * @param object $post
	 */
	public function renderPricingMetaMetabox($post)
	{
        	wp_nonce_field( $this->rand_hash, 'genio_wt_cpt_nonce');
        	$pricing_info = get_post_meta( $post->ID, 'genio_pricing_info', true );
        	if(($pricing_info === false) || ($pricing_info == '')){
        		$pricing_info = array(
        			'title' => '',
        			'plan_order' => '',
        			'price' => '',
        			'price_per' => '',
        			'currency' => '',
        			'plan_features' => array(),
        			'button_text' => '',
        			'button_link' => '',
        		);
        	}
		?>
		<table class="form-table">
             	<tbody>
              		<tr>
               			<th scope="row"><label for="genio_pricing_title"><?php _e('Plan Title', $this->domain); ?> *</label></th>
               		<td>
               			<input name="genio_pricing_info[title]" type="text" maxlength="50" value="<?php echo esc_attr($pricing_info['title']); ?>" id="genio_pricing_title" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert plan title (eg.Developer).', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr>
               			<th scope="row"><label for="genio_pricing_plan_order"><?php _e('Plan Order', $this->domain); ?> *</label></th>
               		<td>
               			<select name="genio_pricing_info[plan_order]" id="genio_pricing_plan_order">
               				<option value="left" <?php selected( $pricing_info['plan_order'], 'left', 'true' ); ?>><?php _e('Left', $this->domain); ?></option>
               				<option value="center" <?php selected( $pricing_info['plan_order'], 'center', 'true' ); ?>><?php _e('Center', $this->domain); ?></option>
               				<option value="right" <?php selected( $pricing_info['plan_order'], 'right', 'true' ); ?>><?php _e('Right', $this->domain); ?></option>
               			</select>
               			<p class='description'><?php _e('Select plan order.', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr>
               			<th scope="row"><label for="genio_pricing_price"><?php _e('Plan Price', $this->domain); ?> *</label></th>
               		<td>
               			<input name="genio_pricing_info[price]" type="text" maxlength="10" value="<?php echo esc_attr($pricing_info['price']); ?>" id="genio_pricing_price" style="width:80px" class="regular-text" placeholder=""> <?php _e('Per', $this->domain); ?> * <input name="genio_pricing_info[price_per]" type="text" maxlength="50" value="<?php echo esc_attr($pricing_info['price_per']); ?>" style="width:120px" id="genio_pricing_price_per" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert plan price (eg. 15 or 15.23 or 00.52).', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr>
               			<th scope="row"><label for="genio_pricing_currency"><?php _e('Currency', $this->domain); ?> *</label></th>
               		<td>
               			<input name="genio_pricing_info[currency]" type="text" maxlength="20" value="<?php echo esc_attr($pricing_info['currency']); ?>" id="genio_pricing_currency" style="width:80px" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert currency shorthand (eg.$).', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr>
               			<th scope="row"><label for="genio_pricing_plan_features"><?php _e('Plan Features', $this->domain); ?> *</label></th>
               		<td class="plan_feature">
               			<span id="plan_feature_proto"><input name="genio_pricing_info[plan_features][]" type="text" maxlength="50" value="" class="regular-text" placeholder="" disabled="disabled"> <a href="#" class="button"><i class="fa fa-plus-circle"></i></a><br><br></span>
               			<?php if( (is_array($pricing_info['plan_features'])) && (count($pricing_info['plan_features']) >= 1) ){ ?>
               				<?php foreach ($pricing_info['plan_features'] as $key => $feature ) { ?>
							<span class="feature_exists"><input name="genio_pricing_info[plan_features][]" type="text" maxlength="50" value="<?php echo esc_attr($feature); ?>" class="regular-text" placeholder=""> <a href="#" class="button"><i class="fa fa-minus-circle"></i></a><br><br></span>
               				<?php } ?>
               			<?php } ?>
               			<p class='description'><?php _e('Insert plan features.', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr>
               			<th scope="row"><label for="genio_pricing_button_text"><?php _e('Button Text', $this->domain); ?></label></th>
               		<td>
               			<input name="genio_pricing_info[button_text]" type="text" maxlength="50" value="<?php echo esc_attr($pricing_info['button_text']); ?>" id="genio_pricing_button_text" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert plan button text (eg.Order Now).', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr>
               			<th scope="row"><label for="genio_pricing_button_link"><?php _e('Button Link', $this->domain); ?></label></th>
               		<td>
               			<input name="genio_pricing_info[button_link]" type="text" maxlength="200" value="<?php echo esc_attr($pricing_info['button_link']); ?>" id="genio_pricing_button_link" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert plan button URL.', $this->domain); ?></p>
               		</td>
               		</tr>
               	</tbody>
            </table>
		<?php
	}

	/**
	 * Render Work Process Metabox
	 *
	 * @since 1.0
	 * @access public
	 * @param object $post
	 */
	public function renderWorkProcessMetaMetabox($post)
	{
		$icons_list = $this->fontIcons();
        	wp_nonce_field( $this->rand_hash, 'genio_wt_cpt_nonce');
        	$work_process_info = get_post_meta( $post->ID, 'genio_work_process_info', true );
        	if(($work_process_info === false) || ($work_process_info == '')){
        		$work_process_info = array(
        			'title' => '',
        			'icon' => 'fa-glass',
        			'order' => '',
        		);
        	}
		?>
		<table class="form-table">
             	<tbody>
              		<tr>
               			<th scope="row"><label for="genio_work_process_title"><?php _e('Title', $this->domain); ?> *</label></th>
               		<td>
               			<input name="genio_work_process_info[title]" type="text" maxlength="50" value="<?php echo esc_attr($work_process_info['title']); ?>" id="genio_work_process_title" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert process title (eg.CONCEPT).', $this->domain); ?></p>
               		</td>
               		</tr>
				<tr>
 					<th scope="row"><label for="genio_work_process_icon"><?php _e('Icon', $this->domain); ?> *</label></th>
 					<td><span class="custom-icon-container" id="genio_work_process_icon_show"><i class="fa <?php echo esc_attr($work_process_info['icon']); ?>"></i></span> <select name="genio_work_process_info[icon]" id="genio_work_process_icon">
   						<?php foreach ($icons_list as $key => $value){ ?>
   							<?php
							$slug = str_replace(array('fa','-'), array('',' '), $value);
							$slug = ucwords($slug);
   						?>
   							<option value="<?php echo esc_attr($value); ?>" <?php selected( $work_process_info['icon'], $value, 'true' ); ?>><?php echo $slug ?></option>
   						<?php } ?>
  					</select>
  					<p class='description'><?php _e('Select your favourite icon for this process.', $this->domain); ?></p>
  					</td>
				</tr>
              		<tr>
               			<th scope="row"><label for="genio_work_process_order"><?php _e('Order', $this->domain); ?> *</label></th>
               		<td>
               			<select name="genio_work_process_info[order]" id="genio_work_process_order">
               				<option value="1" <?php selected( $work_process_info['order'], '1', 'true' ); ?>><?php _e('1', $this->domain); ?></option>
               				<option value="2" <?php selected( $work_process_info['order'], '2', 'true' ); ?>><?php _e('2', $this->domain); ?></option>
               				<option value="3" <?php selected( $work_process_info['order'], '3', 'true' ); ?>><?php _e('3', $this->domain); ?></option>
               				<option value="4" <?php selected( $work_process_info['order'], '4', 'true' ); ?>><?php _e('4', $this->domain); ?></option>
               				<option value="5" <?php selected( $work_process_info['order'], '5', 'true' ); ?>><?php _e('5', $this->domain); ?></option>
               				<option value="6" <?php selected( $work_process_info['order'], '6', 'true' ); ?>><?php _e('6', $this->domain); ?></option>
               			</select>
               		</td>
               		<p class='description'><?php _e('Select work process order.', $this->domain); ?></p>
               		</tr>
               	</tbody>
            </table>
		<?php
	}

	/**
	 * Render Testimonial Metabox
	 *
	 * @since 1.0
	 * @access public
	 * @param object $post
	 */
	public function renderTestimonialMetaMetabox($post)
	{
        	wp_nonce_field( $this->rand_hash, 'genio_wt_cpt_nonce');
        	$testimonial_info = get_post_meta( $post->ID, 'genio_testimonial_info', true );
        	if(($testimonial_info === false) || ($testimonial_info == '')){
        		$testimonial_info = array(
        			'name' => '',
        			'photo' => '',
        			'job' => '',
        			'company' => '',
        			'main' => '',
        		);
        	}
		?>
		<table class="form-table">
             	<tbody>
              		<tr>
               			<th scope="row"><label for="genio_testimonial_name"><?php _e('Client Name', $this->domain); ?> *</label></th>
               		<td>
               			<input name="genio_testimonial_info[name]" maxlength="50" type="text" value="<?php echo esc_attr($testimonial_info['name']); ?>" id="genio_testimonial_name" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert client name.', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr>
               			<th scope="row"><label for="genio_testimonial_photo"><?php _e('Client Photo', $this->domain); ?> *</label></th>
               		<td>
					<input name="genio_testimonial_info[photo]" maxlength="200" type="text" value="<?php echo esc_attr($testimonial_info['photo']); ?>" id="_val_genio_testimonial_photo" class="regular-text"> <a href="#" id="genio_testimonial_photo" class="button"><?php _e('Select Image', $this->domain); ?></a>
               			<p class='description'><?php _e('Select client photo. recommended size (160 x 160)', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr>
               			<th scope="row"><label for="genio_testimonial_job"><?php _e('Client Job', $this->domain); ?> *</label></th>
               		<td>
               			<input name="genio_testimonial_info[job]" maxlength="50" type="text" value="<?php echo esc_attr($testimonial_info['job']); ?>" id="genio_testimonial_job" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert client job (eg.Design Specialist)', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr>
               			<th scope="row"><label for="genio_testimonial_company"><?php _e('Client Company', $this->domain); ?></label></th>
               		<td>
               			<input name="genio_testimonial_info[company]" maxlength="50" type="text" value="<?php echo esc_attr($testimonial_info['company']); ?>" id="genio_testimonial_company" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert company name (eg.Envato)', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr>
               			<th scope="row"><label for="genio_testimonial_main"><?php _e('Testimonial', $this->domain); ?> *</label></th>
               		<td>
               			<textarea name="genio_testimonial_info[main]" type="text" id="genio_testimonial_main" cols="60" rows="10"><?php echo esc_textarea($testimonial_info['main']); ?></textarea>
               			<p class='description'><?php _e('Insert the testimonial.', $this->domain); ?></p>
               		</td>
               		</tr>
               	</tbody>
            </table>
		<?php
	}

	/**
	 * Render Clients Metabox
	 *
	 * @since 1.0
	 * @access public
	 * @param object $post
	 */
	public function renderClientMetaMetabox($post)
	{
        	wp_nonce_field( $this->rand_hash, 'genio_wt_cpt_nonce');
        	$client_info = get_post_meta( $post->ID, 'genio_client_info', true );
        	if(($client_info === false) || ($client_info == '')){
        		$client_info = array(
        			'logo' => '',
        			'url' => '',
        		);
        	}
		?>
		<table class="form-table">
             	<tbody>
              		<tr>
               			<th scope="row"><label for="genio_client_logo"><?php _e('Logo', $this->domain); ?> *</label></th>
				<td>
					<input name="genio_client_info[logo]" type="text" maxlength="200" value="<?php echo esc_attr($client_info['logo']); ?>" id="_val_genio_client_logo" class="regular-text"> <a href="#" id="genio_client_logo" class="button"><?php _e('Select Image', $this->domain); ?></a>
					<p class='description'><?php _e('Select client logo. recommended size (80 x 50)', $this->domain); ?></p>
				</td>
               		</tr>
              		<tr>
               			<th scope="row"><label for="genio_client_url"><?php _e('Client URL', $this->domain); ?></label></th>
               		<td>
               			<input name="genio_client_info[url]" type="text" maxlength="200" value="<?php echo esc_attr($client_info['url']); ?>" id="genio_client_url" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert client site URL.', $this->domain); ?></p>
               		</td>
               		</tr>
               	</tbody>
            </table>
		<?php
	}

	/**
	 * Render Service Metabox
	 *
	 * @since 1.0
	 * @access public
	 * @param object $post
	 */
	public function renderServiceMetaMetabox($post)
	{
        	wp_nonce_field( $this->rand_hash, 'genio_wt_cpt_nonce');
        	$service_info = get_post_meta( $post->ID, 'genio_service_info', true );
        	if(($service_info === false) || ($service_info == '')){
        		$service_info = array(
        			'title' => '',
        			'icon' => 'fa-glass',
        			'summary' => '',
        		);
        	}
		$icons_list = $this->fontIcons();
		?>
		<table class="form-table">
             	<tbody>
              		<tr>
               			<th scope="row"><label for="genio_service_title"><?php _e('Title', $this->domain); ?> *</label></th>
               		<td>
               			<input name="genio_service_info[title]" type="text" maxlength="50" value="<?php echo esc_attr($service_info['title']); ?>" id="genio_service_title" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert service title (eg.Website Installation)', $this->domain); ?></p>
               		</td>
               		</tr>
				<tr>
 					<th scope="row"><label for="genio_service_icon"><?php _e('Icon', $this->domain); ?> *</label></th>
 					<td><span class="custom-icon-container" id="genio_service_icon_show"><i class="fa <?php echo esc_attr($service_info['icon']); ?>"></i></span> <select name="genio_service_info[icon]" id="genio_service_icon">
   						<?php foreach ($icons_list as $key => $value){ ?>
   							<?php
							$slug = str_replace(array('fa','-'), array('',' '), $value);
							$slug = ucwords($slug);
   						?>
   							<option value="<?php echo esc_attr($value); ?>" <?php selected( $service_info['icon'], $value, 'true' ); ?>><?php echo $slug ?></option>
   						<?php } ?>
  					</select>
  					<p class='description'><?php _e('Select your favourite icon.', $this->domain); ?></p>
  					</td>
				</tr>
              		<tr>
               			<th scope="row"><label for="genio_service_summary"><?php _e('Summary', $this->domain); ?></label></th>
               		<td>
               			<textarea name="genio_service_info[summary]" type="text" id="genio_service_summary" cols="60" rows="10"><?php echo esc_textarea($service_info['summary']); ?></textarea>
               			<p class='description'><?php _e('Insert A little description.', $this->domain); ?></p>
               		</td>
               		</tr>
               	</tbody>
            </table>
		<?php
	}

	/**
	 * Render project informations metabox
	 *
	 * @since 1.0
	 * @access public
	 */
   	public function renderProjectMetaMetabox($post)
   	{ 
        	wp_nonce_field( $this->rand_hash, 'genio_wt_cpt_nonce');
        	$project_info = get_post_meta( $post->ID, 'genio_project_info', true );
        	if(($project_info === false) || ($project_info == '')){
        		$project_info = array(
        			'header_img' => '',
        			'client' => '',
        			'role' => '',
        			'date' => '',
        			'link_text' => '',
        			'link' => '',
        			'tes' => '',
        			'tes_by' => '',
        		);
        	}
		?>
		<table class="form-table">
             	<tbody>
              		<tr>
               			<th scope="row"><label for="genio_project_header_img"><?php _e('Header Image', $this->domain); ?></label></th>
				<td>
					<input name="genio_project_info[header_img]" type="text" maxlength="200" value="<?php echo esc_attr($project_info['header_img']); ?>" id="_val_genio_project_header_img" class="regular-text"> <a href="#" id="genio_project_header_img" class="button"><?php _e('Select Image', $this->domain); ?></a>
					<p class='description'><?php _e('Select project page header background. recommended size (1920 x 300)', $this->domain); ?></p>
				</td>
               		</tr>
              		<tr>
               			<th scope="row"><label for="genio_project_client"><?php _e('Client Name', $this->domain); ?></label></th>
               		<td>
               			<input name="genio_project_info[client]" type="text" maxlength="50" value="<?php echo esc_attr($project_info['client']); ?>" id="genio_project_client" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert project client name (eg.John Doe).', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr>
               			<th scope="row"><label for="genio_project_role"><?php _e('Your Role', $this->domain); ?></label></th>
               		<td>
               			<input name="genio_project_info[role]" type="text" maxlength="50" value="<?php echo esc_attr($project_info['role']); ?>" id="genio_project_role" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert your role (eg.Web Developer).', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr>
               			<th scope="row"><label for="genio_project_date"><?php _e('Release Date', $this->domain); ?></label></th>
               		<td>
					<input name="genio_project_info[date]" type="text" maxlength="20" value="<?php echo esc_attr($project_info['date']); ?>" id="genio_project_date" class="regular-text newtag form-input-tip">
               			<p class='description'><?php _e('Select project release date.', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr>
               			<th scope="row"><label for="genio_project_link"><?php _e('Preview Link Text', $this->domain); ?></label></th>
               		<td>
               			<input name="genio_project_info[link_text]" type="text" maxlength="50" value="<?php echo esc_attr($project_info['link_text']); ?>" id="genio_project_link" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert button text (eg.Visit Project).', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr>
               			<th scope="row"><label for="genio_project_link"><?php _e('Preview Link', $this->domain); ?></label></th>
               		<td>
               			<input name="genio_project_info[link]" type="text" maxlength="200" value="<?php echo esc_attr($project_info['link']); ?>" id="genio_project_link" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert project URL.', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr>
               			<th scope="row"><label for="genio_project_testimonial"><?php _e('Testimonial', $this->domain); ?></label></th>
               		<td>
               			<textarea name="genio_project_info[tes]" type="text" id="genio_project_testimonial" cols="48" rows="3"><?php echo esc_textarea($project_info['tes']); ?></textarea>
               			<p class='description'><?php _e('Insert client testimonial.', $this->domain); ?></p>
               		</td>
               		</tr>
              		<tr>
               			<th scope="row"><label for="genio_project_testimonial_by"><?php _e('Testimonial By', $this->domain); ?></label></th>
               		<td>
               			<input name="genio_project_info[tes_by]" type="text" maxlength="50" value="<?php echo esc_attr($project_info['tes_by']); ?>" id="genio_project_testimonial_by" class="regular-text" placeholder="">
               			<p class='description'><?php _e('Insert client name.', $this->domain); ?></p>
               		</td>
               		</tr>
               	</tbody>
            </table>
		<?php
   	}

	/**
	 * Store project informations metabox
	 *
	 * @since 1.0
	 * @access public
	 */
   	public function saveMetaMetabox($post_id, $post = null)
   	{
   		global $post;
	
		// Check if our nonce is set.
		if ( !isset( $_POST['genio_wt_cpt_nonce'] ) ) {
			return;
		}
	
		// Verify that the nonce is valid.
		if ( !wp_verify_nonce( $_POST['genio_wt_cpt_nonce'], $this->rand_hash ) ) {
			return;
		}
	
		// If this is an autosave, our form has not been submitted, so we don't want to do anything.
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( !(isset($_POST['post_type'])) || !(in_array($_POST['post_type'], array('gen_project','gen_skills','gen_resume','gen_hobbies','gen_pricing','gen_work_process','gen_testimonials','gen_clients','gen_services'))) ) {
			return;
		}
		if ( !current_user_can( $this->capability) ) {
			return;
		}

		if( ($_POST['post_type'] == 'gen_project') && (isset($_POST['genio_project_info'])) && (is_array($_POST['genio_project_info'])) ){
			$this->updateProjectMeta($post_id, $_POST['genio_project_info']);
		}

		if( ($_POST['post_type'] == 'gen_skills') && (isset($_POST['genio_skills_info'])) && (is_array($_POST['genio_skills_info'])) ){
			$this->updateSkillMeta($post_id, $_POST['genio_skills_info']);
		}

		if( ($_POST['post_type'] == 'gen_resume') && (isset($_POST['genio_resume_info'])) && (is_array($_POST['genio_resume_info'])) ){
			$this->updateResumeMeta($post_id, $_POST['genio_resume_info']);
		}

		if( ($_POST['post_type'] == 'gen_hobbies') && (isset($_POST['genio_hobbies_info'])) && (is_array($_POST['genio_hobbies_info'])) ){
			$this->updateHobbiesMeta($post_id, $_POST['genio_hobbies_info']);
		}

		if( ($_POST['post_type'] == 'gen_pricing') && (isset($_POST['genio_pricing_info'])) && (is_array($_POST['genio_pricing_info'])) ){
			$this->updatePricingMeta($post_id, $_POST['genio_pricing_info']);
		}

		if( ($_POST['post_type'] == 'gen_work_process') && (isset($_POST['genio_work_process_info'])) && (is_array($_POST['genio_work_process_info'])) ){
			$this->updateWorkProcessMeta($post_id, $_POST['genio_work_process_info']);
		}

		if( ($_POST['post_type'] == 'gen_testimonials') && (isset($_POST['genio_testimonial_info'])) && (is_array($_POST['genio_testimonial_info'])) ){
			$this->updateTestimoialsMeta($post_id, $_POST['genio_testimonial_info']);
		}

		if( ($_POST['post_type'] == 'gen_clients') && (isset($_POST['genio_client_info'])) && (is_array($_POST['genio_client_info'])) ){
			$this->updateClientsMeta($post_id, $_POST['genio_client_info']);
		}

		if( ($_POST['post_type'] == 'gen_services') && (isset($_POST['genio_service_info'])) && (is_array($_POST['genio_service_info'])) ){
			$this->updateServicesMeta($post_id, $_POST['genio_service_info']);
		}

		if( $this->error_indicator !== false ){
			
			remove_action( 'save_post', array(
				&$this,
				'saveMetaMetabox'
			));

			// update the post, which calls save_post again
			wp_update_post( array( 'ID' => $post_id, 'post_status' => 'draft' ) );

			// re-hook this function
			add_action( 'save_post', array(
				&$this,
				'saveMetaMetabox'
			));
			
			add_filter( 'redirect_post_location', array(
				&$this,
				'redirectCPT'
			));
		}
		return;
   	}

   	/**
   	 * Redirect custom post type to error page
   	 *
   	 * @since 1.0
   	 * @access public
   	 * @param string $location
   	 * @return string
   	 */
   	public function redirectCPT($location)
   	{
   		return add_query_arg("message", $this->error_indicator, $location);
   	}

   	/**
   	 * Update project meta data
   	 *
   	 * @since 1.0
   	 * @access private
   	 * @param integer $post_id
   	 * @param array $project_meta
   	 * @return boolean|integer
   	 */
   	private function updateProjectMeta($post_id, $project_meta)
   	{
		$cleared_data = $this->validator->clear_values(array(
			'header_img' => array(
  				'value'=> (isset($project_meta['header_img'])) ? $project_meta['header_img'] : '',
                		'sanit'=> 'surl',
                   	'valid'=> 'vnotempty&vurl&vstrlenbetween:1,200',
                   	'default' => '',
			),
			'client' => array(
  				'value'=> (isset($project_meta['client'])) ? $project_meta['client'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   	'default' => '',
			),
			'role' => array(
  				'value'=> (isset($project_meta['role'])) ? $project_meta['role'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   	'default' => '',
			),
			'date' => array(
  				'value'=> (isset($project_meta['date'])) ? $project_meta['date'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vdates:d',
                   	'default' => '',
			),
			'link_text' => array(
  				'value'=> (isset($project_meta['link_text'])) ? $project_meta['link_text'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   	'default' => '',
			),
			'link' => array(
  				'value'=> (isset($project_meta['link'])) ? $project_meta['link'] : '',
                		'sanit'=> 'surl',
                   	'valid'=> 'vnotempty&vurl&vstrlenbetween:1,200',
                   	'default' => '',
			),
			'tes' => array(
  				'value'=> (isset($project_meta['tes'])) ? $project_meta['tes'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,500',
                   	'default' => '',
			),
			'tes_by' => array(
  				'value'=> (isset($project_meta['tes_by'])) ? $project_meta['tes_by'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   	'default' => '',
			),
		));

		update_post_meta( $post_id, 'genio_project_info', array(
			'header_img' => $cleared_data['header_img']['value'],
			'client' => $cleared_data['client']['value'],
			'role' => $cleared_data['role']['value'],
			'date' => $cleared_data['date']['value'],
			'link_text' => $cleared_data['link_text']['value'],
			'link' => $cleared_data['link']['value'],
			'tes' => $cleared_data['tes']['value'],
			'tes_by' => $cleared_data['tes_by']['value'],	
		));
		//no item required
		$this->error_indicator = false;

		return $this->error_indicator;
   	}

   	/**
   	 * Update skill meta data
   	 *
   	 * @since 1.0
   	 * @access private
   	 * @param integer $post_id
   	 * @param array $skill_meta
   	 * @return boolean|integer
   	 */
   	private function updateSkillMeta($post_id, $skill_meta)
   	{
		$cleared_data = $this->validator->clear_values(array(
			'title' => array(
  				'value'=> (isset($skill_meta['title'])) ? $skill_meta['title'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   	'default' => '',
			),
			'display_as' => array(
  				'value'=> (isset($skill_meta['display_as'])) ? $skill_meta['display_as'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vinarray:bar,list_item',
                   	'default' => '',
			),
			'level' => array(
  				'value'=> (isset($skill_meta['level'])) ? $skill_meta['level'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vinarray:20,40,60,80,100',
                   	'default' => '',
			),
		));

		update_post_meta( $post_id, 'genio_skills_info', array(
			'title' => $cleared_data['title']['value'],
			'display_as' => $cleared_data['display_as']['value'],
			'level' => $cleared_data['level']['value'],			
		));

		$this->error_indicator = ($cleared_data['title']['status'] && $cleared_data['display_as']['status'] && $cleared_data['level']['status']) ? false : 200;

		return $this->error_indicator;
   	}

   	/**
   	 * Update resume meta data
   	 *
   	 * @since 1.0
   	 * @access private
   	 * @param integer $post_id
   	 * @param array $resume_meta
   	 * @return boolean|integer
   	 */
   	private function updateResumeMeta($post_id, $resume_meta)
   	{
		$cleared_data = $this->validator->clear_values(array(
			'category' => array(
  				'value'=> (isset($resume_meta['category'])) ? $resume_meta['category'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vinarray:education,experience,recognition',
                   	'default' => '',
			),
			'ed_from' => array(
  				'value'=> (isset($resume_meta['ed_from'])) ? $resume_meta['ed_from'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vdates:y',
                   	'default' => '',
			),
			'ed_to' => array(
  				'value'=> (isset($resume_meta['ed_to'])) ? $resume_meta['ed_to'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vdates:y',
                   	'default' => '',
			),
			'ed_univ' => array(
  				'value'=> (isset($resume_meta['ed_univ'])) ? $resume_meta['ed_univ'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,60',
                   	'default' => '',
			),
			'ed_coun' => array(
  				'value'=> (isset($resume_meta['ed_coun'])) ? $resume_meta['ed_coun'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,60',
                   	'default' => '',
			),
			'ed_degree' => array(
  				'value'=> (isset($resume_meta['ed_degree'])) ? $resume_meta['ed_degree'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,60',
                   	'default' => '',
			),
			'ed_grade' => array(
  				'value'=> (isset($resume_meta['ed_grade'])) ? $resume_meta['ed_grade'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   	'default' => '',
			),
			'ed_summ' => array(
  				'value'=> (isset($resume_meta['ed_summ'])) ? $resume_meta['ed_summ'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,700',
                   	'default' => '',
			),

			'ex_from' => array(
  				'value'=> (isset($resume_meta['ex_from'])) ? $resume_meta['ex_from'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vdates:y',
                   	'default' => '',
			),
			'ex_to' => array(
  				'value'=> (isset($resume_meta['ex_to'])) ? $resume_meta['ex_to'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vdates:fy',
                   	'default' => '',
			),
			'ex_comp' => array(
  				'value'=> (isset($resume_meta['ex_comp'])) ? $resume_meta['ex_comp'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,60',
                   	'default' => '',
			),
			'ex_coun' => array(
  				'value'=> (isset($resume_meta['ex_coun'])) ? $resume_meta['ex_coun'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,60',
                   	'default' => '',
			),
			'ex_job' => array(
  				'value'=> (isset($resume_meta['ex_job'])) ? $resume_meta['ex_job'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,60',
                   	'default' => '',
			),
			'ex_logo' => array(
  				'value'=> (isset($resume_meta['ex_logo'])) ? $resume_meta['ex_logo'] : '',
                		'sanit'=> 'surl',
                   	'valid'=> 'vnotempty&vurl&vstrlenbetween:1,200',
                   	'default' => '',
			),
			'ex_summ' => array(
  				'value'=> (isset($resume_meta['ex_summ'])) ? $resume_meta['ex_summ'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,700',
                   	'default' => '',
			),
			're_date' => array(
  				'value'=> (isset($resume_meta['re_date'])) ? $resume_meta['re_date'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vdates:d',
                   	'default' => '',
			),
			're_conf' => array(
  				'value'=> (isset($resume_meta['re_conf'])) ? $resume_meta['re_conf'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,60',
                   	'default' => '',
			),
			're_coun' => array(
  				'value'=> (isset($resume_meta['re_coun'])) ? $resume_meta['re_coun'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,60',
                   	'default' => '',
			),
			're_part' => array(
  				'value'=> (isset($resume_meta['re_part'])) ? $resume_meta['re_part'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,60',
                   	'default' => '',
			),
			're_icon' => array(
  				'value'=> (isset($resume_meta['re_icon'])) ? $resume_meta['re_icon'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vicon',
                   	'default' => '',
			),
			're_summ' => array(
  				'value'=> (isset($resume_meta['re_summ'])) ? $resume_meta['re_summ'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,700',
                   	'default' => '',
			),
		));

		update_post_meta( $post_id, 'genio_resume_info', array(
			'category' => $cleared_data['category']['value'],
			'ed_from' => $cleared_data['ed_from']['value'],
			'ed_to' => $cleared_data['ed_to']['value'],
			'ed_univ' => $cleared_data['ed_univ']['value'],
			'ed_coun' => $cleared_data['ed_coun']['value'],
			'ed_degree' => $cleared_data['ed_degree']['value'],
			'ed_grade' => $cleared_data['ed_grade']['value'],
			'ed_summ' => $cleared_data['ed_summ']['value'],
			'ex_from' => $cleared_data['ex_from']['value'],
			'ex_to' => $cleared_data['ex_to']['value'],
			'ex_comp' => $cleared_data['ex_comp']['value'],
			'ex_coun' => $cleared_data['ex_coun']['value'],
			'ex_job' => $cleared_data['ex_job']['value'],
			'ex_logo' => $cleared_data['ex_logo']['value'],
			'ex_summ' => $cleared_data['ex_summ']['value'],
			're_date' => $cleared_data['re_date']['value'],
			're_conf' => $cleared_data['re_conf']['value'],
			're_coun' => $cleared_data['re_coun']['value'],
			're_part' => $cleared_data['re_part']['value'],
			're_icon' => $cleared_data['re_icon']['value'],
			're_summ' => $cleared_data['re_summ']['value'],	
		));
		
		if($cleared_data['category']['value'] == 'education'){
			$this->error_indicator = ($cleared_data['category']['status'] && $cleared_data['ed_from']['status'] && $cleared_data['ed_to']['status'] && $cleared_data['ed_univ']['status'] && $cleared_data['ed_degree']['status'] && $cleared_data['ed_grade']['status']) ? false : 200;
		}

		if($cleared_data['category']['value'] == 'experience'){
			$this->error_indicator = ($cleared_data['ex_from']['status'] && $cleared_data['ex_to']['status'] && $cleared_data['ex_comp']['status'] && $cleared_data['ex_job']['status'] && $cleared_data['ex_logo']['status']) ? false : 200;
		}

		if($cleared_data['category']['value'] == 'recognition'){
			$this->error_indicator = ($cleared_data['re_date']['status'] && $cleared_data['re_conf']['status'] && $cleared_data['re_part']['status'] && $cleared_data['re_icon']['status']) ? false : 200;
		}

		return $this->error_indicator;
   	}

   	/**
   	 * Update hobbies meta data
   	 *
   	 * @since 1.0
   	 * @access private
   	 * @param integer $post_id
   	 * @param array $hobbies_meta
   	 * @return boolean|integer
   	 */
   	private function updateHobbiesMeta($post_id, $hobbies_meta)
   	{
		$cleared_data = $this->validator->clear_values(array(
			'title' => array(
  				'value'=> (isset($hobbies_meta['title'])) ? $hobbies_meta['title'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   	'default' => '',
			),
			'icon' => array(
  				'value'=> (isset($hobbies_meta['icon'])) ? $hobbies_meta['icon'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vicon',
                   	'default' => '',
			),
			'summary' => array(
  				'value'=> (isset($hobbies_meta['summary'])) ? $hobbies_meta['summary'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,500',
                   	'default' => '',
			),
		));

		update_post_meta( $post_id, 'genio_hobbies_info', array(
			'title' => $cleared_data['title']['value'],
			'icon' => $cleared_data['icon']['value'],
			'summary' => $cleared_data['summary']['value'],		
		));

		$this->error_indicator = ($cleared_data['title']['status'] && $cleared_data['icon']['status']) ? false : 200;

		return $this->error_indicator;
   	}

   	/**
   	 * Update pricing meta data
   	 *
   	 * @since 1.0
   	 * @access private
   	 * @param integer $post_id
   	 * @param array $pricing_meta
   	 * @return boolean|integer
   	 */
   	private function updatePricingMeta($post_id, $pricing_meta)
   	{
		$cleared_data = $this->validator->clear_values(array(
			'title' => array(
  				'value'=> (isset($pricing_meta['title'])) ? $pricing_meta['title'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   	'default' => '',
			),
			'plan_order' => array(
  				'value'=> (isset($pricing_meta['plan_order'])) ? $pricing_meta['plan_order'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vinarray:left,right,center',
                   	'default' => '',
			),
			'price' => array(
  				'value'=> (isset($pricing_meta['price'])) ? $pricing_meta['price'] : '',
                		'sanit'=> 'sintfloat',
                   	'valid'=> 'vintfloat',
                   	'default' => '',
			),
			'price_per' => array(
  				'value'=> (isset($pricing_meta['price_per'])) ? $pricing_meta['price_per'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   	'default' => '',
			),
			'currency' => array(
  				'value'=> (isset($pricing_meta['currency'])) ? $pricing_meta['currency'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,20',
                   	'default' => '',
			),
			'plan_features' => array(
  				'value'=> (isset($pricing_meta['plan_features'])) ? $pricing_meta['plan_features'] : '',
                		'sanit'=> 'smultiinput',
                   	'valid'=> 'vmultiinput',
                   	'default' => '',
			),
			'button_text' => array(
  				'value'=> (isset($pricing_meta['button_text'])) ? $pricing_meta['button_text'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   	'default' => '',
			),
			'button_link' => array(
  				'value'=> (isset($pricing_meta['button_link'])) ? $pricing_meta['button_link'] : '',
                		'sanit'=> 'surl',
                   	'valid'=> 'vnotempty&vurl&vstrlenbetween:1,200',
                   	'default' => '',
			),
		));

		update_post_meta( $post_id, 'genio_pricing_info', array(
			'title' => $cleared_data['title']['value'],
			'plan_order' => $cleared_data['plan_order']['value'],
			'price' => $cleared_data['price']['value'],
			'price_per' => $cleared_data['price_per']['value'],
			'currency' => $cleared_data['currency']['value'],
			'plan_features' => $cleared_data['plan_features']['value'],
			'button_text' => $cleared_data['button_text']['value'],
			'button_link' => $cleared_data['button_link']['value'],		
		));

		$this->error_indicator = ($cleared_data['title']['status'] && $cleared_data['plan_order']['status'] && $cleared_data['price']['status'] && $cleared_data['price_per']['status'] && $cleared_data['currency']['status'] && $cleared_data['plan_features']['status']) ? false : 200;

		return $this->error_indicator;
   	}

   	/**
   	 * Update work process meta data
   	 *
   	 * @since 1.0
   	 * @access private
   	 * @param integer $post_id
   	 * @param array $work_process_meta
   	 * @return boolean|integer
   	 */
   	private function updateWorkProcessMeta($post_id, $work_process_meta)
   	{
		$cleared_data = $this->validator->clear_values(array(
			'title' => array(
  				'value'=> (isset($work_process_meta['title'])) ? $work_process_meta['title'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   	'default' => '',
			),
			'icon' => array(
  				'value'=> (isset($work_process_meta['icon'])) ? $work_process_meta['icon'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vicon',
                   	'default' => '',
			),
			'order' => array(
  				'value'=> (isset($work_process_meta['order'])) ? $work_process_meta['order'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vinarray:1,2,3,4,5,6',
                   	'default' => '',
			),
		));

		update_post_meta( $post_id, 'genio_work_process_info', array(
			'title' => $cleared_data['title']['value'],
			'icon' => $cleared_data['icon']['value'],
			'order' => $cleared_data['order']['value'],		
		));

		$this->error_indicator = ($cleared_data['title']['status'] && $cleared_data['icon']['status'] && $cleared_data['order']['status']) ? false : 200;

		return $this->error_indicator;
   	}

   	/**
   	 * Update testimonial meta data
   	 *
   	 * @since 1.0
   	 * @access private
   	 * @param integer $post_id
   	 * @param array $testimoials_meta
   	 * @return boolean|integer
   	 */
   	private function updateTestimoialsMeta($post_id, $testimoials_meta)
   	{
		$cleared_data = $this->validator->clear_values(array(
			'name' => array(
  				'value'=> (isset($testimoials_meta['name'])) ? $testimoials_meta['name'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   	'default' => '',
			),
			'photo' => array(
  				'value'=> (isset($testimoials_meta['photo'])) ? $testimoials_meta['photo'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vurl&vstrlenbetween:1,200',
                   	'default' => '',
			),
			'job' => array(
  				'value'=> (isset($testimoials_meta['job'])) ? $testimoials_meta['job'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   	'default' => '',
			),
			'company' => array(
  				'value'=> (isset($testimoials_meta['company'])) ? $testimoials_meta['company'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   	'default' => '',
			),
			'main' => array(
  				'value'=> (isset($testimoials_meta['main'])) ? $testimoials_meta['main'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,500',
                   	'default' => '',
			),
		));

		update_post_meta( $post_id, 'genio_testimonial_info', array(
			'name' => $cleared_data['name']['value'],
			'photo' => $cleared_data['photo']['value'],
			'job' => $cleared_data['job']['value'],
			'company' => $cleared_data['company']['value'],
			'main' => $cleared_data['main']['value'],		
		));

		$this->error_indicator = ($cleared_data['name']['status'] && $cleared_data['photo']['status'] && $cleared_data['job']['status'] && $cleared_data['main']['status']) ? false : 200;

		return $this->error_indicator;
   	}

   	/**
   	 * Update client meta data
   	 *
   	 * @since 1.0
   	 * @access private
   	 * @param integer $post_id
   	 * @param array $clients_meta
   	 * @return boolean|integer
   	 */
   	private function updateClientsMeta($post_id, $clients_meta)
   	{
		$cleared_data = $this->validator->clear_values(array(
			'logo' => array(
  				'value'=> (isset($clients_meta['logo'])) ? $clients_meta['logo'] : '',
                		'sanit'=> 'surl',
                   	'valid'=> 'vnotempty&vurl&vstrlenbetween:1,200',
                   	'default' => '',
			),
			'url' => array(
  				'value'=> (isset($clients_meta['url'])) ? $clients_meta['url'] : '',
                		'sanit'=> 'surl',
                   	'valid'=> 'vnotempty&vurl&vstrlenbetween:1,200',
                   	'default' => '',
			),
		));

		update_post_meta( $post_id, 'genio_client_info', array(
			'logo' => $cleared_data['logo']['value'],
			'url' => $cleared_data['url']['value'],			
		));

		$this->error_indicator = ($cleared_data['logo']['status']) ? false : 200;

		return $this->error_indicator;
   	}

   	/**
   	 * Update service meta data
   	 *
   	 * @since 1.0
   	 * @access private
   	 * @param integer $post_id
   	 * @param array $services_meta
   	 * @return boolean|integer
   	 */
   	private function updateServicesMeta($post_id, $services_meta)
   	{
		$cleared_data = $this->validator->clear_values(array(
			'title' => array(
  				'value'=> (isset($services_meta['title'])) ? $services_meta['title'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   	'default' => '',
			),
			'icon' => array(
  				'value'=> (isset($services_meta['icon'])) ? $services_meta['icon'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vicon',
                   	'default' => '',
			),
			'summary' => array(
  				'value'=> (isset($services_meta['summary'])) ? $services_meta['summary'] : '',
                		'sanit'=> 'sstring',
                   	'valid'=> 'vnotempty&vstrlenbetween:1,500',
                   	'default' => '',
			),
		));

		update_post_meta( $post_id, 'genio_service_info', array(
			'title' => $cleared_data['title']['value'],
			'icon' => $cleared_data['icon']['value'],
			'summary' => $cleared_data['summary']['value'],		
		));

		$this->error_indicator = ($cleared_data['title']['status'] && $cleared_data['icon']['status']) ? false : 200;

		return $this->error_indicator;
   	}

  
	/**
	 * Perform update related tasks
	 * 
	 * check latest catched version and if it new show alert.
	 * get latest version if latest check become old
	 *
	 * @since 1.0
	 * @access public
	 * @return null
	 */
	public function updater()
	{
		if ( ( string ) $this->theme_options['genio_wt_basic'][ 'version' ] > ( string ) $this->version ) {
			if ( !current_user_can($this->capability) ) {
				return;
			}
			add_action('admin_notices', array(
				&$this,
				'updatesNotice'
			));
			return;
		}

		// check if update not too old
		$now = time();
		if ( ($now - $this->theme_options['genio_wt_basic'][ 'lastcheck' ]) < $this->notifier_cache_interval ) {
			return false;
		}
		// check if xml extension exist
		if ( !function_exists('simplexml_load_string') ) {
			return false;
		}
		// check if cURL extension exist
		if ( function_exists('curl_init') ) {
			// perform remote check
			$ch = curl_init($this->notifier_xml_file);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_HEADER, 0);
			curl_setopt($ch, CURLOPT_TIMEOUT, 10);
			$response = curl_exec($ch);
			curl_close($ch);
		} else {
			// perform remote check with native php
			$response = file_get_contents($this->notifier_xml_file);
		}

		if ( strpos(( string ) $response, '<notifier>') === false ) {
			// failed response set last check to current timestamp and update
			$this->theme_options['genio_wt_basic'][ 'lastcheck' ] = $now;
			$this->updateOptions('genio_wt_basic');
		} else {
			// success response set last check and latest version and update
			$body = simplexml_load_string($response);
			$this->theme_options['genio_wt_basic'][ 'lastcheck' ] = $now;
			$this->theme_options['genio_wt_basic'][ 'version' ] = ( string ) $body->latest;
			$this->updateOptions('genio_wt_basic');
		}
	}

	/**
	 * Add all theme options
	 *
	 * @since 1.0
	 * @access public
	 */
	public function addOptions()
	{
		foreach ( $this->theme_options as $key => $option) {

			if($key == 'genio_wt_default_template'){
				foreach ($option as $option_key => $option_value) {
					if( !(is_array($option_value)) ){
						if( strpos($option_value, 'media/images') >= 1 ){
							$option[$option_key] = get_theme_root_uri() . '/genio-wt' . $option_value;
						}
					}
				}
			}

			if($key == 'genio_wt_customize'){
				foreach ($option as $option_key => $option_value) {
					if( !(is_array($option_value)) ){
						if( strpos($option_value, 'media/images') >= 1 ){
							$option[$option_key] = get_theme_root_uri() . '/genio-wt' . $option_value;
						}
					}
				}
			}

			add_option( $key, $option);
		}
	}

	/**
	 * Add new option
	 *
	 * Used to add new templates
	 *
	 * @since 1.0
	 * @access public
	 */
	public function addOption($key, $value)
	{
		return (boolean) add_option($key, $value);
	}

	/**
	 * Dump theme options
	 *
	 * @since 1.0
	 * @access public
	 */
	public function dumpOptions()
	{
		foreach ( $this->theme_options as $key => $option) {
			delete_option( $key );
		}
	}

	/**
	 * Update theme options
	 *
	 * @since 1.0
	 * @access public
	 * @param string $key
	 */
	public function updateOptions($key)
	{
		update_option( $key, $this->theme_options[$key]);
	}

	/**
	 * Update option
	 *
	 * @since 1.0
	 * @access public
	 * @param string $key
	 * @param string $value
	 */
	public function updateOption($key, $value)
	{
		return (boolean) update_option( $key, $value);
	}

	/**
	 * Get plugin options
	 *
	 * @since 1.0
	 * @access public
	 * @param string $key
	 */
	public function getOptions()
	{
		foreach ($this->theme_options as $key => $option) {
			$stored_option = get_option($key);
			if($stored_option === false){
				if($key == 'genio_wt_default_template'){
					foreach ($option as $option_key => $option_value) {
						if( !(is_array($option_value)) ){
							if( strpos($option_value, 'media/images') >= 1 ){
								$option[$option_key] = get_theme_root_uri() . '/genio-wt' . $option_value;
							}
						}
					}
				}

				if($key == 'genio_wt_customize'){
					foreach ($option as $option_key => $option_value) {
						if( !(is_array($option_value)) ){
							if( strpos($option_value, 'media/images') >= 1 ){
								$option[$option_key] = get_theme_root_uri() . '/genio-wt' . $option_value;
							}
						}
					}
				}
				add_option( $key, $option);
			}else{
				$this->theme_options[$key] = array_merge( $this->theme_options[$key], $stored_option );
			}

		}
	}

	/**
	 * Show notice to inform admin about update
	 *
	 * @since 1.0
	 * @access public
	 */
	public function updatesNotice()
	{
		?>
		<div class='error'><p><strong><?php
			_e('A new version of genio is available! Please update now.', $this->domain);
		?></strong></p></div>
		<?php
	}

	/**
	 * Show error when CPT required inputs invalid
	 *
	 * @since 1.0
	 * @access public
	 */
	public function cptInvalidField()
	{
		?>
		<div class='error'><p><strong><?php
			_e('Please insert valid values to all required fields.', $this->domain);
		?></strong></p></div>
		<?php
	}

	/**
	 * Show notice to inform admin about update
	 *
	 * @since 1.0
	 * @access public
	 */
	public function settingsUpdated()
	{
		?>
		<div class='updated'><p><strong><?php
			_e('Genio home settings updated successfully.', $this->domain);
		?></strong></p></div>
		<?php
	}

	/**
	 * Enqueue code files in backend
	 *
	 * @since 1.0
	 * @access public
	 */
	public function backEnqueue($hook)
	{
    		$screen = get_current_screen();

    		if ( $hook == 'post.php' && $screen->post_type == 'gen_project' ) {
        		$this->router['table'] = true;
        		$this->router['project'] = true;
    		}
    		if ( $hook == 'post.php' && $screen->post_type == 'gen_skills' ) {
        		$this->router['table'] = true;
        		$this->router['skills'] = true;
    		}
    		if ( $hook == 'post.php' && $screen->post_type == 'gen_resume' ) {
        		$this->router['table'] = true;
        		$this->router['resume'] = true;
    		}
    		if ( $hook == 'post.php' && $screen->post_type == 'gen_hobbies' ) {
        		$this->router['table'] = true;
        		$this->router['hobbies'] = true;
    		}
    		if ( $hook == 'post.php' && $screen->post_type == 'gen_pricing' ) {
        		$this->router['table'] = true;
        		$this->router['pricing'] = true;
    		}
    		if ( $hook == 'post.php' && $screen->post_type == 'gen_work_process' ) {
        		$this->router['table'] = true;
        		$this->router['work_process'] = true;
    		}
    		if ( $hook == 'post.php' && $screen->post_type == 'gen_testimonials' ) {
        		$this->router['table'] = true;
        		$this->router['testimoials'] = true;
    		}
    		if ( $hook == 'post.php' && $screen->post_type == 'gen_clients' ) {
        		$this->router['table'] = true;
        		$this->router['clients'] = true;
    		}
    		if ( $hook == 'post.php' && $screen->post_type == 'gen_services' ) {
        		$this->router['table'] = true;
        		$this->router['services'] = true;
    		}

		if( $this->router['table'] || $this->router['builder'] ){
			wp_enqueue_script('genio_wt_date_time_picker',  plugins_url('/genio-wt/assets/js/jquery.datetimepicker.js'), array( 'jquery' ), '2.3.5', true);
			wp_enqueue_script('genio_wt_backend_scripts', plugins_url('/genio-wt/assets/js/backend_scripts.js'), array( 'jquery' ), '1.0', true);
			wp_enqueue_style('genio_wt_font_awesome', plugins_url('/genio-wt/assets/css/font-awesome.css'), array(), '1.0');
			wp_enqueue_style('genio_wt_backend_styles', plugins_url('/genio-wt/assets/css/backend_styles.css'), array(), '1.0');	
		}
	
		if($this->router['builder'] || $this->router['clients'] || $this->router['testimoials'] || $this->router['resume']){
        		wp_enqueue_media();
       		wp_enqueue_style('dashboard');
        		wp_enqueue_style('thickbox');
			wp_enqueue_style('wp-color-picker');
			wp_enqueue_script('wp-color-picker');
		}
	}

	/**
	 * Print code in backend footer
	 *
	 * @since 1.0
	 * @access public
	 */
	public function backFooterPrint()
	{

	}

	/**
	 * Print code in backend header
	 *
	 * @since 1.0
	 * @access public
	 */
	public function backHeaderPrint()
	{
		?>
		<script type="text/javascript">
		 	/* <![CDATA[ */
			var genio_router = {"table" : <?php if($this->router['table']){ echo "true"; }else{ echo "false"; } ?>,"project" : <?php if($this->router['project']){ echo "true"; }else{ echo "false"; } ?>,"skills" : <?php if($this->router['skills']){ echo "true"; }else{ echo "false"; } ?>,"resume" : <?php if($this->router['resume']){ echo "true"; }else{ echo "false"; } ?>,"hobbies" : <?php if($this->router['hobbies']){ echo "true"; }else{ echo "false"; } ?>,"pricing" : <?php if($this->router['pricing']){ echo "true"; }else{ echo "false"; } ?>,"work_process" : <?php if($this->router['work_process']){ echo "true"; }else{ echo "false"; } ?>,"testimoials" : <?php if($this->router['testimoials']){ echo "true"; }else{ echo "false"; } ?>,"clients" : <?php if($this->router['clients']){ echo "true"; }else{ echo "false"; } ?>,"services" : <?php if($this->router['services']){ echo "true"; }else{ echo "false"; } ?>,"builder" : <?php if($this->router['builder']){ echo "true"; }else{ echo "false"; } ?>,"customizer" : <?php if($this->router['customizer']){ echo "true"; }else{ echo "false"; } ?>};
			<?php if($this->router['builder']){ ?>
				var delete_template_auth = {"ajaxurl": "<?php echo esc_js(admin_url('admin-ajax.php')); ?>", "action": "delete_template", "__ajax_nonce": "<?php echo esc_js(wp_create_nonce('delete_template')); ?>"};
				var demo_import_auth = {"ajaxurl": "<?php echo esc_js(admin_url('admin-ajax.php')); ?>", "action": "import_demo", "__ajax_nonce": "<?php echo esc_js(wp_create_nonce('import_demo')); ?>"};
			<?php } ?>
			/* ]]> */
		</script>
		<?php
	}

	/**
	 * Enqueue code files in frontend
	 *
	 * @since 1.0
	 * @access public
	 */
	public function frontEnqueue()
	{

	}

	/**
	 * Print code in frontend footer
	 *
	 * @since 1.0
	 * @access public
	 */
	public function frontFooterPrint()
	{

	}

	/**
	 * Print code in frontend header
	 *
	 * @since 1.0
	 * @access public
	 */
	public function frontHeaderPrint()
	{

	}

	/**
	 * Catch backend requests
	 * 
	 * @since 1.0
	 * @access public
	 */
	public function requests()
	{

		// register admin notices that may need to be shown
		// 1 => genio home builder settings updated

		if( $this->admin_notice_id == 1 ){
			add_action('admin_notices', array(
				&$this,
				'settingsUpdated'
			));
		}

		if( $this->admin_notice_id == 200 ){
			add_action('admin_notices', array(
				&$this,
				'cptInvalidField'
			));
		}

		// Check if form submitted
		// check if nonce and referrer are valid
		// ckeck access permission 
		// clear data
		// update current template data or save new one
		// send to &done=ya page
		
		if( !(isset($_POST['genio_settings_action'])) || ($_POST['genio_settings_action'] != 'fdg682768r7g68387b8g7b3hg7hn39g7n3sd7') ){
			return;
		}
		check_admin_referer($this->rand_hash);
		$this->checkAccessPerm();

		$cleared_data = $this->validator->clear(array(
				'genio_current_template' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:' . implode(',', array_keys($this->theme_options['genio_wt_customize']['templates'])),
                   		'default' => 'default',
				),
				'genio_template_save_as' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:override,new',
                   		'default' => 'override',
				),
				'genio_new_template_name' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&valnumws&vstrlenbetween:1,20',
                   		'default' => 'New Template',
				),
				'genio_sections_order' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                			'valid' => 'vsecord',
                   		'default' => 'home__nav__profile__hobbies__resume__milestones__skills__services__workprocess__blog__portfolio__pricing__clients__testimonials__contact',
				),
				'genio_home_menu_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,30',
                   		'default' => '',
				),
				'genio_home_show_in_menu' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'no',
				), //(yes|no)
				'genio_home_show' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'no',
				), //(yes|no)
				'genio_home_styles' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:parallax,bottom_image,right_image,gradient',
                   		'default' => 'parallax',
				), //(parallax|bottom_image|right_image|gradient)
				'genio_home_bg' => array(
  					'req'=> 'post',
                			'sanit'=> 'surl',
                   		'valid'=> 'vnotempty&vurl&vstrlenbetween:1,200',
                   		'default' => '',
				),
				'genio_home_photo' => array(
  					'req'=> 'post',
                			'sanit'=> 'surl',
                   		'valid'=> 'vnotempty&vurl&vstrlenbetween:1,200',
                   		'default' => '',
				),
				'genio_home_name' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,150',
                   		'default' => '',
				),
				'genio_home_job_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,150',
                   		'default' => '',
				),
				'genio_nav_show' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				), //(yes|no)

				'genio_profile_menu_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,30',
                   		'default' => '',
				),
				'genio_profile_show_in_menu' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_profile_show' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_profile_icon' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vicon',
                   		'default' => '',
				),
				'genio_profile_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_profile_slogan' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,150',
                   		'default' => '',
				),
				'genio_profile_description' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,900',
                   		'default' => '',
				),
				'genio_profile_story_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_profile_story_main' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,900',
                   		'default' => '',
				),
				'genio_profile_signature' => array(
  					'req'=> 'post',
                			'sanit'=> 'surl',
                   		'valid'=> 'vnotempty&vurl&vstrlenbetween:1,200',
                   		'default' => '',
				),
				'genio_profile_photo' => array(
  					'req'=> 'post',
                			'sanit'=> 'surl',
                   		'valid'=> 'vnotempty&vurl&vstrlenbetween:1,200',
                   		'default' => '',
				),
				'genio_profile_cv' => array(
  					'req'=> 'post',
                			'sanit'=> 'surl',
                   		'valid'=> 'vnotempty&vurl&vstrlenbetween:1,200',
                   		'default' => '',
				),
				'genio_profile_information_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_profile_your_name' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,100',
                   		'default' => '',
				),
				'genio_profile_your_age' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_profile_your_phone' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_profile_your_email' => array(
  					'req'=> 'post',
                			'sanit'=> 'semail',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,60&vemail',
                   		'default' => '',
				),
				'genio_profile_your_address' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,100',
                   		'default' => '',
				),
		
				'genio_hobbies_menu_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,30',
                   		'default' => '',
				),
				'genio_hobbies_show_in_menu' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_hobbies_show' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_hobbies_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_hobbies_slogan' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,150',
                   		'default' => '',
				),
				'genio_hobbies_bg' => array(
  					'req'=> 'post',
                			'sanit'=> 'surl',
                   		'valid'=> 'vnotempty&vurl&vstrlenbetween:1,200',
                   		'default' => '',
				),
				
				'genio_resume_menu_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,30',
                   		'default' => '',
				),
				'genio_resume_show_in_menu' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_resume_show' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_resume_icon' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vicon',
                   		'default' => '',
				),
				'genio_resume_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_resume_slogan' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,150',
                   		'default' => '',
				),
				'genio_resume_description' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,900',
                   		'default' => '',
				),
				'genio_resume_education_icon' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vicon',
                   		'default' => '',
				),
				'genio_resume_education_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_resume_experience_icon' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vicon',
                   		'default' => '',
				),
				'genio_resume_experience_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_resume_recognition_icon' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vicon',
                   		'default' => '',
				),
				'genio_resume_recognition_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				
				'genio_milestone_menu_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,30',
                   		'default' => '',
				),
				'genio_milestone_show_in_menu' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_milestone_show' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_first_box_icon' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vicon',
                   		'default' => '',
				),
				'genio_first_box_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_first_box_count' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_second_box_icon' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vicon',
                   		'default' => '',
				),
				'genio_second_box_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_second_box_count' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_third_box_icon' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vicon',
                   		'default' => '',
				),
				'genio_third_box_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_third_box_count' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_fourth_box_icon' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vicon',
                   		'default' => '',
				),
				'genio_fourth_box_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_fourth_box_count' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				
				'genio_skills_menu_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,30',
                   		'default' => '',
				),
				'genio_skills_show_in_menu' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_skills_show' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_skills_icon' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vicon',
                   		'default' => '',
				),
				'genio_skills_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_skills_slogan' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,150',
                   		'default' => '',
				),
				'genio_skills_description' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,900',
                   		'default' => '',
				),
				
				'genio_services_menu_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,30',
                   		'default' => '',
				),
				'genio_services_show_in_menu' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_services_show' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_services_icon' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vicon',
                   		'default' => '',
				),
				'genio_services_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_services_slogan' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,150',
                   		'default' => '',
				),
				'genio_services_description' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,900',
                   		'default' => '',
				),
				
				'genio_workprocess_menu_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,30',
                   		'default' => '',
				),
				'genio_workprocess_show_in_menu' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_workprocess_show' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_workprocess_bg' => array(
  					'req'=> 'post',
                			'sanit'=> 'surl',
                   		'valid'=> 'vnotempty&vurl&vstrlenbetween:1,200',
                   		'default' => '',
				),
				'genio_workprocess_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_workprocess_slogan' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,150',
                   		'default' => '',
				),
			
				'genio_blog_menu_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,30',
                   		'default' => '',
				),
				'genio_blog_show_in_menu' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_blog_show' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_blog_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' =>'',
				),
				'genio_blog_slogan' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,150',
                   		'default' => '',
				),
				'genio_blog_count' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:1,2,3,4,5,6',
                   		'default' => '3',
				),
				'genio_blog_link_text' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				
				'genio_portfolio_menu_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,30',
                   		'default' => '',
				),
				'genio_portfolio_show_in_menu' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_portfolio_show' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_portfolio_icon' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vicon',
                   		'default' => '',
				),
				'genio_portfolio_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_portfolio_slogan' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,150',
                   		'default' =>'',
				),
				'genio_portfolio_description' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,900',
                   		'default' => '',
				),
				'genio_portfolio_count' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:5,10,15,20,25,30,all',
                   		'default' => '15',
				),
				'genio_portfolio_link_text' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				
				'genio_pricing_menu_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,30',
                   		'default' => '',
				),
				'genio_pricing_show_in_menu' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_pricing_show' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_pricing_icon' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vicon',
                   		'default' => '',
				),
				'genio_pricing_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_pricing_slogan' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,150',
                   		'default' => '',
				),
				'genio_pricing_description' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,900',
                   		'default' => '',
				),
		
				'genio_clients_menu_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,30',
                   		'default' => '',
				),
				'genio_clients_show_in_menu' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_clients_show' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_clients_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_clients_slogan' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,150',
                   		'default' => '',
				),
				
				'genio_testimonials_menu_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,30',
                   		'default' => '',
				),
				'genio_testimonials_show_in_menu' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_testimonials_show' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_testimonials_bg' => array(
  					'req'=> 'post',
                			'sanit'=> 'surl',
                   		'valid'=> 'vnotempty&vurl&vstrlenbetween:1,200',
                   		'default' => '',
				),
				'genio_testimonials_count' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:5,10,15,20,25,30',
                   		'default' => '15',
				),
				
				'genio_contact_menu_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,30',
                   		'default' => '',
				),
				'genio_contact_show_in_menu' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_contact_show' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_contact_icon' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vicon',
                   		'default' => '',
				),
				'genio_contact_title' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,50',
                   		'default' => '',
				),
				'genio_contact_slogan' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,150',
                   		'default' => '',
				),
				'genio_contact_description' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,900',
                   		'default' => '',
				),
				'genio_contact_form_show' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_contact_email' => array(
  					'req'=> 'post',
                			'sanit'=> 'semail',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,60&vemail',
                   		'default' => '',
				),
				'genio_hireme_form_show' => array(
  					'req'=> 'post',
                			'sanit'=> 'sstring',
                   		'valid'=> 'vinarray:yes,no',
                   		'default' => 'yes',
				),
				'genio_hireme_email' => array(
  					'req'=> 'post',
                			'sanit'=> 'semail',
                   		'valid'=> 'vnotempty&vstrlenbetween:1,60&vemail',
                   		'default' => '',
				),
		));


		$template_data['sections_order'] = explode('__', $cleared_data['genio_sections_order']['value']);

		$template_data['nav_s_s'] = $cleared_data['genio_nav_show']['value'];

		$template_data['home_s_mt'] = $cleared_data['genio_home_menu_title']['value'];
		$template_data['home_s_sim'] = $cleared_data['genio_home_show_in_menu']['value'];
		$template_data['home_s_s'] = $cleared_data['genio_home_show']['value'];
		$template_data['home_s_hs'] = $cleared_data['genio_home_styles']['value'];
		$template_data['home_s_bg'] = $cleared_data['genio_home_bg']['value'];
		$template_data['home_s_img'] = $cleared_data['genio_home_photo']['value'];
		$template_data['home_s_n'] = $cleared_data['genio_home_name']['value'];
		$template_data['home_s_jt'] = $cleared_data['genio_home_job_title']['value'];

		$template_data['profile_s_mt'] = $cleared_data['genio_profile_menu_title']['value'];
		$template_data['profile_s_sim'] = $cleared_data['genio_profile_show_in_menu']['value'];
		$template_data['profile_s_s'] = $cleared_data['genio_profile_show']['value'];
		$template_data['profile_s_ic'] = $cleared_data['genio_profile_icon']['value'];
		$template_data['profile_s_tit'] = $cleared_data['genio_profile_title']['value'];
		$template_data['profile_s_slog'] = $cleared_data['genio_profile_slogan']['value'];
		$template_data['profile_s_desc'] = $cleared_data['genio_profile_description']['value'];
		$template_data['profile_s_sto_tit'] = $cleared_data['genio_profile_story_title']['value'];
		$template_data['profile_s_sto_mai'] = $cleared_data['genio_profile_story_main']['value'];
		$template_data['profile_s_sign'] = $cleared_data['genio_profile_signature']['value'];
		$template_data['profile_s_phot'] = $cleared_data['genio_profile_photo']['value'];
		$template_data['profile_s_cv'] = $cleared_data['genio_profile_cv']['value'];
		$template_data['profile_s_inf_tit'] = $cleared_data['genio_profile_information_title']['value'];
		$template_data['profile_s_yo_nam'] = $cleared_data['genio_profile_your_name']['value'];
		$template_data['profile_s_yo_age'] = $cleared_data['genio_profile_your_age']['value'];
		$template_data['profile_s_yo_phon'] = $cleared_data['genio_profile_your_phone']['value'];
		$template_data['profile_s_yo_emai'] = $cleared_data['genio_profile_your_email']['value'];
		$template_data['profile_s_yo_addrs'] = $cleared_data['genio_profile_your_address']['value'];

		$template_data['hobbies_s_mt'] = $cleared_data['genio_hobbies_menu_title']['value'];
		$template_data['hobbies_s_sim'] = $cleared_data['genio_hobbies_show_in_menu']['value'];
		$template_data['hobbies_s_s'] = $cleared_data['genio_hobbies_show']['value'];
		$template_data['hobbies_s_tit'] = $cleared_data['genio_hobbies_title']['value'];
		$template_data['hobbies_s_slog'] = $cleared_data['genio_hobbies_slogan']['value'];
		$template_data['hobbies_s_bg'] = $cleared_data['genio_hobbies_bg']['value'];

		$template_data['resume_s_mt'] = $cleared_data['genio_resume_menu_title']['value'];
		$template_data['resume_s_sim'] = $cleared_data['genio_resume_show_in_menu']['value'];
		$template_data['resume_s_s'] = $cleared_data['genio_resume_show']['value'];
		$template_data['resume_s_res_ic'] = $cleared_data['genio_resume_icon']['value'];
		$template_data['resume_s_tit'] = $cleared_data['genio_resume_title']['value'];
		$template_data['resume_s_slog'] = $cleared_data['genio_resume_slogan']['value'];
		$template_data['resume_s_desc'] = $cleared_data['genio_resume_description']['value'];
		$template_data['resume_s_ed_ic'] = $cleared_data['genio_resume_education_icon']['value'];
		$template_data['resume_s_ed_tit'] = $cleared_data['genio_resume_education_title']['value'];
		$template_data['resume_s_ex_ic'] = $cleared_data['genio_resume_experience_icon']['value'];
		$template_data['resume_s_ex_tit'] = $cleared_data['genio_resume_experience_title']['value'];
		$template_data['resume_s_rec_ic'] = $cleared_data['genio_resume_recognition_icon']['value'];
		$template_data['resume_s_rec_tit'] = $cleared_data['genio_resume_recognition_title']['value'];

		$template_data['milesto_s_mt'] = $cleared_data['genio_milestone_menu_title']['value'];
		$template_data['milesto_s_sim'] = $cleared_data['genio_milestone_show_in_menu']['value'];
		$template_data['milesto_s_s'] = $cleared_data['genio_milestone_show']['value'];
		$template_data['milesto_fi_ic'] = $cleared_data['genio_first_box_icon']['value'];
		$template_data['milesto_fi_tit'] = $cleared_data['genio_first_box_title']['value'];
		$template_data['milesto_fi_cou'] = $cleared_data['genio_first_box_count']['value'];
		$template_data['milesto_se_ic'] = $cleared_data['genio_second_box_icon']['value'];
		$template_data['milesto_se_tit'] = $cleared_data['genio_second_box_title']['value'];
		$template_data['milesto_se_cou'] = $cleared_data['genio_second_box_count']['value'];
		$template_data['milesto_th_ic'] = $cleared_data['genio_third_box_icon']['value'];
		$template_data['milesto_th_tit'] = $cleared_data['genio_third_box_title']['value'];
		$template_data['milesto_th_cou'] = $cleared_data['genio_third_box_count']['value'];
		$template_data['milesto_fo_ic'] = $cleared_data['genio_fourth_box_icon']['value'];
		$template_data['milesto_fo_tit'] = $cleared_data['genio_fourth_box_title']['value'];
		$template_data['milesto_fo_cou'] = $cleared_data['genio_fourth_box_count']['value'];

		$template_data['skills_s_mt'] = $cleared_data['genio_skills_menu_title']['value'];
		$template_data['skills_s_sim'] = $cleared_data['genio_skills_show_in_menu']['value'];
		$template_data['skills_s_ic'] = $cleared_data['genio_skills_icon']['value'];
		$template_data['skills_s_s'] = $cleared_data['genio_skills_show']['value'];
		$template_data['skills_s_tit'] = $cleared_data['genio_skills_title']['value'];
		$template_data['skills_s_slog'] = $cleared_data['genio_skills_slogan']['value'];
		$template_data['skills_s_desc'] = $cleared_data['genio_skills_description']['value'];

		$template_data['services_s_mt'] = $cleared_data['genio_services_menu_title']['value'];
		$template_data['services_s_sim'] = $cleared_data['genio_services_show_in_menu']['value'];
		$template_data['services_s_ic'] = $cleared_data['genio_services_icon']['value'];
		$template_data['services_s_s'] = $cleared_data['genio_services_show']['value'];
		$template_data['services_s_tit'] = $cleared_data['genio_services_title']['value'];
		$template_data['services_s_slog'] = $cleared_data['genio_services_slogan']['value'];
		$template_data['services_s_desc'] = $cleared_data['genio_services_description']['value'];

		$template_data['process_s_mt'] = $cleared_data['genio_workprocess_menu_title']['value'];
		$template_data['process_s_sim'] = $cleared_data['genio_workprocess_show_in_menu']['value'];
		$template_data['process_s_s'] = $cleared_data['genio_workprocess_show']['value'];
		$template_data['process_s_bg'] = $cleared_data['genio_workprocess_bg']['value'];
		$template_data['process_s_tit'] = $cleared_data['genio_workprocess_title']['value'];
		$template_data['process_s_slog'] = $cleared_data['genio_workprocess_slogan']['value'];

		$template_data['blog_s_mt'] = $cleared_data['genio_blog_menu_title']['value'];
		$template_data['blog_s_sim'] = $cleared_data['genio_blog_show_in_menu']['value'];
		$template_data['blog_s_s'] = $cleared_data['genio_blog_show']['value'];
		$template_data['blog_s_tit'] = $cleared_data['genio_blog_title']['value'];
		$template_data['blog_s_slog'] = $cleared_data['genio_blog_slogan']['value'];
		$template_data['blog_s_sh_on'] = $cleared_data['genio_blog_count']['value'];
		$template_data['blog_s_lin_tex'] = $cleared_data['genio_blog_link_text']['value'];

		$template_data['portfolio_s_mt'] = $cleared_data['genio_portfolio_menu_title']['value'];
		$template_data['portfolio_s_sim'] = $cleared_data['genio_portfolio_show_in_menu']['value'];
		$template_data['portfolio_s_s'] = $cleared_data['genio_portfolio_show']['value'];
		$template_data['portfolio_s_ic'] = $cleared_data['genio_portfolio_icon']['value'];
		$template_data['portfolio_s_tit'] = $cleared_data['genio_portfolio_title']['value'];
		$template_data['portfolio_s_slog'] = $cleared_data['genio_portfolio_slogan']['value'];
		$template_data['portfolio_s_desc'] = $cleared_data['genio_portfolio_description']['value'];
		$template_data['portfolio_s_sh_on'] = $cleared_data['genio_portfolio_count']['value'];
		$template_data['portfolio_s_lin_tex'] = $cleared_data['genio_portfolio_link_text']['value'];

		$template_data['pricing_s_mt'] = $cleared_data['genio_pricing_menu_title']['value'];
		$template_data['pricing_s_sim'] = $cleared_data['genio_pricing_show_in_menu']['value'];
		$template_data['pricing_s_s'] = $cleared_data['genio_pricing_show']['value'];
		$template_data['pricing_s_ic'] = $cleared_data['genio_pricing_icon']['value'];
		$template_data['pricing_s_tit'] = $cleared_data['genio_pricing_title']['value'];
		$template_data['pricing_s_slog'] = $cleared_data['genio_pricing_slogan']['value'];
		$template_data['pricing_s_desc'] = $cleared_data['genio_pricing_description']['value'];

		$template_data['clients_s_mt'] = $cleared_data['genio_clients_menu_title']['value'];
		$template_data['clients_s_sim'] = $cleared_data['genio_clients_show_in_menu']['value'];
		$template_data['clients_s_s'] = $cleared_data['genio_clients_show']['value'];
		$template_data['clients_s_tit'] = $cleared_data['genio_clients_title']['value'];
		$template_data['clients_s_slog'] = $cleared_data['genio_clients_slogan']['value'];

		$template_data['testimonial_s_mt'] = $cleared_data['genio_testimonials_menu_title']['value'];
		$template_data['testimonial_s_sim'] = $cleared_data['genio_testimonials_show_in_menu']['value'];
		$template_data['testimonial_s_s'] = $cleared_data['genio_testimonials_show']['value'];
		$template_data['testimonial_s_bg'] = $cleared_data['genio_testimonials_bg']['value'];
		$template_data['testimonial_s_sh_on'] = $cleared_data['genio_testimonials_count']['value'];

		$template_data['contact_s_mt'] = $cleared_data['genio_contact_menu_title']['value'];
		$template_data['contact_s_sim'] = $cleared_data['genio_contact_show_in_menu']['value'];
		$template_data['contact_s_s'] = $cleared_data['genio_contact_show']['value'];
		$template_data['contact_s_ic'] = $cleared_data['genio_contact_icon']['value'];
		$template_data['contact_s_tit'] = $cleared_data['genio_contact_title']['value'];
		$template_data['contact_s_slog'] = $cleared_data['genio_contact_slogan']['value'];
		$template_data['contact_s_desc'] = $cleared_data['genio_contact_description']['value'];
		$template_data['contact_s_scf'] = $cleared_data['genio_contact_form_show']['value'];
		$template_data['contact_s_cem'] = $cleared_data['genio_contact_email']['value'];
		$template_data['contact_s_shf'] = $cleared_data['genio_hireme_form_show']['value'];
		$template_data['contact_s_hem'] = $cleared_data['genio_hireme_email']['value'];

		$template_data = stripslashes_deep($template_data);

		if($cleared_data['genio_template_save_as']['value'] == 'override'){
		
			$template = $this->toSlug($cleared_data['genio_current_template']['value']);
			$this->updateOption('genio_wt_' . $template . '_template', $template_data);
		
		}elseif($cleared_data['genio_template_save_as']['value'] == 'new'){
		
			$this->theme_options['genio_wt_customize']['templates'][$this->toSlug($cleared_data['genio_new_template_name']['value'])] = $cleared_data['genio_new_template_name']['value'];
			$this->updateOptions('genio_wt_customize');
			$template = $this->toSlug($cleared_data['genio_new_template_name']['value']);
			$this->updateOption('genio_wt_' . $template . '_template', $template_data);
		
		}
          	
            wp_redirect(admin_url('themes.php?page=clivern_genio&template=' . $template . '&done=1'));
            exit();
	}

	/**
	 * Delete template home action
	 *
	 * @since 1.0
	 * @access public
	 * @return string
	 */
	public function deleteTemplateAction()
	{
            $response = array(
                  'status' => 'error',
                  'data' => array()
            );

            $templates = $this->theme_options['genio_wt_customize']['templates'];
            unset($templates['default']);

            $action = ( (isset($_POST['action'])) && ($_POST['action'] == 'delete_template') ) ? trim($_POST['action']) : false;
            $template = ( (isset($_POST['template'])) && (array_key_exists($_POST['template'], $templates)) ) ? trim($_POST['template']) : false;
            
            if( ($action === false) || ($template === false) ){
            	header('Content: application/json');
            	echo json_encode($response);
            	die;
            }

            check_ajax_referer($action, '__ajax_nonce');

            unset($this->theme_options['genio_wt_customize']['templates'][$template]);
            if( $this->theme_options['genio_wt_customize']['template'] == $template ){
            	$this->theme_options['genio_wt_customize']['template'] = 'default';
            }

            delete_option( "genio_wt_" . $template . "_template" );
            $this->updateOptions('genio_wt_customize');
            $response['status'] = 'success';

            header('Content: application/json');
            echo json_encode($response);
            die;
	}

	/**
	 * Import demo action
	 *
	 * @since 1.0
	 * @access public
	 * @return string
	 */
	public function importDemoAction()
	{
            $response = array(
                  'status' => 'error',
                  'data' => array()
            );

            $action = ( (isset($_POST['action'])) && ($_POST['action'] == 'import_demo') ) ? trim($_POST['action']) : false;
            
            if( $action === false ){
            	 $response['data'] = 'error';
            	header('Content: application/json');
            	echo json_encode($response);
            	die;
            }

            check_ajax_referer($action, '__ajax_nonce');

            if($this->importer->import()){
            	$response['status'] = 'success';
            	$response['data'] = __('Amazing You Imported Demo Data. Have Fun!', $this->domain);
            }
	
            header('Content: application/json');
            echo json_encode($response);
            die;
	}

	/**
	 * Create slug from string
	 *
	 * @since 1.0
	 * @param string $string
	 * @return string
	 */
	private function toSlug($string){
   		return strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '_', $string)));
	}

	/**
	 * Add new contact methods to user profile
	 *
	 * @since 1.0
	 * @access public
	 * @param array $contactmethods
	 */
	public function addToProfile( $contactmethods ) {
		$contactmethods['genio_google_profile'] = __('Google Profile URL', $this->domain);
		$contactmethods['genio_twitter_profile'] = __('Twitter Profile URL', $this->domain);
		$contactmethods['genio_facebook_profile'] = __('Facebook Profile URL', $this->domain);	
		return $contactmethods;
	}

	/**
	 * Load home template options
	 *
	 * @since 1.0
	 * @access private
	 */
	private function templateLoader()
	{
		if( $this->current_template === false ){
			$this->current_template = $this->theme_options['genio_wt_customize']['template'];
		}elseif( array_key_exists($this->current_template, $this->theme_options['genio_wt_customize']['templates']) ){
			$this->current_template = $this->current_template;
		}else{
			$this->current_template = $this->theme_options['genio_wt_customize']['template'];
		}

		$this->current_template_data = get_option( 'genio_wt_' . $this->current_template . '_template', $this->theme_options['genio_wt_default_template'] );
	}
	
	/**
	 * Get a list of icons
	 *
	 * @since 1.0
	 * @return array
	 */
	private function fontIcons()
	{
		$icons_list = array('fa-glass', 'fa-music', 'fa-search', 'fa-envelope-o', 'fa-heart', 'fa-star', 'fa-star-o', 'fa-user', 'fa-film', 'fa-th-large', 'fa-th', 'fa-th-list', 'fa-check', 'fa-times', 'fa-search-plus', 'fa-search-minus', 'fa-power-off', 'fa-signal', 'fa-cog', 'fa-trash-o', 'fa-home', 'fa-file-o', 'fa-clock-o', 'fa-road', 'fa-download', 'fa-arrow-circle-o-down', 'fa-arrow-circle-o-up', 'fa-inbox', 'fa-play-circle-o', 'fa-repeat', 'fa-refresh', 'fa-list-alt', 'fa-lock', 'fa-flag', 'fa-headphones', 'fa-volume-off', 'fa-volume-down', 'fa-volume-up', 'fa-qrcode', 'fa-barcode', 'fa-tag', 'fa-tags', 'fa-book', 'fa-bookmark', 'fa-print', 'fa-camera', 'fa-font', 'fa-bold', 'fa-italic', 'fa-text-height', 'fa-text-width', 'fa-align-left', 'fa-align-center', 'fa-align-right', 'fa-align-justify', 'fa-list', 'fa-outdent', 'fa-indent', 'fa-video-camera', 'fa-picture-o', 'fa-pencil', 'fa-map-marker', 'fa-adjust', 'fa-tint', 'fa-pencil-square-o', 'fa-share-square-o', 'fa-check-square-o', 'fa-arrows', 'fa-step-backward', 'fa-fast-backward', 'fa-backward', 'fa-play', 'fa-pause', 'fa-stop', 'fa-forward', 'fa-fast-forward', 'fa-step-forward', 'fa-eject', 'fa-chevron-left', 'fa-chevron-right', 'fa-plus-circle', 'fa-minus-circle', 'fa-times-circle', 'fa-check-circle', 'fa-question-circle', 'fa-info-circle', 'fa-crosshairs', 'fa-times-circle-o', 'fa-check-circle-o', 'fa-ban', 'fa-arrow-left', 'fa-arrow-right', 'fa-arrow-up', 'fa-arrow-down', 'fa-share', 'fa-expand', 'fa-compress', 'fa-plus', 'fa-minus', 'fa-asterisk', 'fa-exclamation-circle', 'fa-gift', 'fa-leaf', 'fa-fire', 'fa-eye', 'fa-eye-slash', 'fa-exclamation-triangle', 'fa-plane', 'fa-calendar', 'fa-random', 'fa-comment', 'fa-magnet', 'fa-chevron-up', 'fa-chevron-down', 'fa-retweet', 'fa-shopping-cart', 'fa-folder', 'fa-folder-open', 'fa-arrows-v', 'fa-arrows-h', 'fa-bar-chart-o', 'fa-twitter-square', 'fa-facebook-square', 'fa-camera-retro', 'fa-key', 'fa-cogs', 'fa-comments', 'fa-thumbs-o-up', 'fa-thumbs-o-down', 'fa-star-half', 'fa-heart-o', 'fa-sign-out', 'fa-linkedin-square', 'fa-thumb-tack', 'fa-external-link', 'fa-sign-in', 'fa-trophy', 'fa-github-square', 'fa-upload', 'fa-lemon-o', 'fa-phone', 'fa-square-o', 'fa-bookmark-o', 'fa-phone-square', 'fa-twitter', 'fa-facebook', 'fa-github', 'fa-unlock', 'fa-credit-card', 'fa-rss', 'fa-hdd-o', 'fa-bullhorn', 'fa-bell', 'fa-certificate', 'fa-hand-o-right', 'fa-hand-o-left', 'fa-hand-o-up', 'fa-hand-o-down', 'fa-arrow-circle-left', 'fa-arrow-circle-right', 'fa-arrow-circle-up', 'fa-arrow-circle-down', 'fa-globe', 'fa-wrench', 'fa-tasks', 'fa-filter', 'fa-briefcase', 'fa-arrows-alt', 'fa-users', 'fa-link', 'fa-cloud', 'fa-flask', 'fa-scissors', 'fa-files-o', 'fa-paperclip', 'fa-floppy-o', 'fa-square', 'fa-bars', 'fa-list-ul', 'fa-list-ol', 'fa-strikethrough', 'fa-underline', 'fa-table', 'fa-magic', 'fa-truck', 'fa-pinterest', 'fa-pinterest-square', 'fa-google-plus-square', 'fa-google-plus', 'fa-money', 'fa-caret-down', 'fa-caret-up', 'fa-caret-left', 'fa-caret-right', 'fa-columns', 'fa-sort', 'fa-sort-asc', 'fa-sort-desc', 'fa-envelope', 'fa-linkedin', 'fa-undo', 'fa-gavel', 'fa-tachometer', 'fa-comment-o', 'fa-comments-o', 'fa-bolt', 'fa-sitemap', 'fa-umbrella', 'fa-clipboard', 'fa-lightbulb-o', 'fa-exchange', 'fa-cloud-download', 'fa-cloud-upload', 'fa-user-md', 'fa-stethoscope', 'fa-suitcase', 'fa-bell-o', 'fa-coffee', 'fa-cutlery', 'fa-file-text-o', 'fa-building-o', 'fa-hospital-o', 'fa-ambulance', 'fa-medkit', 'fa-fighter-jet', 'fa-beer', 'fa-h-square', 'fa-plus-square', 'fa-angle-double-left', 'fa-angle-double-right', 'fa-angle-double-up', 'fa-angle-double-down', 'fa-angle-left', 'fa-angle-right', 'fa-angle-up', 'fa-angle-down', 'fa-desktop', 'fa-laptop', 'fa-tablet', 'fa-mobile', 'fa-circle-o', 'fa-quote-left', 'fa-quote-right', 'fa-spinner', 'fa-circle', 'fa-reply', 'fa-github-alt', 'fa-folder-o', 'fa-folder-open-o', 'fa-smile-o', 'fa-frown-o', 'fa-meh-o', 'fa-gamepad', 'fa-keyboard-o', 'fa-flag-o', 'fa-flag-checkered', 'fa-terminal', 'fa-code', 'fa-reply-all', 'fa-mail-reply-all', 'fa-star-half-o', 'fa-location-arrow', 'fa-crop', 'fa-code-fork', 'fa-chain-broken', 'fa-question', 'fa-info', 'fa-exclamation', 'fa-superscript', 'fa-subscript', 'fa-eraser', 'fa-puzzle-piece', 'fa-microphone', 'fa-microphone-slash', 'fa-shield', 'fa-calendar-o', 'fa-fire-extinguisher', 'fa-rocket', 'fa-maxcdn', 'fa-chevron-circle-left', 'fa-chevron-circle-right', 'fa-chevron-circle-up', 'fa-chevron-circle-down', 'fa-html5', 'fa-css3', 'fa-anchor', 'fa-unlock-alt', 'fa-bullseye', 'fa-ellipsis-h', 'fa-ellipsis-v', 'fa-rss-square', 'fa-play-circle', 'fa-ticket', 'fa-minus-square', 'fa-minus-square-o', 'fa-level-up', 'fa-level-down', 'fa-check-square', 'fa-pencil-square', 'fa-external-link-square', 'fa-share-square', 'fa-compass', 'fa-caret-square-o-down', 'fa-caret-square-o-up', 'fa-caret-square-o-right', 'fa-eur', 'fa-gbp', 'fa-usd', 'fa-inr', 'fa-jpy', 'fa-rub', 'fa-krw', 'fa-btc', 'fa-file', 'fa-file-text', 'fa-sort-alpha-asc', 'fa-sort-alpha-desc', 'fa-sort-amount-asc', 'fa-sort-amount-desc', 'fa-sort-numeric-asc', 'fa-sort-numeric-desc', 'fa-thumbs-up', 'fa-thumbs-down', 'fa-youtube-square', 'fa-youtube', 'fa-xing', 'fa-xing-square', 'fa-youtube-play', 'fa-dropbox', 'fa-stack-overflow', 'fa-instagram', 'fa-flickr', 'fa-adn', 'fa-bitbucket', 'fa-bitbucket-square', 'fa-tumblr', 'fa-tumblr-square', 'fa-long-arrow-down', 'fa-long-arrow-up', 'fa-long-arrow-left', 'fa-long-arrow-right', 'fa-apple', 'fa-windows', 'fa-android', 'fa-linux', 'fa-dribbble', 'fa-skype', 'fa-foursquare', 'fa-trello', 'fa-female', 'fa-male', 'fa-gittip', 'fa-sun-o', 'fa-moon-o', 'fa-archive', 'fa-bug', 'fa-vk', 'fa-weibo', 'fa-renren', 'fa-pagelines', 'fa-stack-exchange', 'fa-arrow-circle-o-right', 'fa-arrow-circle-o-left', 'fa-caret-square-o-left', 'fa-dot-circle-o', 'fa-wheelchair', 'fa-vimeo-square', 'fa-try', 'fa-plus-square-o');
		return $icons_list;
	}

      /**
       * Check if user in the right place
       *
       * @since 1.0
       * @access private
       */
      private function checkAccessPerm()
      {
            if ( !current_user_can($this->capability) ) {
                  // die
                  wp_die(__('You do not have sufficient permissions to access this page.', $this->domain), 'Genio');
            }
      }
}