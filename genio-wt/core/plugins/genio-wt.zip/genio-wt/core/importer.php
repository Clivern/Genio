<?php
/**
 * Genio - WordPress Theme Core Plugin
 *
 * @version 1.0
 * @package genio-wt
 * @author  Clivern <support@clivern.com>
 * @link    http://clivern.com/
 * @copyright     Copyright (c) 2015, Clivern (http://clivern.com/)
 * @license http://themeforest.net/licenses GPL
 */

class GENIO_WT_IMPORTER
{


	/**
	 * Import sample data
	 *
	 * @since 1.0
	 * @access public
	 * @return boolean
	 */
	public function import()
	{
		$user_id = get_current_user_id();
		$media_root = get_theme_root_uri().'/genio-wt/media/images';
		$this->importTestimonials($user_id, $media_root);
		$this->importClients($user_id, $media_root);
		$this->importServices($user_id, $media_root);
		$this->importHobbies($user_id, $media_root);
		$this->importProcess($user_id, $media_root);
		$this->importPricing($user_id, $media_root);
		$this->importResume($user_id, $media_root);
		$this->importSkills($user_id, $media_root);
		$this->importProjects($user_id, $media_root);
		$this->importHomeTemplates($user_id, $media_root);
		return true;
	}

	/**
	 * Import Projects
	 *
	 * @since 1.0
	 * @access public
	 * @param integer $user_id
	 * @param string $media_root
	 * @return boolean
	 */
	public function importProjects($user_id, $media_root)
	{
		$web_design_id = wp_insert_category(array(
  			'cat_name' => 'Web Design' ,
  			'taxonomy' => 'gen_proj_sk_categ',
		));
		$wordpress_id = wp_insert_category(array(
  			'cat_name' => 'Wordpress' ,
  			'taxonomy' => 'gen_proj_sk_categ',
		));
		$html_id = wp_insert_category(array(
  			'cat_name' => 'HTML' ,
  			'taxonomy' => 'gen_proj_sk_categ',
		));

		$projects = array(
			1 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Image Project',
				'post_name' => 'image-project',
				'post_content' => '<h5 class="bold text-capitalize">project description</h5><p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC.</p><p>This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>',
				'post_type' => 'gen_project',
				'tax_input' => array( 'gen_proj_sk_categ' => $web_design_id ),
			),

			2 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Video Project',
				'post_name' => 'video-project',
				'post_content' => '<h5 class="bold text-capitalize">project description</h5><p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC.</p><p>This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>',
				'post_type' => 'gen_project',
				'tax_input' => array( 'gen_proj_sk_categ' => $wordpress_id ),
			),
			3 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Slider Project',
				'post_name' => 'slider-project',
				'post_content' => '<h5 class="bold text-capitalize">project description</h5><p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC.</p><p>This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>',
				'post_type' => 'gen_project',
				'tax_input' => array( 'gen_proj_sk_categ' => $html_id ),
			),
		);

		$projects_meta = array(
			1 => array(
        			'header_img' => $media_root . '/backgrounds/work.png',
        			'client' => 'Envato',
        			'role' => 'Developer',
        			'date' => '2014-01-29',
        			'link_text' => 'Visit Website',
        			'link' => home_url('/#'),
        			'tes' => 'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur.',
        			'tes_by' => 'Envato CEO',
			),
			2 => array(
        			'header_img' => $media_root . '/backgrounds/work.png',
        			'client' => 'Envato',
        			'role' => 'Developer',
        			'date' => '2014-05-10',
        			'link_text' => 'Visit Website',
        			'link' => home_url('/#'),
        			'tes' => 'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur.',
        			'tes_by' => 'Envato CEO',
			),
			3 => array(
        			'header_img' => $media_root . '/backgrounds/work.png',
        			'client' => 'Envato',
        			'role' => 'Developer',
        			'date' => '2015-02-10',
        			'link_text' => 'Visit Website',
        			'link' => home_url('/#'),
        			'tes' => 'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur.',
        			'tes_by' => 'Envato CEO',
			),
		);

		foreach ($projects as $key => $value) {
			$post_id = wp_insert_post( $value );
			update_post_meta( $post_id, 'genio_project_info', $projects_meta[$key]);
		}
		return true;
	}

	/**
	 * Import Home Templates
	 *
	 * @since 1.0
	 * @access public
	 * @param integer $user_id
	 * @param string $media_root
	 * @return boolean
	 */
	public function importHomeTemplates($user_id, $media_root)
	{

		$default_template = array(
			'sections_order' => array(
				'home',
				'nav',
				'profile',
				'hobbies',
				'resume',
				'milestones',
				'skills',
				'services',
				'workprocess',
				'portfolio',
				'pricing',
				'clients',
				'blog',
				'testimonials',
				'contact',
			),

			'home_s_mt' => 'Home',
			'home_s_sim' => 'yes',
			'home_s_s' => 'yes',
			'home_s_hs' => 'gradient',
			'home_s_bg' => $media_root . '/backgrounds/06.jpg',
			'home_s_img' => $media_root . '/photo-4.jpg',
			'home_s_n' => 'Patt Miller',
			'home_s_jt' => 'Designer / Developer',

			'nav_s_s' => 'yes',

			'profile_s_mt' => 'Profile',
			'profile_s_sim' => 'yes',
			'profile_s_s' => 'yes',
			'profile_s_ic' => 'fa-user',
			'profile_s_tit' => 'Profile',
			'profile_s_slog' => 'My Personal Info',
			'profile_s_desc' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s, when an unknown printer.',
			'profile_s_sto_tit' => 'My Story',
			'profile_s_sto_mai' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer.',
			'profile_s_sign' => $media_root . '/signature.png',
			'profile_s_phot' => $media_root . '/photo-4.jpg',
			'profile_s_cv' => 'https://www.dropbox.com/',
			'profile_s_inf_tit' => 'Personal Info',
			'profile_s_yo_nam' => 'Patt Miller Doe',
			'profile_s_yo_age' => '23 Years Old',
			'profile_s_yo_phon' => '+123-456-7890',
			'profile_s_yo_emai' => 'hello@site.com',
			'profile_s_yo_addrs' => '1732 Monroe Street Houston, TX 77055',

			'hobbies_s_mt' => 'Hobbies',
			'hobbies_s_sim' => 'no',
			'hobbies_s_s' => 'yes',
			'hobbies_s_tit' => 'My Hobbies',
			'hobbies_s_slog' => 'Work Hard, Party Harder',
			'hobbies_s_bg' => $media_root . '/backgrounds/03.jpg',

			'resume_s_mt' => 'Resume',
			'resume_s_sim' => 'yes',
			'resume_s_s' => 'yes',
			'resume_s_res_ic' => 'fa-book',
			'resume_s_tit' => 'Resume',
			'resume_s_slog' => 'Know Who I am',
			'resume_s_desc' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer.',
			'resume_s_ed_ic' => 'fa-graduation-cap',
			'resume_s_ed_tit' => 'Education',
			'resume_s_ex_ic' => 'fa-flask',
			'resume_s_ex_tit' => 'Experience',
			'resume_s_rec_ic' => 'fa-globe',
			'resume_s_rec_tit' => 'Recognition',

			'milesto_s_mt' => 'Milestones',
			'milesto_s_sim' => 'no',
			'milesto_s_s' => 'yes',
			'milesto_fi_ic' => 'fa-users',
			'milesto_fi_tit' => 'Happy Clients',
			'milesto_fi_cou' => '1200',
			'milesto_se_ic' => 'fa-briefcase',
			'milesto_se_tit' => 'Projects Finished',
			'milesto_se_cou' => '1500',
			'milesto_th_ic' => 'fa-clock-o',
			'milesto_th_tit' => 'Years Of Experience',
			'milesto_th_cou' => '10',
			'milesto_fo_ic' => 'fa-code',
			'milesto_fo_tit' => 'Lines Of Code',
			'milesto_fo_cou' => '30M',

			'skills_s_mt' => 'Skills',
			'skills_s_sim' => 'yes',
			'skills_s_ic' => 'fa-pie-chart',
			'skills_s_s' => 'yes',
			'skills_s_tit' => 'Skills',
			'skills_s_slog' => 'How Good I am',
			'skills_s_desc' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer.',

			'services_s_mt' => 'Services',
			'services_s_sim' => 'yes',
			'services_s_ic' => 'fa-cog',
			'services_s_s' => 'yes',
			'services_s_tit' => 'Services',
			'services_s_slog' => 'What My Clients Get',
			'services_s_desc' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer.',
			
			'process_s_mt' => 'Process',
			'process_s_sim' => 'no',
			'process_s_s' => 'yes',
			'process_s_bg' => $media_root . '/backgrounds/04.jpg',
			'process_s_tit' => 'Work Process',
			'process_s_slog' => 'How i work in my projects',

			'blog_s_mt' => 'Blog',
			'blog_s_sim' => 'yes',
			'blog_s_s' => 'yes',
			'blog_s_tit' => 'My Blog',
			'blog_s_slog' => 'All about my latest achievements',
			'blog_s_sh_on' => '3',
			'blog_s_lin_tex' => 'Visit My Blog',

			'portfolio_s_mt' => 'Portfolio',
			'portfolio_s_sim' => 'yes',
			'portfolio_s_s' => 'yes',
			'portfolio_s_ic' => 'fa-briefcase',
			'portfolio_s_tit' => 'Work',
			'portfolio_s_slog' => 'Recent Projects',
			'portfolio_s_desc' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer.',
			'portfolio_s_sh_on' => '10',
			'portfolio_s_lin_tex' => 'Show More Items',

			'pricing_s_mt' => 'Pricing',
			'pricing_s_sim' => 'yes',
			'pricing_s_s' => 'yes',
			'pricing_s_ic' => 'fa-dollar',
			'pricing_s_tit' => 'Pricing',
			'pricing_s_slog' => 'Choose Your Package',
			'pricing_s_desc' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer.',

			'clients_s_mt' => 'Clients',
			'clients_s_sim' => 'no',
			'clients_s_s' => 'yes',
			'clients_s_tit' => 'Famous Clients',
			'clients_s_slog' => 'Names you definitly know',

			'testimonial_s_mt' => 'Testimonials',
			'testimonial_s_sim' => 'yes',
			'testimonial_s_s' => 'yes',
			'testimonial_s_bg' => $media_root . '/backgrounds/01.jpg',
			'testimonial_s_sh_on' => '15',

			'contact_s_mt' => 'Contact',
			'contact_s_sim' => 'yes',
			'contact_s_s' => 'yes',
			'contact_s_ic' => 'fa-envelope',
			'contact_s_tit' => 'Contact',
			'contact_s_slog' => 'Get In Touch With Me',
			'contact_s_desc' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer.',
			'contact_s_scf' => 'yes',
			'contact_s_cem' => '',
			'contact_s_shf' => 'yes',
			'contact_s_hem' => '',
		);

		$gradient_template = $default_template;
		$gradient['home_s_hs'] = 'gradient';
		$gradient['home_s_bg'] = $media_root . '/backgrounds/06.jpg';
		$gradient['home_s_img'] = $media_root . '/photo-4.jpg';
		$gradient['home_s_n'] = 'Patt Miller';
		$gradient['home_s_jt'] = 'Designer / Developer';
		$gradient['profile_s_phot'] = $media_root . '/photo-4.jpg';
		$gradient['profile_s_yo_nam'] = 'Patt Miller Doe';

		$right_image_template = $default_template;
		$right_image_template['home_s_hs'] = 'right_image';
		$right_image_template['home_s_bg'] = $media_root . '/backgrounds/02.jpg';
		$right_image_template['home_s_img'] = $media_root . '/photo-2.png';
		$right_image_template['home_s_n'] = 'John Adam';
		$right_image_template['home_s_jt'] = 'Web Designer--Web Developer--Speaker';
		$right_image_template['profile_s_phot'] = $media_root . '/photo-2.png';
		$right_image_template['profile_s_yo_nam'] = 'John Adam Doe';

		$bottom_image_template = $default_template;
		$bottom_image_template['home_s_hs'] = 'bottom_image';
		$bottom_image_template['home_s_bg'] = $media_root . '/backgrounds/02.jpg';
		$bottom_image_template['home_s_img'] = $media_root . '/photo.png';
		$bottom_image_template['home_s_n'] = 'Angela Goble';
		$bottom_image_template['home_s_jt'] = 'Web Designer--Web Developer--Speaker';
		$bottom_image_template['profile_s_phot'] = $media_root . '/photo.png';
		$bottom_image_template['profile_s_yo_nam'] = 'Anglea Goble Doe';

		$parallax_image_template = $default_template;
		$parallax_image_template['home_s_hs'] = 'parallax';
		$parallax_image_template['home_s_bg'] = $media_root . '/backgrounds/06.jpg';
		$parallax_image_template['home_s_img'] = $media_root . '/photo-3.png';
		$parallax_image_template['home_s_n'] = 'Patt Miller';
		$parallax_image_template['home_s_jt'] = 'Creative Web Designer';
		$parallax_image_template['profile_s_phot'] = $media_root . '/photo-3.png';
		$parallax_image_template['profile_s_yo_nam'] = 'Patt Miller Doe';


		add_option( 'genio_wt_gradient_tem_template', $gradient_template );
		add_option( 'genio_wt_right_image_tem_template', $right_image_template );
		add_option( 'genio_wt_bottom_image_tem_template', $bottom_image_template );
		add_option( 'genio_wt_parallax_tem_template', $parallax_image_template );

		$customizer = get_option( 'genio_wt_customize', false );
		if($customizer !== false){
			$customizer['templates']['parallax_tem'] = 'Parallax Template';
			$customizer['templates']['gradient_tem'] = 'Gradient Template';
			$customizer['templates']['bottom_image_tem'] = 'Bottom Image Template';
			$customizer['templates']['right_image_tem'] = 'Right Image Template';
			update_option( 'genio_wt_customize', $customizer );
		}
	}

	/**
	 * Import Skills
	 *
	 * @since 1.0
	 * @access public
	 * @param integer $user_id
	 * @param string $media_root
	 * @return boolean
	 */
	public function importSkills($user_id, $media_root)
	{
		$personal_id = wp_insert_category(array(
  			'cat_name' => 'Personal' ,
  			'taxonomy' => 'gen_proj_sk_categ',
		));
		$knowledge_id = wp_insert_category(array(
  			'cat_name' => 'Knowledge' ,
  			'taxonomy' => 'gen_proj_sk_categ',
		));
		$languages_id = wp_insert_category(array(
  			'cat_name' => 'Languages' ,
  			'taxonomy' => 'gen_proj_sk_categ',
		));
		$design_id = wp_insert_category(array(
  			'cat_name' => 'Design' ,
  			'taxonomy' => 'gen_proj_sk_categ',
		));
		$coding_id = wp_insert_category(array(
  			'cat_name' => 'Coding' ,
  			'taxonomy' => 'gen_proj_sk_categ',
		));

		$skills = array(
			1 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Responsible',
				'post_name' => 'responsible',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $personal_id ),
			),

			2 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Diligence',
				'post_name' => 'diligence',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $personal_id ),
			),
			3 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Labour',
				'post_name' => 'labour',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $personal_id ),
			),
			4 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Rigor',
				'post_name' => 'rigor',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $personal_id ),
			),
			5 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Creative',
				'post_name' => 'creative',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $personal_id ),
			),
			6 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Funny',
				'post_name' => 'funny',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $personal_id ),
			),
			7 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Great Communicator',
				'post_name' => 'great-communicator',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $personal_id ),
			),
			8 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Flexible',
				'post_name' => 'flexible',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $personal_id ),
			),
			9 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Personal Integrity',
				'post_name' => 'personal-integrity',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $personal_id ),
			),
			10 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Positive Work Ethic',
				'post_name' => 'positive-work-ethic',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $personal_id ),
			),
			11 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Team Oriented',
				'post_name' => 'team-oriented',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $personal_id ),
			),
			12 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Reliability',
				'post_name' => 'reliability',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $personal_id ),
			),
			13 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Google Analythics & SEO',
				'post_name' => 'google-analythics-seo',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $knowledge_id ),
			),
			14 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Install And Configure',
				'post_name' => 'install-and-configure',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $knowledge_id ),
			),
			15 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'E-Commerce Platform',
				'post_name' => 'e-commerce-platform',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $knowledge_id ),
			),
			16 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Color Theory Knowledge',
				'post_name' => 'color-theory-knowledge',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $knowledge_id ),
			),
			17 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Web Usability',
				'post_name' => 'web-usability',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $knowledge_id ),
			),
			18 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Grid & Layout',
				'post_name' => 'grid-layout',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $knowledge_id ),
			),
			19 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Photo Manipulation Skills',
				'post_name' => 'photo-manipulation-skills',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $knowledge_id ),
			),
			20 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Digital Painting',
				'post_name' => 'digital-painting',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $knowledge_id ),
			),
			21 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Photo Composition',
				'post_name' => 'photo-composition',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $knowledge_id ),
			),
			22 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Good Sense Of Tipography',
				'post_name' => 'good-sense-of-tipography',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $knowledge_id ),
			),
			23 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Portrait Retouching',
				'post_name' => 'portrait-retouching',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $knowledge_id ),
			),
			24 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Video Editing',
				'post_name' => 'video-editing',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $knowledge_id ),
			),
			25 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'English',
				'post_name' => 'english',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $languages_id ),
			),
			26 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'French',
				'post_name' => 'french',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $languages_id ),
			),
			27 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'German',
				'post_name' => 'german',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $languages_id ),
			),
			28 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Spanish',
				'post_name' => 'spanish',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $languages_id ),
			),
			29 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Adobe Photoshop',
				'post_name' => 'adobe-photoshop',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $design_id ),
			),
			30 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Adobe Illustrator',
				'post_name' => 'adobe-illustrator',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $design_id ),
			),
			31 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Adobe Fireworks',
				'post_name' => 'adobe-fireworks',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $design_id ),
			),
			32 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => '3D MAX',
				'post_name' => '3d-max',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $design_id ),
			),
			33 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'HTML5',
				'post_name' => 'html5',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $coding_id ),
			),
			34 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'CSS3',
				'post_name' => 'css3',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $coding_id ),
			),
			35 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'JavaScript',
				'post_name' => 'javascript',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $coding_id ),
			),
			36 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'PHP',
				'post_name' => 'php',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $coding_id ),
			),
			37 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'WordPress',
				'post_name' => 'wordpress',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $coding_id ),
			),
			38 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Ruby',
				'post_name' => 'ruby',
				'post_content' => '',
				'post_type' => 'gen_skills',
				'tax_input' => array( 'gen_proj_sk_categ' => $coding_id ),
			),
		);

		$skills_meta = array(
			1 => array(
        			'title' => 'Responsible',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			2 => array(
        			'title' => 'Diligence',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			3 => array(
        			'title' => 'Labour',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			4 => array(
        			'title' => 'Rigor',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			5 => array(
        			'title' => 'Creative',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			
			6 => array(
        			'title' => 'Funny',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			7 => array(
        			'title' => 'Great Communicator',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			8 => array(
        			'title' => 'Flexible',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			9 => array(
        			'title' => 'Personal Integrity',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			10 => array(
        			'title' => 'Positive Work Ethic',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			11 => array(
        			'title' => 'Team Oriented',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			12 => array(
        			'title' => 'Reliability',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			13 => array(
        			'title' => 'Google Analythics & SEO',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			14 => array(
        			'title' => 'Install And Configure',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			15 => array(
        			'title' => 'E-Commerce Platform',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			16 => array(
        			'title' => 'Color Theory Knowledge',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			17 => array(
        			'title' => 'Web Usability',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			18 => array(
        			'title' => 'Grid & Layout',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			19 => array(
        			'title' => 'Photo Manipulation Skills',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			20 => array(
        			'title' => 'Digital Painting',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			21 => array(
        			'title' => 'Photo Composition',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			22 => array(
        			'title' => 'Good Sense Of Tipography ',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			23 => array(
        			'title' => 'Portrait Retouching',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			24 => array(
        			'title' => 'Video Editing',
        			'display_as' => 'list_item',
        			'level' => '20',
			),
			25 => array(
        			'title' => 'English',
        			'display_as' => 'bar',
        			'level' => '60',
			),
			26 => array(
        			'title' => 'French',
        			'display_as' => 'bar',
        			'level' => '60',
			),
			27 => array(
        			'title' => 'German',
        			'display_as' => 'bar',
        			'level' => '40',
			),
			28 => array(
        			'title' => 'Spanish',
        			'display_as' => 'bar',
        			'level' => '40',
			),
			29 => array(
        			'title' => 'Adobe Photoshop',
        			'display_as' => 'bar',
        			'level' => '60',
			),
			30 => array(
        			'title' => 'Adobe Illustrator',
        			'display_as' => 'bar',
        			'level' => '80',
			),
			31 => array(
        			'title' => 'Adobe Fireworks',
        			'display_as' => 'bar',
        			'level' => '100',
			),
			32 => array(
        			'title' => '3D MAX',
        			'display_as' => 'bar',
        			'level' => '40',
			),
			33 => array(
        			'title' => 'HTML5',
        			'display_as' => 'bar',
        			'level' => '100',
			),
			34 => array(
        			'title' => 'CSS3',
        			'display_as' => 'bar',
        			'level' => '100',
			),
			35 => array(
        			'title' => 'JavaScript',
        			'display_as' => 'bar',
        			'level' => '60',
			),
			36 => array(
        			'title' => 'PHP',
        			'display_as' => 'bar',
        			'level' => '80',
			),
			37 => array(
        			'title' => 'WordPress',
        			'display_as' => 'bar',
        			'level' => '80',
			),
			38 => array(
        			'title' => 'Ruby',
        			'display_as' => 'bar',
        			'level' => '40',
			),
		);

		foreach ($skills as $key => $value) {
			$post_id = wp_insert_post( $value );
			update_post_meta( $post_id, 'genio_skills_info', $skills_meta[$key]);
		}
		return true;
	}

	/**
	 * Import Pricing
	 *
	 * @since 1.0
	 * @access public
	 * @param integer $user_id
	 * @param string $media_root
	 * @return boolean
	 */
	public function importPricing($user_id, $media_root)
	{
		$plans = array(
			1 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Designer',
				'post_name' => 'designer',
				'post_content' => '',
				'post_type' => 'gen_pricing',
			),
			2 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Developer',
				'post_name' => 'developer',
				'post_content' => '',
				'post_type' => 'gen_pricing',
			),
			3 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Speaker',
				'post_name' => 'speaker',
				'post_content' => '',
				'post_type' => 'gen_pricing',
			),
		);


		$plans_meta = array(
			1 => array(
        			'title' => 'Designer',
        			'plan_order' => 'left',
        			'price' => '59.99',
        			'price_per' => 'Hour',
        			'currency' => '$',
        			'plan_features' => array(
        				'Logo Designing',
					'Website Retouches',
					'Image Editing',
					'Wireframing',
					'Other Options',
        			),
        			'button_text' => 'Order Now',
        			'button_link' => home_url('/#'),
			),
			2 => array(
        			'title' => 'Developer',
        			'plan_order' => 'center',
        			'price' => '79.99',
        			'price_per' => 'Hour',
        			'currency' => '$',
        			'plan_features' => array(
					'CSS Coding',
					'JavaScript Coding',
					'PHP Coding',
					'WordPress',
					'Other Options',
        			),
        			'button_text' => 'Order Now',
        			'button_link' => home_url('/#'),
			),
			3 => array(
        			'title' => 'Speaker',
        			'plan_order' => 'right',
        			'price' => '99.99',
        			'price_per' => 'Hour',
        			'currency' => '$',
        			'plan_features' => array(
					'Web Design Talk',
					'Web Development Talk',
					'Web Projects Management',
					'Plugin Authoring',
					'Other',
        			),
        			'button_text' => 'Order Now',
        			'button_link' => home_url('/#'),
			),
		);

		foreach ($plans as $key => $value) {
			$post_id = wp_insert_post( $value );
			update_post_meta( $post_id, 'genio_pricing_info', $plans_meta[$key]);
		}
		return true;
	}

	/**
	 * Import Resume
	 *
	 * @since 1.0
	 * @access public
	 * @param integer $user_id
	 * @param string $media_root
	 * @return boolean
	 */
	public function importResume($user_id, $media_root)
	{
		$resume_items = array(
			1 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Master Degree Of Design',
				'post_name' => 'master-degree-of-design',
				'post_content' => '',
				'post_type' => 'gen_resume',
			),
			2 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Bachelor Degree Of Design',
				'post_name' => 'bachelor-degree-of-design',
				'post_content' => '',
				'post_type' => 'gen_resume',
			),
			3 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'High School Degree',
				'post_name' => 'high-school-degree',
				'post_content' => '',
				'post_type' => 'gen_resume',
			),
			4 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Lead Web Developer',
				'post_name' => 'lead-web-developer',
				'post_content' => '',
				'post_type' => 'gen_resume',
			),
			5 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Lead Web Designer',
				'post_name' => 'lead-web-designer',
				'post_content' => '',
				'post_type' => 'gen_resume',
			),
			6 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Web Designer',
				'post_name' => 'web-designer',
				'post_content' => '',
				'post_type' => 'gen_resume',
			),

			7 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'CSS Conference',
				'post_name' => 'css-conference',
				'post_content' => '',
				'post_type' => 'gen_resume',
			),
			8 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Design Of The Day',
				'post_name' => 'design-of-the-day',
				'post_content' => '',
				'post_type' => 'gen_resume',
			),
		);

		$resume_items_meta = array(
			1 => array(
        			'category' => 'education',
        			'ed_from' => '2008',
        			'ed_to' => '2009',
        			'ed_univ' => 'Name Of University',
        			'ed_coun' => 'USA',
        			'ed_degree' => 'Master Degree Of Design',
        			'ed_grade' => 'A+',
        			'ed_summ' => 'Coordinates for abs positioning use the closest positioned parent box of the positioned element. So assuming that your div creating the corner(s) has no parent elements that are rel or abs positioned it will default up the chain to the html element which is at 0,0 of the viewport. The only problem here is this may be hard to accomplish depending on your layout.',
        			'ex_from' => '',
        			'ex_to' => '',
        			'ex_comp' => '',
        			'ex_coun' => '',
        			'ex_job' => '',
        			'ex_logo' => '',
        			'ex_summ' => '',
        			're_date' => '',
        			're_conf' => '',
        			're_coun' => '',
        			're_part' => '',
        			're_icon' => 'fa-glass',
        			're_summ' => '',
			),
			2 => array(
        			'category' => 'education',
        			'ed_from' => '2004',
        			'ed_to' => '2007',
        			'ed_univ' => 'Name Of University',
        			'ed_coun' => 'USA',
        			'ed_degree' => 'Bachelor Degree Of Design',
        			'ed_grade' => 'A+',
        			'ed_summ' => 'Coordinates for abs positioning use the closest positioned parent box of the positioned element. So assuming that your div creating the corner(s) has no parent elements that are rel or abs positioned.',
        			'ex_from' => '',
        			'ex_to' => '',
        			'ex_comp' => '',
        			'ex_coun' => '',
        			'ex_job' => '',
        			'ex_logo' => '',
        			'ex_summ' => '',
        			're_date' => '',
        			're_conf' => '',
        			're_coun' => '',
        			're_part' => '',
        			're_icon' => 'fa-glass',
        			're_summ' => '',
			),
			3 => array(
        			'category' => 'education',
        			'ed_from' => '2000',
        			'ed_to' => '2003',
        			'ed_univ' => 'Name Of University',
        			'ed_coun' => 'USA',
        			'ed_degree' => 'High School Degree',
        			'ed_grade' => 'A+',
        			'ed_summ' => 'Coordinates for abs positioning use the closest positioned parent box of the positioned element. So assuming that your div creating the corner(s) has no parent elements that are rel or abs positioned.',
        			'ex_from' => '',
        			'ex_to' => '',
        			'ex_comp' => '',
        			'ex_coun' => '',
        			'ex_job' => '',
        			'ex_logo' => '',
        			'ex_summ' => '',
        			're_date' => '',
        			're_conf' => '',
        			're_coun' => '',
        			're_part' => '',
        			're_icon' => 'fa-glass',
        			're_summ' => '',
			),
			4 => array(
        			'category' => 'experience',
        			'ed_from' => '',
        			'ed_to' => '',
        			'ed_univ' => '',
        			'ed_coun' => '',
        			'ed_degree' => '',
        			'ed_grade' => '',
        			'ed_summ' => '',
        			'ex_from' => '2013',
        			'ex_to' => '2025',
        			'ex_comp' => 'Name Of Company',
        			'ex_coun' => 'USA',
        			'ex_job' => 'Lead Web Developer',
        			'ex_logo' => $media_root . '/clients/01.png',
        			'ex_summ' => 'Coordinates for abs positioning use the closest positioned parent box of the positioned element. So assuming that your div creating the corner(s) has no parent elements that are rel or abs positioned it will default up the chain to the html element which is at 0,0 of the viewport.',
        			're_date' => '',
        			're_conf' => '',
        			're_coun' => '',
        			're_part' => '',
        			're_icon' => 'fa-glass',
        			're_summ' => '',
			),
			5 => array(
        			'category' => 'experience',
        			'ed_from' => '',
        			'ed_to' => '',
        			'ed_univ' => '',
        			'ed_coun' => '',
        			'ed_degree' => '',
        			'ed_grade' => '',
        			'ed_summ' => '',
        			'ex_from' => '2010',
        			'ex_to' => '2012',
        			'ex_comp' => 'Name Of Company',
        			'ex_coun' => 'USA',
        			'ex_job' => 'Lead Web Designer',
        			'ex_logo' => $media_root . '/clients/02.png',
        			'ex_summ' => 'Coordinates for abs positioning use the closest positioned parent box of the positioned element. So assuming that your div creating the corner(s) has no parent elements.',
        			're_date' => '',
        			're_conf' => '',
        			're_coun' => '',
        			're_part' => '',
        			're_icon' => 'fa-glass',
        			're_summ' => '',
			),
			6 => array(
        			'category' => 'experience',
        			'ed_from' => '',
        			'ed_to' => '',
        			'ed_univ' => '',
        			'ed_coun' => '',
        			'ed_degree' => '',
        			'ed_grade' => '',
        			'ed_summ' => '',
        			'ex_from' => '2008',
        			'ex_to' => '2009',
        			'ex_comp' => 'Name Of Company',
        			'ex_coun' => 'USA',
        			'ex_job' => 'Web Designer',
        			'ex_logo' => $media_root . '/clients/03.png',
        			'ex_summ' => 'Coordinates for abs positioning use the closest positioned parent box of the positioned element. So assuming that your div creating the corner(s) has no parent elements.',
        			're_date' => '',
        			're_conf' => '',
        			're_coun' => '',
        			're_part' => '',
        			're_icon' => 'fa-glass',
        			're_summ' => '',
			),

			7 => array(
        			'category' => 'recognition',
        			'ed_from' => '',
        			'ed_to' => '',
        			'ed_univ' => '',
        			'ed_coun' => '',
        			'ed_degree' => '',
        			'ed_grade' => '',
        			'ed_summ' => '',
        			'ex_from' => '',
        			'ex_to' => '',
        			'ex_comp' => '',
        			'ex_coun' => '',
        			'ex_job' => '',
        			'ex_logo' => '',
        			'ex_summ' => '',
        			're_date' => '2014-02-01',
        			're_conf' => 'CSS3 Conference',
        			're_coun' => 'USA',
        			're_part' => 'Speaker',
        			're_icon' => 'fa-microphone',
        			're_summ' => 'Coordinates for abs positioning use the closest positioned parent box of the positioned element. So assuming that your div creating the corner(s) has no parent elements that are rel or abs positioned it will default up the chain to the html element which is at 0,0 of the viewport. The only problem here is this may be hard to accomplish depending on your layout.',
			),
			8 => array(
        			'category' => 'recognition',
        			'ed_from' => '',
        			'ed_to' => '',
        			'ed_univ' => '',
        			'ed_coun' => '',
        			'ed_degree' => '',
        			'ed_grade' => '',
        			'ed_summ' => '',
        			'ex_from' => '',
        			'ex_to' => '',
        			'ex_comp' => '',
        			'ex_coun' => '',
        			'ex_job' => '',
        			'ex_logo' => '',
        			'ex_summ' => '',
        			're_date' => '2014-12-16',
        			're_conf' => 'Design Of The Day',
        			're_coun' => 'USA',
        			're_part' => 'Website',
        			're_icon' => 'fa-trophy',
        			're_summ' => 'Coordinates for abs positioning use the closest positioned parent box of the positioned element.',
			),
		);

		foreach ($resume_items as $key => $value) {
			$post_id = wp_insert_post( $value );
			update_post_meta( $post_id, 'genio_resume_info', $resume_items_meta[$key]);
		}
		return true;
	}	

	/**
	 * Import Process
	 *
	 * @since 1.0
	 * @access public
	 * @param integer $user_id
	 * @param string $media_root
	 * @return boolean
	 */
	public function importProcess($user_id, $media_root)
	{
		$processes = array(
			1 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Concept',
				'post_name' => 'concept',
				'post_content' => '',
				'post_type' => 'gen_work_process',
			),
			2 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Sketch',
				'post_name' => 'sketch',
				'post_content' => '',
				'post_type' => 'gen_work_process',
			),
			3 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Design',
				'post_name' => 'design',
				'post_content' => '',
				'post_type' => 'gen_work_process',
			),
			4 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Code',
				'post_name' => 'code',
				'post_content' => '',
				'post_type' => 'gen_work_process',
			),
			5 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Test',
				'post_name' => 'test',
				'post_content' => '',
				'post_type' => 'gen_work_process',
			),
			6 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Launch',
				'post_name' => 'launch',
				'post_content' => '',
				'post_type' => 'gen_work_process',
			),
		);

		$processes_meta = array(
			1 => array(
        			'title' => 'Concept',
        			'icon' => 'fa-lightbulb-o',
        			'order' => '1',
			),
			2 => array(
        			'title' => 'Sketch',
        			'icon' => 'fa-pencil-square',
        			'order' => '2',
			),
			3 => array(
        			'title' => 'Design',
        			'icon' => 'fa-magic',
        			'order' => '3',
			),
			4 => array(
        			'title' => 'Code',
        			'icon' => 'fa-code',
        			'order' => '4',
			),
			5 => array(
        			'title' => 'Test',
        			'icon' => 'fa-flask',
        			'order' => '5',
			),
			6 => array(
        			'title' => 'Launch',
        			'icon' => 'fa-rocket',
        			'order' => '6',
			),
		);

		foreach ($processes as $key => $value) {
			$post_id = wp_insert_post( $value );
			update_post_meta( $post_id, 'genio_work_process_info', $processes_meta[$key]);
		}
		return true;
	}

	/**
	 * Import Hobbies
	 *
	 * @since 1.0
	 * @access public
	 * @param integer $user_id
	 * @param string $media_root
	 * @return boolean
	 */
	public function importHobbies($user_id, $media_root)
	{
		$hobbies = array(
			1 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Puzzles',
				'post_name' => 'puzzles',
				'post_content' => '',
				'post_type' => 'gen_hobbies',
			),
			2 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Cinema',
				'post_name' => 'cinema',
				'post_content' => '',
				'post_type' => 'gen_hobbies',
			),
			3 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Music',
				'post_name' => 'music',
				'post_content' => '',
				'post_type' => 'gen_hobbies',
			),
			4 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Travel',
				'post_name' => 'travel',
				'post_content' => '',
				'post_type' => 'gen_hobbies',
			),
			5 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Shopping',
				'post_name' => 'shopping',
				'post_content' => '',
				'post_type' => 'gen_hobbies',
			),
		);

		$hobbies_meta = array(
			1 => array(
				'title' => 'Puzzles',
				'icon' => 'fa-puzzle-piece',
				'summary' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500.',	
			),
			2 => array(
				'title' => 'Cinema',
				'icon' => 'fa-video-camera',
				'summary' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500.',	
			),
			3 => array(
				'title' => 'Music',
				'icon' => 'fa-headphones',
				'summary' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500.',	
			),
			4 => array(
				'title' => 'Travel',
				'icon' => 'fa-plane',
				'summary' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500.',	
			),
			5 => array(
				'title' => 'Shopping',
				'icon' => 'fa-shopping-cart',
				'summary' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500.',	
			),
		);

		foreach ($hobbies as $key => $value) {
			$post_id = wp_insert_post( $value );
			update_post_meta( $post_id, 'genio_hobbies_info', $hobbies_meta[$key]);
		}
		return true;
	}

	/**
	 * Import Services
	 *
	 * @since 1.0
	 * @access public
	 * @param integer $user_id
	 * @param string $media_root
	 * @return boolean
	 */
	public function importServices($user_id, $media_root)
	{
		$services = array(
			1 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Support My Products',
				'post_name' => 'support-my-products',
				'post_content' => '',
				'post_type' => 'gen_services',
			),
			2 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Website Installation',
				'post_name' => 'website-installation',
				'post_content' => '',
				'post_type' => 'gen_services',
			),
			3 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Marketing',
				'post_name' => 'marketing',
				'post_content' => '',
				'post_type' => 'gen_services',
			),
			4 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Branding',
				'post_name' => 'branding',
				'post_content' => '',
				'post_type' => 'gen_services',
			),
			5 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Web Development',
				'post_name' => 'web-development',
				'post_content' => '',
				'post_type' => 'gen_services',
			),
			6 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Web Design',
				'post_name' => 'web-design',
				'post_content' => '',
				'post_type' => 'gen_services',
			),
		);

		$services_meta = array(
			1 => array(
        			'title' => 'Support My Products',
        			'icon' => 'fa-question',
        			'summary' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
			),
			2 => array(
        			'title' => 'Website Installation',
        			'icon' => 'fa-wrench',
        			'summary' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
			),
			3 => array(
        			'title' => 'Marketing',
        			'icon' => 'fa-globe',
        			'summary' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
			),
			4 => array(
        			'title' => 'Branding',
        			'icon' => 'fa-star',
        			'summary' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
			),
			5 => array(
        			'title' => 'Web Development',
        			'icon' => 'fa-code',
        			'summary' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
			),
			6 => array(
        			'title' => 'Web Design',
        			'icon' => 'fa-magic',
        			'summary' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
			),
		);

		foreach ($services as $key => $value) {
			$post_id = wp_insert_post( $value );
			update_post_meta( $post_id, 'genio_service_info', $services_meta[$key]);
		}
		return true;
	}

	/**
	 * Import Clients
	 *
	 * @since 1.0
	 * @access public
	 * @param integer $user_id
	 * @param string $media_root
	 * @return boolean
	 */
	public function importClients($user_id, $media_root)
	{
		$clients = array(
			1 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Client1',
				'post_name' => 'client1',
				'post_content' => '',
				'post_type' => 'gen_clients',
			),
			2 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Client2',
				'post_name' => 'client2',
				'post_content' => '',
				'post_type' => 'gen_clients',
			),
			3 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Client3',
				'post_name' => 'client3',
				'post_content' => '',
				'post_type' => 'gen_clients',
			),
			4 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Client4',
				'post_name' => 'client4',
				'post_content' => '',
				'post_type' => 'gen_clients',
			),
			5 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Client5',
				'post_name' => 'client5',
				'post_content' => '',
				'post_type' => 'gen_clients',
			),
			6 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Client6',
				'post_name' => 'client6',
				'post_content' => '',
				'post_type' => 'gen_clients',
			),
		);

		$clients_meta = array(
			1 => array(
        			'logo' => $media_root . '/clients/01.png',
        			'url' => 'http://envato.com',
			),
			2 => array(
        			'logo' => $media_root . '/clients/02.png',
        			'url' => 'http://envato.com',
			),
			3 => array(
        			'logo' => $media_root . '/clients/03.png',
        			'url' => 'http://envato.com',
			),
			4 => array(
        			'logo' => $media_root . '/clients/04.png',
        			'url' => 'http://envato.com',
			),
			5 => array(
        			'logo' => $media_root . '/clients/05.png',
        			'url' => 'http://envato.com',
			),
			6 => array(
        			'logo' => $media_root . '/clients/06.png',
        			'url' => 'http://envato.com',
			),
		);

		foreach ($clients as $key => $value) {
			$post_id = wp_insert_post( $value );
			update_post_meta( $post_id, 'genio_client_info', $clients_meta[$key]);
		}
		return true;
	}

	/**
	 * Import Testimonials
	 *
	 * @since 1.0
	 * @access public
	 * @param integer $user_id
	 * @param string $media_root
	 * @return boolean
	 */
	public function importTestimonials($user_id, $media_root)
	{
		$testimonials = array(
			1 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'John Doe',
				'post_name' => 'john-doe',
				'post_content' => '',
				'post_type' => 'gen_testimonials',
			),
			2 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Jessica Doe',
				'post_name' => 'jessica-doe',
				'post_content' => '',
				'post_type' => 'gen_testimonials',
			),
			3 => array(
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_title' => 'Angela Doe',
				'post_name' => 'angela-doe',
				'post_content' => '',
				'post_type' => 'gen_testimonials',
			),
		);

		$testimonials_meta = array(
			1 => array(
				'name' => 'John Doe',
				'photo' => $media_root . '/testimonials/01.jpg',
				'job' => 'Web Developer',
				'company' => 'Envato',
				'main' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer.',
			),
			2 => array(
				'name' => 'Jessica Doe',
				'photo' => $media_root . '/testimonials/02.jpg',
				'job' => 'Web Designer',
				'company' => 'Envato',
				'main' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text.',
			),
			3 => array(
				'name' => 'Angela Doe',
				'photo' => $media_root . '/testimonials/03.jpg',
				'job' => 'Design Consultant',
				'company' => 'Envato',
				'main' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
			),
		);

		foreach ($testimonials as $key => $value) {
			$post_id = wp_insert_post( $value );
			update_post_meta( $post_id, 'genio_testimonial_info', $testimonials_meta[$key]);
		}
		return true;
	}
}