<?php
/**
 * Genio - WordPress Theme Core Plugin
 *
 * @version 1.0
 * @package genio-wt
 * @author  Clivern <support@clivern.com>
 * @link    http://clivern.com/
 * @copyright     Copyright (c) 2015, Clivern (http://clivern.com/)
 * @license http://themeforest.net/licenses GPL
 */

class GENIO_WT_SHORTCODES
{
	/**
	 * Stored gallery and video elements
	 *
	 * @since 1.0
	 * @var array $this->stored_element
	 */
	private $stored_element = array(
		'gallery' => array(),
		'video' => array(),
	);

      /**
       * Register tinymce button
       *
       * @since 1.0
       * @access public
       */
	public function run()
	{
		add_action( 'init', array(
			&$this,
			'init'
		));

		// get gallery and video shortcode
		// out of the post to be used as featured
		add_action( 'genio_featured_content', array(
			&$this,
			'processFeatured'
		), 20);
		add_action( 'genio_featured_content', array(
			&$this,
			'featuredContent'
		), 21);
		add_shortcode('genio_fgallery', '__return_false');
		add_shortcode('genio_fvideo', '__return_false');

		remove_shortcode( 'gallery', 'gallery_shortcode' );
		add_shortcode( 'gallery', array(
			&$this,
			'genioDefaultGallery' 
		));
	}

	/**
	 * Process featured video and featured gallery later
	 *
	 * This method is alittle tricky it is fired 
	 * before original wp shortcode 
	 * it remove all shortcodes then add two shortcodes to get featured 
	 * element then return shortcodes back again
	 * 
	 * @param array $args
	 */
	public function processFeatured($args)
	{
     		global $shortcode_tags;

		$page = $args[0];
		$post_id =  $args[1];
		$content = $args[2];

          	$original_shortcode_tags = $shortcode_tags;
          	remove_all_shortcodes();
		
		add_shortcode('genio_fgallery', array(
			&$this,
			'genioGallery'
		));
		add_shortcode('genio_fvideo', array(
			&$this,
			'genioVideo'
		));
        	
        	do_shortcode( $content );
 
         	$shortcode_tags = $original_shortcode_tags;
	}

	/**
	 * Render featured content whether stored or fallback
	 *
	 * @since 1.0
	 * @param array $args
	 * @return string
	 */
	public function featuredContent( $args)
	{
		$page = $args[0];
		$post_id =  $args[1];
		$content = $args[2];
		if( ('project' == $page) ){
			$render_done = false;
			if( ($render_done == false) && (isset($this->stored_element['gallery'][$post_id])) ){
				//render gallery
				$ids = $this->stored_element['gallery'][$post_id]['ids'];
				$ids = explode(',', $ids);
				$urls = array();
				foreach ($ids as $id) {
					$url = wp_get_attachment_url($id, 'full');
					if( filter_var($url, FILTER_VALIDATE_URL) ){
						$urls[] = $url;
					}
				}
				if( count($urls) >= 1 ){
					echo '<div class="slider"><ul class="rslides">';
					foreach ($urls as $url) {
						echo '<li><img src="' . esc_url($url) . '"></li>';
					}
					echo '</ul></div>';
					$render_done = true;	
				}				
			}
			if( ($render_done == false) && (isset($this->stored_element['video'][$post_id])) ){
				//render video
				$id = $this->stored_element['video'][$post_id]['id'];
				$url = $this->stored_element['video'][$post_id]['url'];
				$width = $this->stored_element['video'][$post_id]['width'];
				$height = $this->stored_element['video'][$post_id]['height'];
				if( filter_var($url, FILTER_VALIDATE_URL) ){
					echo '<div class="fitvid"><iframe width="' . esc_attr($width) . '" height="' . esc_attr($height) . '" src="' . esc_url($url) . '" frameborder="0" allowfullscreen></iframe></div>';
					$render_done = true;
				}
				if( ($render_done == false) && !(empty($id)) ){
					$url = wp_get_attachment_url($id, 'full');
					if( filter_var($url, FILTER_VALIDATE_URL) ){
						echo '<div class="fitvid"><iframe width="' . esc_attr($width) . '" height="' . esc_attr($height) . '" src="' . esc_url($url) . '" frameborder="0" allowfullscreen></iframe></div>';
						$render_done = true;
					}
				}
			}

			if( $render_done == false ){
				//render featured image
				if( has_post_thumbnail($post_id) ){
					$thumb_id = get_post_thumbnail_id( $post_id );
					$thumb_url_array = wp_get_attachment_image_src($thumb_id, 'full', true);
					$thumb_url = $thumb_url_array[0];
				}else{
					$thumb_url = false;
				}
				if( $thumb_url !== false ){
					echo '<div><img src="' . esc_url($thumb_url) . '" class="img-responsive wow fadeInUp"></div>';
				}
				$render_done = true;
			}
		}

		if( ('post' == $page) ){
			$render_done = false;
			if( ($render_done == false) && (isset($this->stored_element['gallery'][$post_id])) ){
				//render gallery
				$ids = $this->stored_element['gallery'][$post_id]['ids'];
				$ids = explode(',', $ids);
				$urls = array();
				foreach ($ids as $id) {
					$url = wp_get_attachment_url($id, 'full');
					if( filter_var($url, FILTER_VALIDATE_URL) ){
						$urls[] = $url;
					}
				}
				if( count($urls) >= 1 ){
					echo '<div class="slider"><ul class="rslides">';
					foreach ($urls as $url) {
						echo '<li><img src="' . esc_url($url) . '"></li>';
					}
					echo '</ul></div>';
					$render_done = true;	
				}
			}
			if( ($render_done == false) && (isset($this->stored_element['video'][$post_id])) ){
				//render video
				$id = $this->stored_element['video'][$post_id]['id'];
				$url = $this->stored_element['video'][$post_id]['url'];
				$width = $this->stored_element['video'][$post_id]['width'];
				$height = $this->stored_element['video'][$post_id]['height'];
				if( filter_var($url, FILTER_VALIDATE_URL) ){
					echo '<div class="fitvid"><iframe width="' . esc_attr($width) . '" height="' . esc_attr($height) . '" src="' . esc_url($url) . '" frameborder="0" allowfullscreen></iframe></div>';
					$render_done = true;
				}
				if( ($render_done == false) && !(empty($id)) ){
					$url = wp_get_attachment_url($id, 'full');
					if( filter_var($url, FILTER_VALIDATE_URL) ){
						echo '<div class="fitvid"><iframe width="' . esc_attr($width) . '" height="' . esc_attr($height) . '" src="' . esc_url($url) . '" frameborder="0" allowfullscreen></iframe></div>';
						$render_done = true;
					}
				}
			}

			if( $render_done == false ){
				//render featured image
				if( has_post_thumbnail($post_id) ){
					$thumb_id = get_post_thumbnail_id( $post_id );
					$thumb_url_array = wp_get_attachment_image_src($thumb_id, 'full', true);
					$thumb_url = $thumb_url_array[0];
				}else{
					$thumb_url = false;
				}
				if( $thumb_url !== false ){
					echo '<div><img src="' . esc_url($thumb_url) . '" class="img-responsive wow fadeInUp"></div>';
				}
				$render_done = true;
			}
		}

		if( ('page' == $page) ){
			$render_done = false;
			if( ($render_done == false) && (isset($this->stored_element['gallery'][$post_id])) ){
				//render gallery
				$ids = $this->stored_element['gallery'][$post_id]['ids'];
				$ids = explode(',', $ids);
				$urls = array();
				foreach ($ids as $id) {
					$url = wp_get_attachment_url($id, 'full');
					if( filter_var($url, FILTER_VALIDATE_URL) ){
						$urls[] = $url;
					}
				}
				if( count($urls) >= 1 ){
					echo '<div class="slider"><ul class="rslides">';
					foreach ($urls as $url) {
						echo '<li><img src="' . esc_url($url) . '"></li>';
					}
					echo '</ul></div>';
					$render_done = true;	
				}
			}
			if( ($render_done == false) && (isset($this->stored_element['video'][$post_id])) ){
				//render video
				$id = $this->stored_element['video'][$post_id]['id'];
				$url = $this->stored_element['video'][$post_id]['url'];
				$width = $this->stored_element['video'][$post_id]['width'];
				$height = $this->stored_element['video'][$post_id]['height'];
				if( filter_var($url, FILTER_VALIDATE_URL) ){
					echo '<div class="fitvid"><iframe width="' . esc_attr($width) . '" height="' . esc_attr($height) . '" src="' . esc_url($url) . '" frameborder="0" allowfullscreen></iframe></div>';
					$render_done = true;
				}
				if( ($render_done == false) && !(empty($id)) ){
					$url = wp_get_attachment_url($id, 'full');
					if( filter_var($url, FILTER_VALIDATE_URL) ){
						echo '<div class="fitvid"><iframe width="' . esc_attr($width) . '" height="' . esc_attr($height) . '" src="' . esc_url($url) . '" frameborder="0" allowfullscreen></iframe></div>';
						$render_done = true;
					}
				}
			}

			if( $render_done == false ){
				//render featured image
				if( has_post_thumbnail($post_id) ){
					$thumb_id = get_post_thumbnail_id( $post_id );
					$thumb_url_array = wp_get_attachment_image_src($thumb_id, 'full', true);
					$thumb_url = $thumb_url_array[0];
				}else{
					$thumb_url = false;
				}
				if( $thumb_url !== false ){
					echo '<div><img src="' . esc_url($thumb_url) . '" class="img-responsive wow fadeInUp"></div>';
				}
				$render_done = true;
			}
		}
	}

	/**
	 * Get featured gallery and store to be used later
	 *
	 * @since 1.0
	 * @param array $atts 
	 * @param null $content
	 * @return boolean
	 */
	public function genioGallery($atts, $content = null)
	{
		global $post;
		extract( shortcode_atts( array(
			'ids'			=> '',
		  ), $atts ) );
		$this->stored_element['gallery'][$post->ID] = ( !(isset($this->stored_element['gallery'][$post->ID])) ) ? array('ids' => $ids) : $this->stored_element['gallery'][$post->ID];
		return false;
	}

	/**
	 * Get featured video and store to be used later
	 *
	 * @since 1.0
	 * @param array $atts 
	 * @param null $content
	 * @return boolean
	 */
	public function genioVideo($atts, $content = null)
	{
		global $post;
		extract( shortcode_atts( array(
			'id'			=> '',
			'url'             => '',
			'width'           => '560',
			'height'          => '315',
		  ), $atts ) );

		$this->stored_element['video'][$post->ID] = ( !(isset($this->stored_element['video'][$post->ID])) ) ? array( 'id' => $id, 'url' => $url, 'width' => $width , 'height' => $height) : $this->stored_element['video'][$post->ID];
		return false;
	}

	/**
	 * Process wordpress default gallery shortcode after removing wp one
	 *
	 * @since 1.0
	 * @param array $atts 
	 * @return string
	 */
	public function genioDefaultGallery( $attr ) {
		$post = get_post();

		static $instance = 0;
		$instance++;

		if ( ! empty( $attr['ids'] ) ) {
			if ( empty( $attr['orderby'] ) ){
				$attr['orderby'] = 'post__in';
			}
			$attr['include'] = $attr['ids'];
		}

		$output = apply_filters( 'post_gallery', '', $attr );
		if ( $output != '' ){
			return $output;
		}

		if ( isset( $attr['orderby'] ) ) {
			$attr['orderby'] = sanitize_sql_orderby( $attr['orderby'] );
			if ( ! $attr['orderby'] ){
				unset( $attr['orderby'] );
			}
		}

		extract( shortcode_atts( array(
			'order'      => 'ASC',
			'orderby'    => 'menu_order ID',
			'id'         => $post->ID,
			'itemtag'    => 'li',
			'icontag'    => 'dt',
			'captiontag' => 'dd',
			'columns'    => 3,
			'size'       => 'thumbnail',
			'include'    => '',
			'exclude'    => '',
			), $attr));

		$id = intval( $id );
		if ( 'RAND' == $order ){
			$orderby = 'none';
		}

		if ( ! empty( $include ) ) {
			
			$_attachments = get_posts( array( 'include' => $include, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby ) );

			$attachments = array();
			foreach ( $_attachments as $key => $val ) {
				$attachments[ $val->ID ] = $_attachments[ $key ];
			}
		} elseif ( ! empty( $exclude ) ) {
			$attachments = get_children( array( 'post_parent' => $id, 'exclude' => $exclude, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby ) );
		} else {
			$attachments = get_children( array( 'post_parent' => $id, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby ) );
		}
		if ( empty( $attachments ) ){
			return '';
		}

		if ( is_feed() ) {
			$output = "\n";
			foreach ( $attachments as $att_id => $attachment ){
				$output .= wp_get_attachment_link( $att_id, $size, true ) . "\n";
			}
			return $output;
		}

		$itemtag = tag_escape( $itemtag );
		$captiontag = tag_escape( $captiontag );
		//$columns = intval( $columns );
		//$itemwidth = $columns > 0 ? floor( 100 / $columns ) : 100;
		//$float = is_rtl() ? 'right' : 'left';

		$selector = "gallery-{$instance}";

		$gallery_style = $gallery_div = '';
		$size_class = sanitize_html_class( $size );

		$gid = rand( 1, 15 );
		$carousel_div = "<div id='gallery-{$id}{$gid}' class='slider'><ul class='rslides'>";
		$output .= apply_filters( 'gallery_style', $gallery_style . "\n\t\t" . $carousel_div );

		$i = 0;
		$thumbnails = array();

		foreach ( $attachments as $img_id => $attachment ) {
			$link = isset( $attr['link']) && 'file' == $attr['link'] ? wp_get_attachment_link( $img_id, $size, false, false ) : wp_get_attachment_link( $img_id, $size, true, false );
			$full_url = wp_get_attachment_image_src( $img_id, 'full' );
			$thumb_url = wp_get_attachment_image_src( $img_id, $size );
			$thumbnails[] = $thumb_url;

			$output .= '<li>';
			$output .= '<img src="' . $full_url[0] . '" />';
			$output .= '</li>';
		}
		$output .= ' </ul></div>';
		
		return $output;
	}

      /**
       * Init shortcode button and styles
       *
       * @since 1.0
       * @access public
       */
	public function init()
	{
		if ( ! current_user_can('edit_posts') && ! current_user_can('edit_pages') )
			return;
		if ( get_user_option('rich_editing') == 'true' ) {
			add_filter( 'mce_external_plugins', array(
				&$this,
				'addPlugin'
			));
			add_filter( 'mce_buttons', array(
				&$this,
				'registerButton'
			));
			add_action( 'admin_head', array(
				&$this, 
				'adminHead'
			));
		}
	}

      /**
       * Add tinymce plugin
       *
       * @since 1.0
       * @access public
       */
	public function addPlugin($plugin_array) {
		$plugin_array['genio_wt_shortcodes'] = plugins_url('/genio-wt/assets/js/tinymce.js');
		return $plugin_array;
	}

      /**
       * Register shortcodes button
       *
       * @since 1.0
       * @access public
       */
	public function registerButton($buttons) {
		array_push($buttons, 'genio_wt_shortcodes_button');
		return $buttons;
	}
    
      /**
       * Add inline css in header
       *
       * @since 1.0
       * @access public
       */
	public function adminHead() {
		?>
		<style type="text/css">.mce-menu-item-title { background: transparent none !important; cursor: default !important; }.mce-menu-item-title span { color: #000 !important; font-weight: bold; }</style>
		<?php
	}
}