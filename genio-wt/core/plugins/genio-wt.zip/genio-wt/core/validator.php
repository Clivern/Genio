<?php
/**
 * Genio - WordPress Theme Core Plugin
 *
 * @version 1.0
 * @package genio-wt
 * @author  Clivern <support@clivern.com>
 * @link    http://clivern.com/
 * @copyright     Copyright (c) 2015, Clivern (http://clivern.com/)
 * @license http://themeforest.net/licenses GPL
 */

class GENIO_WT_VALIDATOR
{

      /**
       * Current validated input
       * 
       * @since 1.0
       * @access private
       * @var array $this->input
       */
      private $input;

      /**
       * Clear $_GET and $_POST vars
       *
       * 
       * Prevents internet pirates from exploiting dan
       * If there is any issue here, i should remove my IDE and simply sell toys :)
       * So IF YOU FOUND BUG HERE SEND EMAIL TO HELLO@CLIVERN.COM TO INFORM.
       *
       * <code>
       * $inputs = array(
       *       'key' => array(
       *             'req'=> 'get|post',
       *             'sanit'=> '',
       *             'valid'=> '',
       *             'default'=>'',
       *             'errors'=>array(
       *                         'vrule' => error,
       *                         'vrule' => error,
       *                   ),
       *             ),
       *        ......,
       *        ......,
       * );  
       * </code>
       *
       * @since 1.0
       * @access public
       * @param array $inputs
       * @return array
       */
      public function clear($inputs)
      {
            $cleared_data = array(
                  'error_status' => false,
                  'error_text' => '',
            );
            foreach ( $inputs as $key => $rules ) {
                  $request = ($rules[ 'req' ] == 'get') ? $_GET : $_POST;
                  $sanit_rules = (isset($rules[ 'sanit' ])) ? $rules[ 'sanit' ] : null;
                  $valid_rules = (isset($rules[ 'valid' ])) ? $rules[ 'valid' ] : null;
                  $this->input = array(
                        'value' => null,
                        'status' => false,
                        'error' => false,
                  );
                  $this->input[ 'value' ] = (isset($request[ $key ])) ? $request[ $key ] : null;
                  //we need to validate user inputs
                  if ( $this->input[ 'value' ] !== null ) {
                        $this->input[ 'status' ] = ( boolean ) $this->valid($this->input[ 'value' ], $valid_rules);
                  }
                  //then sanitize
                  if ( $this->input[ 'value' ] !== null ) {
                        $this->input[ 'value' ] = $this->sanit($this->input[ 'value' ], $sanit_rules);
                  }
                  //override default
                  if ( (isset($rules[ 'default' ])) && ($rules[ 'default' ] !== null) && ($this->input[ 'status' ] == false) ) {
                        $this->input[ 'value' ] = $rules[ 'default' ];
                  }

                  //check if error found in 
                  if( (false === $cleared_data['error_status']) && (false !== $this->input['error']) && (isset($rules['errors'])) && (isset($rules['errors'][$this->input['error']])) ){
                        $cleared_data['error_status'] = true;
                        $cleared_data['error_text'] = $rules['errors'][$this->input['error']];
                  }
                  $cleared_data[ $key ] = $this->input;

            }
            return $cleared_data;
      }

      /**
       * Clear array of values
       *
       * 
       * Prevents internet pirates from exploiting dan
       * If there is any issue here, i should remove my IDE and simply sell toys :)
       * So IF YOU FOUND BUG HERE SEND EMAIL TO HELLO@CLIVERN.COM TO INFORM.
       *
       * <code>
       * $values = array(
       *       'key' => array(
       *             'value'=> '',
       *             'sanit'=> '',
       *             'valid'=> '',
       *             'default'=>'',
       *             'errors' => array()
       *             ),
       *        ......,
       *        ......,
       * );  
       * </code>
       *
       * @since 1.0
       * @access public
       * @param array $values
       * @return array
       */
      public function clear_values($values)
      {
            $cleared_values = array(
                  'error_status' => false,
                  'error_text' => '',
            );
            foreach ( $values as $key => $rules ) {
                  $sanit_rules = (isset($rules[ 'sanit' ])) ? $rules[ 'sanit' ] : null;
                  $valid_rules = (isset($rules[ 'valid' ])) ? $rules[ 'valid' ] : null;
                  $this->input = array(
                        'value' => null,
                        'status' => false,
                        'error' => false
                  );
                  $this->input[ 'value' ] = (isset($rules[ 'value' ])) ? $rules[ 'value' ] : null;
                  if ( $this->input[ 'value' ] !== null ) {
                        $this->input[ 'status' ] = ( boolean ) $this->valid($this->input[ 'value' ], $valid_rules);
                  }
                  if ( $this->input[ 'value' ] !== null ) {
                        $this->input[ 'value' ] = $this->sanit($this->input[ 'value' ], $sanit_rules);
                  }
                  if ( (isset($rules[ 'default' ])) && ($rules[ 'default' ] !== null) && ($this->input[ 'status' ] == false) ) {
                        $this->input[ 'value' ] = $rules[ 'default' ];
                  }

                  //check if error found in 
                  if( (false === $cleared_values['error_status']) && (false !== $this->input['error']) && (isset($rules['errors'])) && (isset($rules['errors'][$this->input['error']])) ){
                        $cleared_values['error_status'] = true;
                        $cleared_values['error_text'] = $rules['errors'][$this->input['error']];
                  }
                  $cleared_values[ $key ] = $this->input;
            }
            return $cleared_values;
      }

      /**
       * Execute different sanitization methods on given input value and return value again
       *
       * @since 1.0
       * @access private
       * @param string|array $value
       * @param string $rules
       * @return string|array
       */
      private function sanit($value, $rules)
      {
            if ( $rules == null ) {
                  return $value;
            }
            if ( strpos($rules, '&') ) {
                  $rules = explode('&', $rules);
            }
            else {
                  $rules = array( $rules );
            }
            $san_value = $value;
            $san_value = (is_array($san_value)) ? $san_value : trim($san_value);
            foreach ( $rules as $rule ) {
                  if ( strpos($rule, ':') ) {
                        $rule = explode(':', $rule);
                        $method = $rule[ 0 ];
                        $args = $rule[ 1 ];
                        $san_value = $this->$method($san_value, $args);
                  }
                  else {
                        $method = $rule;
                        $san_value = $this->$method($san_value);
                  }
            }
            return $san_value;
      }

      /**
       * Execute different validation methods on given input value and return status
       *
       * @since 1.0
       * @access private
       * @param string|array $value
       * @param string $rules
       * @return boolean
       */
      private function valid($value, $rules)
      {
            if ( $rules == null ) {
                  return true;
            }
            if ( strpos($rules, '&') ) {
                  $rules = explode('&', $rules);
            }
            else {
                  $rules = array( $rules );
            }
            $passed = true;
            $value = (is_array($value)) ? $value : trim($value);
            foreach ( $rules as $rule ) {
                  if ( strpos($rule, ':') ) {
                        $rule = explode(':', $rule);
                        $method = $rule[ 0 ];
                        $args = $rule[ 1 ];
                        $passed &= $this->$method($value, $args);
                        //detect first broken rule
                        $this->input['error'] = ( !($passed) && ($this->input['error'] == false) ) ? $method : $this->input['error'];
                  }
                  else {
                        $method = $rule;
                        $passed &= $this->$method($value);
                        //detect first broken rule
                        $this->input['error'] = ( !($passed) && ($this->input['error'] == false) ) ? $method : $this->input['error'];
                  }
            }
            return $passed;
      }

      /**
       * Sanitize email value 
       * 
       * Usage : add ..&semail to sanit rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return string sanitized value
       */
      private function semail($value)
      {
            return filter_var($value, FILTER_SANITIZE_EMAIL);
      }

      /**
       * Sanitize encoded value
       * + to used add ..&sencoded to sanit rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return string sanitized value
       */
      private function sencoded($value)
      {
            return filter_var($value, FILTER_SANITIZE_ENCODED);
      }

      /**
       * Sanitize full special chars value
       * 
       * Usage : add ..&sfullspecialchars to sanit rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return string sanitized value
       */
      private function sfullspecialchars($value)
      {
            return filter_var($value, FILTER_SANITIZE_SPECIAL_CHARS);
      }

      /**
       * Sanitize magic quotes value
       * 
       * Usage : add ..&smagicquotes to sanit rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return string sanitized value
       */
      private function smagicquotes($value)
      {
            return filter_var($value, FILTER_SANITIZE_MAGIC_QUOTES);
      }

      /**
       * Sanitize number float value
       * 
       * Usage : add ..&snumberfloat to sanit rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return string sanitized value
       */
      private function snumberfloat($value)
      {
            return filter_var($value, FILTER_SANITIZE_NUMBER_FLOAT);
      }

      /**
       * Sanitize number int value
       * 
       * Usage : add ..&snumberint to sanit rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return string sanitized value
       */
      private function snumberint($value)
      {
            return filter_var($value, FILTER_SANITIZE_NUMBER_INT);
      }

      /**
       * Sanitize special chars value
       * 
       * Usage : add ..&sspecialchars to sanit rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return string sanitized value
       */
      private function sspecialchars($value)
      {
            return filter_var($value, FILTER_SANITIZE_SPECIAL_CHARS);
      }

      /**
       * Sanitize string value
       * 
       * Usage : add ..&sstring to sanit rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return string sanitized value
       */
      private function sstring($value)
      {
            return filter_var($value, FILTER_SANITIZE_STRING);
      }

      /**
       * Sanitize integer or float value
       * 
       * Usage : add ..&sintfloat to sanit rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return string sanitized value
       */
      private function sintfloat($value)
      {      
            return filter_var($value, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
      }

      /**
       * Sanitize stripped value
       * 
       * Usage : add ..&sstripped to sanit rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return string sanitized value
       */
      /*private function sstripped($value)
      {
            return filter_var($value, FILTER_SANITIZE_STRIPPED);
      }*/

      /**
       * Sanitize url value
       * 
       * Usage : add ..&surl to sanit rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return string sanitized value
       */
      private function surl($value)
      {
            return filter_var($value, FILTER_SANITIZE_URL);
      }

      /**
       * Sanitize multi-input items
       * 
       * Usage : add ..&smultiinput to sanit rules
       *
       * @since 1.0
       * @access private
       * @param array $value
       * @return array
       */
      private function smultiinput($value)
      {
            if ( (is_array($value)) && (count($value) > 0) ) {
                  $new_values = array();
                  foreach ( $value as $input ) {
                        $new_value = filter_var(trim($input), FILTER_SANITIZE_STRING);
                        if ( ($new_value != '') && (strlen($new_value) <= 50) ) {
                              $new_values[] = $new_value;
                        }
                  }
                  return $new_values;
            } else {
                  return array();
            }
      }

      /**
       * Validate multi-input items
       * 
       * Usage : add ..&vmultiinput to valid rules
       *
       * @since 1.0
       * @access private
       * @param array $value
       * @return boolean
       */
      private function vmultiinput($value)
      {
            if ( (is_array($value)) && (count($value) > 0) ) {
                  $new_values = array();
                  foreach ( $value as $input ) {
                        $new_value = filter_var(trim($input), FILTER_SANITIZE_STRING);
                        if ( ($new_value != '') && (strlen($new_value) <= 50) ) {
                              $new_values[] = $new_value;
                        }
                  }
                  return (count($new_values) < 1 ) ? false : true;
            } else {
                  return false;
            }
      }

      /**
       * Validate boolean value
       * 
       * Usage : add ..&vboolean to validate rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return boolean
       */
      private function vboolean($value)
      {
            return ( boolean ) (filter_var($value, FILTER_VALIDATE_BOOLEAN));
      }

      /**
       * Validate email value
       * 
       * Usage : add ..&vemail to validate rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return boolean
       */
      private function vemail($value)
      {
            return ( boolean ) (filter_var($value, FILTER_VALIDATE_EMAIL));
      }

      /**
       * Validate float value
       * 
       * Usage : add ..&vfloat to validate rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return boolean
       */
      private function vfloat($value)
      {
            return ( boolean ) (filter_var($value, FILTER_VALIDATE_FLOAT));
      }

      /**
       * Validate int value
       * 
       * Usage : add ..&vint to validate rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return boolean
       */
      private function vint($value)
      {
            return ( boolean ) (filter_var($value, FILTER_VALIDATE_INT));
      }

      /**
       * Validate int or float value
       * 
       * Usage : add ..&vintfloat to validate rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return boolean
       */
      private function vintfloat($value)
      {      
            return ( ((boolean) filter_var($value, FILTER_VALIDATE_FLOAT)) || ((boolean)filter_var($value, FILTER_VALIDATE_INT)));
      }

      /**
       * Validate ip value
       * 
       * Usage : add ..&vip to validate rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return boolean
       */
      private function vip($value)
      {
            return ( boolean ) (filter_var($value, FILTER_VALIDATE_IP));
      }

      /**
       * Validate mac value
       * 
       * Usage : add ..&vmac to validate rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return boolean
       */
      /*private function vmac($value)
      {
            return ( boolean ) filter_var($value, FILTER_VALIDATE_MAC);
      }*/

      /**
       * Validate regexp value
       * 
       * Usage : add ..&vregexp to validate rules
       *
       * THIS METHOD TRY TO VALIDATE REGEXPs SO USING OF @ TO PREVENT NOTICES
       * THAT COULD RISE IF CLIENT SUBMIT INVALID REGEXPs
       * 
       * @since 1.0
       * @access private
       * @param string $value
       * @return boolean
       */
      private function vregexp($value)
      {
            $value = trim($value);
            return ( (boolean) (empty($value)) ) ? true : (@preg_match($value, null) !== false);
            return true;
      }

      /**
       * Validate url value
       * 
       * Usage : add ..&vurl to validate rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return boolean
       */
      private function vurl($value)
      {
            return ( boolean ) (filter_var($value, FILTER_VALIDATE_URL));
      }

      /**
       * Validate color value
       * 
       * Usage : add ..&vcolor to validate rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return boolean
       */
      private function vcolor($value)
      {
            return ( boolean ) (preg_match('|^#([A-Fa-f0-9]{3}){1,2}$|', $value));
      }

      /**
       * Validate notempty value
       * 
       * Usage : add ..&vnotempty to validate rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return boolean
       */
      private function vnotempty($value)
      {
            return ( boolean ) (($value != '') && (!empty($value)) && ($value != null));
      }

      /**
       * Validate inarray value
       * 
       * Usage : add ..&vinarray:left,right,center to validate rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return boolean
       */
      private function vinarray($value, $args)
      {
            $args = explode(',', $args);
            return ( boolean ) (in_array($value, $args));
      }

      /**
       * Validate dates
       * 
       * Usage : add ..&vdates:y|d
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @param string $args
       * @return boolean
       */
      private function vdates($value, $args)
      {
            if($args == 'y'){
            	return (boolean)( (filter_var($value, FILTER_VALIDATE_INT)) && ($value > 1920) && ($value <= current_time('Y')) );
            }elseif($args == 'd'){
            	return (boolean)( preg_match("/^(([1-2]?\\d{3})-((?:0\\d|1[0-2]))-(?:[0-2]\\d|3[0-1]))$/", $value) );
            }elseif($args == 'fy'){
                  return (boolean)( (filter_var($value, FILTER_VALIDATE_INT)) && ($value > 1920) );    
            }
      }


      /**
       * Validate intbetween value
       * 
       * Usage : add ..&vintbetween:1,1000 to validate rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return boolean
       */
      private function vintbetween($value, $args)
      {
            $args = explode(',', $args);
            $min = ( int ) $args[ 0 ];
            $max = ( int ) $args[ 1 ];
            return ( boolean ) (($value >= $min) && ($value <= $max));
      }

      /**
       * Validate equals value
       * 
       * Usage : add ..&vequals:helo to validate rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return boolean
       */
      private function vequals($value, $args)
      {
            return ( boolean ) ($value == $args);
      }

      /**
       * Validate checkbox value
       * 
       * Usage : add ..&vcheckbox to validate rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return boolean
       */
      private function vcheckbox($value)
      {
            return ( boolean ) ($value == '1');
      }

      /**
       * Validate if str lenght between two values
       * 
       * Usage : add ..&vstrlenbetween:1,250 to validate rules
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @param string $args
       * @return boolean
       */
      private function vstrlenbetween($value, $args)
      {
            $args = explode(',', $args);
            $value_lenght = strlen($value);
            $min = ( int ) $args[ 0 ];
            $max = ( int ) $args[ 1 ];
            return ( boolean ) (($value_lenght >= $min) && ($value_lenght <= $max));
      }

      /**
       * Validate alphanumeric strings with spaces
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return boolean
       */
      private function valnumws($value)
      {
            return (boolean) ctype_alnum(trim(str_replace(' ','',$value)));
      }

      /**
       * Validate if value is icon
       * 
       * Usage : add ..&vicon
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return boolean
       */
      private function vicon($value)
      {
            $icons_list = array('fa-glass', 'fa-music', 'fa-search', 'fa-envelope-o', 'fa-heart', 'fa-star', 'fa-star-o', 'fa-user', 'fa-film', 'fa-th-large', 'fa-th', 'fa-th-list', 'fa-check', 'fa-times', 'fa-search-plus', 'fa-search-minus', 'fa-power-off', 'fa-signal', 'fa-cog', 'fa-trash-o', 'fa-home', 'fa-file-o', 'fa-clock-o', 'fa-road', 'fa-download', 'fa-arrow-circle-o-down', 'fa-arrow-circle-o-up', 'fa-inbox', 'fa-play-circle-o', 'fa-repeat', 'fa-refresh', 'fa-list-alt', 'fa-lock', 'fa-flag', 'fa-headphones', 'fa-volume-off', 'fa-volume-down', 'fa-volume-up', 'fa-qrcode', 'fa-barcode', 'fa-tag', 'fa-tags', 'fa-book', 'fa-bookmark', 'fa-print', 'fa-camera', 'fa-font', 'fa-bold', 'fa-italic', 'fa-text-height', 'fa-text-width', 'fa-align-left', 'fa-align-center', 'fa-align-right', 'fa-align-justify', 'fa-list', 'fa-outdent', 'fa-indent', 'fa-video-camera', 'fa-picture-o', 'fa-pencil', 'fa-map-marker', 'fa-adjust', 'fa-tint', 'fa-pencil-square-o', 'fa-share-square-o', 'fa-check-square-o', 'fa-arrows', 'fa-step-backward', 'fa-fast-backward', 'fa-backward', 'fa-play', 'fa-pause', 'fa-stop', 'fa-forward', 'fa-fast-forward', 'fa-step-forward', 'fa-eject', 'fa-chevron-left', 'fa-chevron-right', 'fa-plus-circle', 'fa-minus-circle', 'fa-times-circle', 'fa-check-circle', 'fa-question-circle', 'fa-info-circle', 'fa-crosshairs', 'fa-times-circle-o', 'fa-check-circle-o', 'fa-ban', 'fa-arrow-left', 'fa-arrow-right', 'fa-arrow-up', 'fa-arrow-down', 'fa-share', 'fa-expand', 'fa-compress', 'fa-plus', 'fa-minus', 'fa-asterisk', 'fa-exclamation-circle', 'fa-gift', 'fa-leaf', 'fa-fire', 'fa-eye', 'fa-eye-slash', 'fa-exclamation-triangle', 'fa-plane', 'fa-calendar', 'fa-random', 'fa-comment', 'fa-magnet', 'fa-chevron-up', 'fa-chevron-down', 'fa-retweet', 'fa-shopping-cart', 'fa-folder', 'fa-folder-open', 'fa-arrows-v', 'fa-arrows-h', 'fa-bar-chart-o', 'fa-twitter-square', 'fa-facebook-square', 'fa-camera-retro', 'fa-key', 'fa-cogs', 'fa-comments', 'fa-thumbs-o-up', 'fa-thumbs-o-down', 'fa-star-half', 'fa-heart-o', 'fa-sign-out', 'fa-linkedin-square', 'fa-thumb-tack', 'fa-external-link', 'fa-sign-in', 'fa-trophy', 'fa-github-square', 'fa-upload', 'fa-lemon-o', 'fa-phone', 'fa-square-o', 'fa-bookmark-o', 'fa-phone-square', 'fa-twitter', 'fa-facebook', 'fa-github', 'fa-unlock', 'fa-credit-card', 'fa-rss', 'fa-hdd-o', 'fa-bullhorn', 'fa-bell', 'fa-certificate', 'fa-hand-o-right', 'fa-hand-o-left', 'fa-hand-o-up', 'fa-hand-o-down', 'fa-arrow-circle-left', 'fa-arrow-circle-right', 'fa-arrow-circle-up', 'fa-arrow-circle-down', 'fa-globe', 'fa-wrench', 'fa-tasks', 'fa-filter', 'fa-briefcase', 'fa-arrows-alt', 'fa-users', 'fa-link', 'fa-cloud', 'fa-flask', 'fa-scissors', 'fa-files-o', 'fa-paperclip', 'fa-floppy-o', 'fa-square', 'fa-bars', 'fa-list-ul', 'fa-list-ol', 'fa-strikethrough', 'fa-underline', 'fa-table', 'fa-magic', 'fa-truck', 'fa-pinterest', 'fa-pinterest-square', 'fa-google-plus-square', 'fa-google-plus', 'fa-money', 'fa-caret-down', 'fa-caret-up', 'fa-caret-left', 'fa-caret-right', 'fa-columns', 'fa-sort', 'fa-sort-asc', 'fa-sort-desc', 'fa-envelope', 'fa-linkedin', 'fa-undo', 'fa-gavel', 'fa-tachometer', 'fa-comment-o', 'fa-comments-o', 'fa-bolt', 'fa-sitemap', 'fa-umbrella', 'fa-clipboard', 'fa-lightbulb-o', 'fa-exchange', 'fa-cloud-download', 'fa-cloud-upload', 'fa-user-md', 'fa-stethoscope', 'fa-suitcase', 'fa-bell-o', 'fa-coffee', 'fa-cutlery', 'fa-file-text-o', 'fa-building-o', 'fa-hospital-o', 'fa-ambulance', 'fa-medkit', 'fa-fighter-jet', 'fa-beer', 'fa-h-square', 'fa-plus-square', 'fa-angle-double-left', 'fa-angle-double-right', 'fa-angle-double-up', 'fa-angle-double-down', 'fa-angle-left', 'fa-angle-right', 'fa-angle-up', 'fa-angle-down', 'fa-desktop', 'fa-laptop', 'fa-tablet', 'fa-mobile', 'fa-circle-o', 'fa-quote-left', 'fa-quote-right', 'fa-spinner', 'fa-circle', 'fa-reply', 'fa-github-alt', 'fa-folder-o', 'fa-folder-open-o', 'fa-smile-o', 'fa-frown-o', 'fa-meh-o', 'fa-gamepad', 'fa-keyboard-o', 'fa-flag-o', 'fa-flag-checkered', 'fa-terminal', 'fa-code', 'fa-reply-all', 'fa-mail-reply-all', 'fa-star-half-o', 'fa-location-arrow', 'fa-crop', 'fa-code-fork', 'fa-chain-broken', 'fa-question', 'fa-info', 'fa-exclamation', 'fa-superscript', 'fa-subscript', 'fa-eraser', 'fa-puzzle-piece', 'fa-microphone', 'fa-microphone-slash', 'fa-shield', 'fa-calendar-o', 'fa-fire-extinguisher', 'fa-rocket', 'fa-maxcdn', 'fa-chevron-circle-left', 'fa-chevron-circle-right', 'fa-chevron-circle-up', 'fa-chevron-circle-down', 'fa-html5', 'fa-css3', 'fa-anchor', 'fa-unlock-alt', 'fa-bullseye', 'fa-ellipsis-h', 'fa-ellipsis-v', 'fa-rss-square', 'fa-play-circle', 'fa-ticket', 'fa-minus-square', 'fa-minus-square-o', 'fa-level-up', 'fa-level-down', 'fa-check-square', 'fa-pencil-square', 'fa-external-link-square', 'fa-share-square', 'fa-compass', 'fa-caret-square-o-down', 'fa-caret-square-o-up', 'fa-caret-square-o-right', 'fa-eur', 'fa-gbp', 'fa-usd', 'fa-inr', 'fa-jpy', 'fa-rub', 'fa-krw', 'fa-btc', 'fa-file', 'fa-file-text', 'fa-sort-alpha-asc', 'fa-sort-alpha-desc', 'fa-sort-amount-asc', 'fa-sort-amount-desc', 'fa-sort-numeric-asc', 'fa-sort-numeric-desc', 'fa-thumbs-up', 'fa-thumbs-down', 'fa-youtube-square', 'fa-youtube', 'fa-xing', 'fa-xing-square', 'fa-youtube-play', 'fa-dropbox', 'fa-stack-overflow', 'fa-instagram', 'fa-flickr', 'fa-adn', 'fa-bitbucket', 'fa-bitbucket-square', 'fa-tumblr', 'fa-tumblr-square', 'fa-long-arrow-down', 'fa-long-arrow-up', 'fa-long-arrow-left', 'fa-long-arrow-right', 'fa-apple', 'fa-windows', 'fa-android', 'fa-linux', 'fa-dribbble', 'fa-skype', 'fa-foursquare', 'fa-trello', 'fa-female', 'fa-male', 'fa-gittip', 'fa-sun-o', 'fa-moon-o', 'fa-archive', 'fa-bug', 'fa-vk', 'fa-weibo', 'fa-renren', 'fa-pagelines', 'fa-stack-exchange', 'fa-arrow-circle-o-right', 'fa-arrow-circle-o-left', 'fa-caret-square-o-left', 'fa-dot-circle-o', 'fa-wheelchair', 'fa-vimeo-square', 'fa-try', 'fa-plus-square-o');
            return (boolean)(in_array($value, $icons_list));
      }

      /**
       * Validate if value is sections order
       * 
       * Usage : add ..&vsarr
       *
       * @since 1.0
       * @access private
       * @param string $value
       * @return boolean
       */
      private function vsecord($value)
      {
            $status = true;
            if( !(strpos($value, '__') > 0) ){
                  return false;
            }
            $value = explode('__', $value);
            $status &= (count($value) == 15);
            $status &= (boolean) in_array('home', $value);
            $status &= (boolean) in_array('nav', $value);
            $status &= (boolean) in_array('profile', $value);
            $status &= (boolean) in_array('hobbies', $value);
            $status &= (boolean) in_array('resume', $value);
            $status &= (boolean) in_array('milestones', $value);
            $status &= (boolean) in_array('skills', $value);
            $status &= (boolean) in_array('services', $value);
            $status &= (boolean) in_array('blog', $value);
            $status &= (boolean) in_array('workprocess', $value);
            $status &= (boolean) in_array('portfolio', $value);
            $status &= (boolean) in_array('pricing', $value);
            $status &= (boolean) in_array('clients', $value);
            $status &= (boolean) in_array('testimonials', $value);
            $status &= (boolean) in_array('contact', $value);

            return $status;
      }
}