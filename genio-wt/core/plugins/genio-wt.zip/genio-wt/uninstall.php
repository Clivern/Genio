<?php
/**
 * Genio - WordPress Theme Core Plugin
 *
 * @version 1.0
 * @package genio-wt
 * @author  Clivern <support@clivern.com>
 * @link    http://clivern.com/
 * @copyright     Copyright (c) 2015, Clivern (http://clivern.com/)
 * @license http://themeforest.net/licenses GPL
 */

/**
 * Check if user need us to leave
 *
 * THAT'S TOO BAD
 */
if ( !defined('WP_UNINSTALL_PLUGIN') ){
	//die
      exit();
}

/**
 * Delete theme options
 *
 * Both templates, customize and basic
 */
$templates = get_option('genio_wt_customize');
foreach ($templates['templates'] as $key => $template) {
	delete_option('genio_wt_' . $key . '_template');
}
delete_option('genio_wt_customize');
delete_option('genio_wt_basic');
// End of uninstall.php