
// For all WP versions
function genio_on_click(id) {
    // Selected content
    var mceSelected = tinyMCE.activeEditor.selection.getContent();

    // Add highlighted content inside the shortcode when possible
    if ( mceSelected ) {
        var genioDummyContent = mceSelected;
    } else {
        var genioDummyContent = 'Dummy Content';
    }

    // Featured
    if(id == "gallery") {
        tinyMCE.activeEditor.selection.setContent('[genio_fgallery ids="1,2,3"]');
    }
    if(id == "video") {
        tinyMCE.activeEditor.selection.setContent('[genio_fvideo url="http://dummy/video/url"]');
    }

    return false;
}

function genio_wt_render_item(parent_item, title, id) {
    var item = {
        'text': title,
        onclick: function(){ genio_on_click(id); }
    };
    parent_item.push(item);
}

function genio_wt_get_menu() {
    var menu = [
        {
            text: 'Genio Shortcodes',
            classes: 'menu-item-title',
            disabled: true,
        },
        { text: 'Featured' },
    ];

    // Featured
    var c = menu[1].menu = [];
    genio_wt_render_item( c, "Gallery", "gallery" );
    genio_wt_render_item( c, "Video", "video" );

    return menu;
}

tinymce.PluginManager.add('genio_wt_shortcodes', function( editor, url ) {
    if (typeof tinymce.plugins == 'undefined') tinymce.plugins = {};
    if (typeof tinymce.plugins.genioWtShortcodeMce == 'undefined')
    tinymce.plugins.genioWtShortcodeMce = {};
    tinymce.plugins.genioWtShortcodeMce.theurl = url;
    menu = genio_wt_get_menu();

    editor.addButton( 'genio_wt_shortcodes_button', {
        type: 'splitbutton',
        style: 'background: url(' + tinymce.plugins.genioWtShortcodeMce.theurl + '/../img/genio-shortcodes.png' + ') no-repeat 3px 2px;',
        //image: tinymce.plugins.genioWtShortcodeMce.theurl + '/images/shortcodes.png',
        'menu': menu
    });
});
