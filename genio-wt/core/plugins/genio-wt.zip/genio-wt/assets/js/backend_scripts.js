
var genio = genio || {};

genio.builder = (function (window, document, $) {
    'use strict';

var utils = {

        // set initial metabox order
        set_metaboxes_order : function(){
            var metaboxes_order = $('input#genio_sections_order').val();
            var metaboxes_order_list = metaboxes_order.split('__');
            var metaboxes = [];
            metaboxes_order_list.forEach(function(e,i){
                metaboxes.push($('#genio-' + e + '-metabox'));
            });
            $('div#normal-sortables').append(metaboxes);   
        },

        //set save as template switcher
        save_templates_switch : function(){
            $('select#genio_template_save_as').on('change', function(event) {
                var $this = $(this);
                if($this.val() == 'new'){
                    $('p#genio_new_template_wrapper').show();
                }else{
                    $('p#genio_new_template_wrapper').hide();
                }
            });
        },

        //store metaboxes order on submit
        store_metaboxes_order : function(){
            var available_metaboxes = [
                'genio',
                'genio-home-metabox',
                'genio-nav-metabox',
                'genio-profile-metabox',
                'genio-hobbies-metabox',
                'genio-resume-metabox',
                'genio-milestones-metabox',
                'genio-skills-metabox',
                'genio-services-metabox',
                'genio-workprocess-metabox',
                'genio-blog-metabox',
                'genio-portfolio-metabox',
                'genio-pricing-metabox',
                'genio-clients-metabox',
                'genio-testimonials-metabox',
                'genio-contact-metabox',
            ];
            $('form#genio_settings_form').submit(function(event) {
                var metaboxes_names = [];
                $('div#publishing-action #spinner_submit').css('display','inline');
                $('div[id^="genio-"]').each(function() {
                    var $this = $(this);
                    if(available_metaboxes.indexOf($this.attr('id')) >= 1){
                        var sections = $this.attr('id').split('-');
                        metaboxes_names.push(sections[1]);
                    }
                });
                $('input#genio_sections_order').val(metaboxes_names.join('__'));
            });
        },

        //add media select action to select image button
        media_select : function(){
            $('a#genio_home_photo, a#genio_profile_photo, a#genio_profile_signature, a#genio_profile_cv, a#genio_home_bg, a#genio_testimonials_bg, a#genio_hobbies_bg, a#genio_workprocess_bg').click(function(event){
                var $this = $(this);
                if (this.window === undefined) {
                    this.window = wp.media({
                        title: 'Insert a media',
                        library: {type: 'image'},
                        multiple: false,
                        button: {text: 'Insert'}
                    });
 
                    var self = this;
                    this.window.on('select', function() {
                        var first = self.window.state().get('selection').first().toJSON();
                        $('input#_val_' + $this.attr('id')).val(first.url);
                    });
                }
 
                this.window.open();
                return false;
            });
        },

        //change icon preview on select
        icon_select : function(){
            $('select#genio_pricing_icon, select#genio_profile_icon, select#genio_resume_icon, select#genio_resume_education_icon, select#genio_resume_experience_icon, select#genio_resume_recognition_icon, select#genio_first_box_icon, select#genio_second_box_icon, select#genio_third_box_icon, select#genio_fourth_box_icon, select#genio_skills_icon, select#genio_services_icon, select#genio_portfolio_icon, select#genio_contact_icon').change(function(event){
                var $this = $(this);
                $('span#' + $this.attr('id') + '_show i').removeClass().addClass('fa').addClass($this.val());
            });
        },

        template_delete : function(){
            $('input#template_delete').on('click', function(event) {
                if(event.target == this){
                    event.preventDefault();
                    $('span#spinner_delete').show();
                    $.post(
                        delete_template_auth.ajaxurl,
                        {
                            action : delete_template_auth.action,
                            __ajax_nonce : delete_template_auth.__ajax_nonce,
                            template : $('select#genio_delete_template').val()
                        },
                        function( response, textStatus, jqXHR ){
                            if( 200 == jqXHR.status && 'success' == textStatus ) {
                                if( 'success' == response.status ){
                                    $('span#spinner_delete').hide();
                                    location.reload();
                                }else{
                                    //error encountered
                                    $('span#spinner_delete').hide();
                                    location.reload();
                                }
                            }
                        },
                        'json'
                    ); 
                }  
            });
        },

        demo_import : function(){
            
            $('input#demo_import').on('click', function(event) {
                if(event.target == this){
                    event.preventDefault();
                    if(!confirm("Are Your Sure, You Are Tring To Import Demo?")){
                        return false;
                    }
                    $('span#spinner_import').show();
                    $('input#demo_import').val('Wait!').attr('disabled', 'disabled');
                    $.post(
                        demo_import_auth.ajaxurl,
                        {
                            action : demo_import_auth.action,
                            __ajax_nonce : demo_import_auth.__ajax_nonce
                        },
                        function( response, textStatus, jqXHR ){
                            if( 200 == jqXHR.status && 'success' == textStatus ) {
                                if( 'success' == response.status ){
                                    $('span#spinner_import').hide();
                                    $('p#import_alert').text(response.data).show();
                                    $('p#import_alert_info').hide();
                                    $('input#demo_import').val('Done').attr('disabled', 'disabled');
                                }else{
                                    //error encountered
                                    $('span#spinner_import').hide();
                                    $('p#import_alert').text("Error encountered during importing, may be server not responding.").show();
                                    $('p#import_alert_info').hide();
                                    $('input#demo_import').val('Done').attr('disabled', 'disabled');
                                }
                            }
                        },
                        'json'
                    );
                }
            });
        },

        home_style_switch : function(){
            var home_style_switch = $('select#genio_home_styles'),
            bg_image_row = $('tr#genio_home_bg_tr'),
            photo_image_row  = $('tr#genio_home_your_photo_tr');

            if(home_style_switch.val() == 'parallax'){
                bg_image_row.show();
                photo_image_row.hide();
            }else if(home_style_switch.val() == 'bottom_image'){
                bg_image_row.show();
                photo_image_row.show();
                photo_image_row.find('p#bottom_img_desc').show();
                photo_image_row.find('p#right_img_desc').hide();
                photo_image_row.find('p#gradient_img_desc').hide();
            }else if(home_style_switch.val() == 'right_image'){
                bg_image_row.show();
                photo_image_row.show();
                photo_image_row.find('p#bottom_img_desc').hide();
                photo_image_row.find('p#right_img_desc').show();
                photo_image_row.find('p#gradient_img_desc').hide();
            }else if(home_style_switch.val() == 'gradient'){
                bg_image_row.hide();
                photo_image_row.show();
                photo_image_row.find('p#bottom_img_desc').hide();
                photo_image_row.find('p#right_img_desc').hide();
                photo_image_row.find('p#gradient_img_desc').show();
            }

            home_style_switch.on('change', function(event) {
                var $this = $(this);
                if($this.val() == 'parallax'){
                    bg_image_row.show();
                    photo_image_row.hide();
                }else if($this.val() == 'bottom_image'){
                    bg_image_row.show();
                    photo_image_row.show();
                    photo_image_row.find('p#bottom_img_desc').show();
                    photo_image_row.find('p#right_img_desc').hide();
                    photo_image_row.find('p#gradient_img_desc').hide();
                }else if($this.val() == 'right_image'){
                    bg_image_row.show();
                    photo_image_row.show();
                    photo_image_row.find('p#bottom_img_desc').hide();
                    photo_image_row.find('p#right_img_desc').show();
                    photo_image_row.find('p#gradient_img_desc').hide();
                }else if($this.val() == 'gradient'){
                    bg_image_row.hide();
                    photo_image_row.show();
                    photo_image_row.find('p#bottom_img_desc').hide();
                    photo_image_row.find('p#right_img_desc').hide();
                    photo_image_row.find('p#gradient_img_desc').show();
                }
            });
        },

        //run home builder module
        init : function(){
            utils.set_metaboxes_order();
            utils.save_templates_switch();
            utils.store_metaboxes_order();
            utils.media_select();
            utils.icon_select();
            utils.template_delete();
            utils.demo_import();
            utils.home_style_switch();
        },
    
    }
    return {
        init: utils.init,
    }
})(window, document, jQuery);

genio.customizer = (function (window, document, $) {
    'use strict';
var utils = {
        init : function(){},
    }
    return {
        init: utils.init,
    }
})(window, document, jQuery);


genio.tabular = (function (window, document, $) {
    'use strict';
var utils = {

        media_select : function (){
            var $this = $(this);
            if (this.window === undefined) {
                this.window = wp.media({
                    title: 'Insert a media',
                    library: {type: 'image'},
                    multiple: false,
                    button: {text: 'Insert'}
                });
 
                var self = this;
                this.window.on('select', function() {
                    var first = self.window.state().get('selection').first().toJSON();
                    $('input#_val_' + $this.attr('id')).val(first.url);
                });
            }
 
            this.window.open();
            return false;
        },

        icon_select : function update_icon_shown(event){
            var $this = $(this);
            $('span#' + $this.attr('id') + '_show i').removeClass().addClass('fa').addClass($this.val());
        },
        
        //init project page events
        projects_page : function(){
            $('#genio_project_date').datetimepicker({
                    timepicker: false,
                    format: 'Y-m-d',
            });

            $('a#genio_project_header_img').click(utils.media_select);
        },

        //init services page events
        services_page : function(){
             $('select#genio_service_icon').change(utils.icon_select);
        },

        //init clients page events
        clients_page : function(){
            $('a#genio_client_logo').click(utils.media_select);
        },

        //init testimonials page events
        testimoials_page : function(){
            $('a#genio_testimonial_photo').click(utils.media_select);
        },

        //init work process page events
        work_process_page : function(){
            $('select#genio_work_process_icon').change(utils.icon_select);
        },

        //init hobbies page events
        hobbies_page : function(){
            $('select#genio_hobbies_icon').change(utils.icon_select);
        },

        //init skills page events
        skills_page : function(){
            if($('select#genio_skills_display_as').val() == 'list_item'){
                $('select#genio_skills_level').parents('tr').hide();
            }
            $('select#genio_skills_display_as').on('change', function(event) {
                var $this = $(this);
                if($this.val() == 'list_item'){
                    $('select#genio_skills_level').parents('tr').hide();
                }else{
                    $('select#genio_skills_level').parents('tr').show();
                }
            });
        },

        //init resume page events
        resume_page : function(){
            $('input#genio_resume_ed_from, input#genio_resume_ed_to, input#genio_resume_ex_to, input#genio_resume_ex_from').datetimepicker({
                    timepicker: false,
                    format: 'Y',
            });
            $('input#genio_resume_re_date').datetimepicker({
                    timepicker: false,
                    format: 'Y-m-d',
            });
            $('select#genio_resume_re_icon').change(utils.icon_select);
            $('a#genio_resume_ex_logo').click(utils.media_select);

            if($('select#genio_resume_category').val() == 'education'){
                $('tr.ed_part').show();
                $('tr.ex_part').hide();
                $('tr.re_part').hide();
            }else if($('select#genio_resume_category').val() == 'experience'){
                $('tr.ed_part').hide();
                $('tr.ex_part').show();
                $('tr.re_part').hide();
            }else{
                $('tr.ed_part').hide();
                $('tr.ex_part').hide();
                $('tr.re_part').show();
            }
            $('select#genio_resume_category').on('change', function(event) {
                var $this = $(this);
                if($this.val() == 'education'){
                    $('tr.ed_part').show();
                    $('tr.ex_part').hide();
                    $('tr.re_part').hide();
                }else if($this.val() == 'experience'){
                    $('tr.ed_part').hide();
                    $('tr.ex_part').show();
                    $('tr.re_part').hide();
                }else{
                    $('tr.ed_part').hide();
                    $('tr.ex_part').hide();
                    $('tr.re_part').show();
                }
            });
        },

        //init pricing page events
        pricing_page : function(){
            $('td.plan_feature').on('click', 'a.button',function(event) {
                event.preventDefault();
                var $this = $(this);
                if($this.parents('span').hasClass('feature_exists')){
                    $this.parents('span').remove();
                }
                var new_feature = $this.parents('span').clone();
                new_feature.removeAttr('id');
                new_feature.find('input').removeAttr('disabled');
                new_feature.find('i').removeClass('fa-plus-circle').addClass('fa-minus-circle');
                new_feature.addClass('feature_exists');
                $this.parents('td.plan_feature').append(new_feature);
            });
        },
    }
    return {
        projects_page : utils.projects_page,
        services_page : utils.services_page,
        clients_page : utils.clients_page,
        testimoials_page : utils.testimoials_page,
        work_process_page : utils.work_process_page,
        hobbies_page : utils.hobbies_page,
        skills_page : utils.skills_page,
        resume_page : utils.resume_page,
        pricing_page : utils.pricing_page,
    }
})(window, document, jQuery);

if(genio_router.builder){
    genio.builder.init();   
}

if(genio_router.customizer){
     genio.customizer.init();   
}

if(genio_router.table && genio_router.project){
    genio.tabular.projects_page();
}

if(genio_router.table && genio_router.services){
    genio.tabular.services_page();
}

if(genio_router.table && genio_router.clients){
    genio.tabular.clients_page();
}

if(genio_router.table && genio_router.testimoials){
    genio.tabular.testimoials_page();
}

if(genio_router.table && genio_router.work_process){
    genio.tabular.work_process_page();
}

if(genio_router.table && genio_router.hobbies){
    genio.tabular.hobbies_page();
}

if(genio_router.table && genio_router.skills){
    genio.tabular.skills_page();
}

if(genio_router.table && genio_router.resume){
    genio.tabular.resume_page();
}

if(genio_router.table && genio_router.pricing){
    genio.tabular.pricing_page();
}

